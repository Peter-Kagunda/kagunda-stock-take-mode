<?php
/**
 * Settings import/export helper for Kagunda Stock Take Mode for WooCommerce.
 *
 * Lets a store owner download their configuration as JSON and re-import it
 * on the same or another site. No arbitrary code is ever executed - only a
 * fixed allow-list of known option keys is read or written.
 *
 * @package Kagunda_Stock_Take_Mode_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'KAGSTM_Import_Export' ) ) {

	class KAGSTM_Import_Export {

		/**
		 * Allow-listed option keys (without the "kagstm_" prefix) that are
		 * safe to export/import. Deliberately excludes stats and the
		 * subscriber waitlist, which are site-specific data, not settings.
		 *
		 * @return array
		 */
		public static function get_portable_keys() {
			return array(
				'enabled',
				'start_datetime',
				'end_datetime',
				'message',
				'button_behavior',
				'button_text',
				'bg_color',
				'text_color',
				'clear_cart',
				'show_countdown',
				'enable_waitlist',
				'admin_alerts',
				'broadcast_complete',
				'broadcast_subject',
				'broadcast_body',
				'bypass_roles',
				'product_exceptions',
				'category_exceptions',
				'show_admin_bar_indicator',
			);
		}

		/**
		 * Build a JSON string with the current settings.
		 *
		 * @return string
		 */
		public static function export_json() {
			$data = array();

			foreach ( self::get_portable_keys() as $key ) {
				$data[ $key ] = get_option( 'kagstm_' . $key, null );
			}

			return wp_json_encode(
				array(
					'plugin'  => 'kagunda-stock-take-mode-for-woocommerce',
					'version' => defined( 'KAGSTM_VERSION' ) ? KAGSTM_VERSION : '',
					'settings' => $data,
				),
				JSON_PRETTY_PRINT
			);
		}

		/**
		 * Validate and apply a previously exported JSON payload.
		 *
		 * @param string $json Raw JSON string supplied by the store owner.
		 * @return true|WP_Error
		 */
		public static function import_json( $json ) {
			$decoded = json_decode( $json, true );

			if ( null === $decoded || ! is_array( $decoded ) || empty( $decoded['settings'] ) || ! is_array( $decoded['settings'] ) ) {
				return new WP_Error( 'kagstm_invalid_file', __( 'That file does not look like a valid configuration export.', 'kagunda-stock-take-mode-for-woocommerce' ) );
			}

			$allowed = self::get_portable_keys();

			foreach ( $decoded['settings'] as $key => $value ) {
				if ( ! in_array( $key, $allowed, true ) ) {
					continue; // Ignore anything outside the allow-list.
				}

				$sanitized = self::sanitize_value( $key, $value );
				update_option( 'kagstm_' . $key, $sanitized );
			}

			return true;
		}

		/**
		 * Re-uses the same sanitizers as the settings screen so imported
		 * data is held to the same standard as manually entered data.
		 *
		 * @param string $key   Unprefixed option key.
		 * @param mixed  $value Raw value from the import file.
		 * @return mixed
		 */
		private static function sanitize_value( $key, $value ) {
			switch ( $key ) {
				case 'message':
				case 'broadcast_body':
					return wp_kses_post( (string) $value );
				case 'bg_color':
				case 'text_color':
					return sanitize_hex_color( (string) $value );
				case 'bypass_roles':
				case 'product_exceptions':
				case 'category_exceptions':
					if ( ! is_array( $value ) ) {
						return array();
					}
					return 'bypass_roles' === $key ? array_map( 'sanitize_text_field', $value ) : array_filter( array_map( 'absint', $value ) );
				default:
					return sanitize_text_field( (string) $value );
			}
		}
	}
}
