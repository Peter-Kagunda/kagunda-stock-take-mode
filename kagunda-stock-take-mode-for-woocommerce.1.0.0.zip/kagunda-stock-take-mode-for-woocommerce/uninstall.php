<?php
/**
 * Uninstall handler for Kagunda Stock Take Mode for WooCommerce.
 *
 * Runs only when the plugin is deleted from the Plugins screen (never on
 * deactivation), and removes every option this plugin created.
 *
 * @package Kagunda_Stock_Take_Mode_For_WooCommerce
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Delete every "kagstm_" option (and the legacy "wc_stm_" options carried
 * over from before the plugin was renamed) for the current site.
 */
function kagstm_uninstall_delete_options() {
	$options = array(
		'kagstm_enabled',
		'kagstm_start_datetime',
		'kagstm_end_datetime',
		'kagstm_message',
		'kagstm_button_behavior',
		'kagstm_button_text',
		'kagstm_bg_color',
		'kagstm_text_color',
		'kagstm_clear_cart',
		'kagstm_show_countdown',
		'kagstm_enable_waitlist',
		'kagstm_admin_alerts',
		'kagstm_show_admin_bar_indicator',
		'kagstm_broadcast_complete',
		'kagstm_broadcast_subject',
		'kagstm_broadcast_body',
		'kagstm_bypass_roles',
		'kagstm_product_exceptions',
		'kagstm_category_exceptions',
		'kagstm_last_known_state',
		'kagstm_stat_blocked_attempts',
		'kagstm_subscriber_waitlist',
		'kagstm_legacy_migration_done',
		// Legacy option names used before the plugin's pre-approval rename.
		'wc_stm_enabled',
		'wc_stm_start_datetime',
		'wc_stm_end_datetime',
		'wc_stm_message',
		'wc_stm_button_behavior',
		'wc_stm_button_text',
		'wc_stm_bg_color',
		'wc_stm_text_color',
		'wc_stm_custom_css',
		'wc_stm_clear_cart',
		'wc_stm_show_countdown',
		'wc_stm_enable_waitlist',
		'wc_stm_admin_alerts',
		'wc_stm_broadcast_complete',
		'wc_stm_broadcast_subject',
		'wc_stm_broadcast_body',
		'wc_stm_bypass_roles',
		'wc_stm_product_exceptions',
		'wc_stm_last_known_state',
		'wc_stm_stat_blocked_attempts',
		'wc_stm_subscriber_waitlist_v2',
	);

	foreach ( $options as $option ) {
		delete_option( $option );
	}

	delete_transient( 'kagstm_category_product_ids_cache' );
}

if ( is_multisite() ) {
	$kagstm_uninstall_site_ids = get_sites( array( 'fields' => 'ids' ) );
	foreach ( $kagstm_uninstall_site_ids as $kagstm_uninstall_site_id ) {
		switch_to_blog( $kagstm_uninstall_site_id );
		kagstm_uninstall_delete_options();
		restore_current_blog();
	}
} else {
	kagstm_uninstall_delete_options();
}
