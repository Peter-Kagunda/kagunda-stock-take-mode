<?php
/**
 * Plugin Name:       Kagunda Stock Take Mode for WooCommerce
 * Plugin URI:        https://peterkagunda.com
 * Description:       Temporarily pause purchasing on your WooCommerce store during inventory counts, with a countdown banner, waitlist capture, and automatic re-open notifications.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Requires Plugins:  woocommerce
 * Author:            Peter Kagunda
 * Author URI:        https://peterkagunda.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       kagunda-stock-take-mode-for-woocommerce
 *
 * @package Kagunda_Stock_Take_Mode_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'KAGSTM_VERSION', '1.0.0' );
define( 'KAGSTM_PLUGIN_FILE', __FILE__ );
define( 'KAGSTM_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'KAGSTM_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once KAGSTM_PLUGIN_DIR . 'includes/class-kagstm-logger.php';
require_once KAGSTM_PLUGIN_DIR . 'includes/class-kagstm-import-export.php';

add_action( 'before_woocommerce_init', 'kagstm_declare_features_compatibility' );
/**
 * Declare compatibility with WooCommerce's HPOS and cart/checkout blocks.
 */
function kagstm_declare_features_compatibility() {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', KAGSTM_PLUGIN_FILE, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', KAGSTM_PLUGIN_FILE, true );
	}
}

/**
 * Core plugin class.
 */
class Kagunda_Stock_Take_Mode_For_WooCommerce {

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Get the singleton instance.
	 *
	 * @return self
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Wire up hooks.
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'maybe_migrate_legacy_options' ), 1 );
		add_action( 'admin_menu', array( $this, 'register_admin_menu' ), 56 );
		add_action( 'admin_init', array( $this, 'register_settings_fields' ) );
		add_action( 'admin_init', array( $this, 'handle_csv_export' ) );
		add_action( 'admin_init', array( $this, 'handle_settings_export' ) );
		add_action( 'admin_init', array( $this, 'handle_settings_import' ) );
		add_action( 'admin_notices', array( $this, 'render_admin_notices' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
		add_action( 'wp_ajax_kagstm_json_search_products', array( $this, 'ajax_search_products' ) );

		// Waitlist AJAX handlers.
		add_action( 'wp_ajax_kagstm_subscribe_email', array( $this, 'handle_banner_subscription' ) );
		add_action( 'wp_ajax_nopriv_kagstm_subscribe_email', array( $this, 'handle_banner_subscription' ) );
		add_action( 'wp_ajax_kagstm_send_test_email', array( $this, 'handle_admin_test_email' ) );

		add_action( 'init', array( $this, 'maybe_init_restrictions' ), 10 );
		add_action( 'wp_dashboard_setup', array( $this, 'register_dashboard_analytics_widget' ) );
		add_action( 'admin_bar_menu', array( $this, 'render_admin_bar_indicator' ), 100 );
	}

	/**
	 * One-time, best-effort migration from the plugin's earlier "wc_stm_"
	 * option prefix (used before the plugin was renamed to comply with the
	 * WordPress.org trademark guidelines) to the current "kagstm_" prefix,
	 * so an existing store's configuration is not lost on update.
	 */
	public function maybe_migrate_legacy_options() {
		if ( '1' === get_option( 'kagstm_legacy_migration_done', '' ) ) {
			return;
		}

		$legacy_map = array(
			'wc_stm_enabled'                 => 'kagstm_enabled',
			'wc_stm_start_datetime'          => 'kagstm_start_datetime',
			'wc_stm_end_datetime'            => 'kagstm_end_datetime',
			'wc_stm_message'                 => 'kagstm_message',
			'wc_stm_button_behavior'         => 'kagstm_button_behavior',
			'wc_stm_button_text'             => 'kagstm_button_text',
			'wc_stm_bg_color'                => 'kagstm_bg_color',
			'wc_stm_text_color'              => 'kagstm_text_color',
			'wc_stm_clear_cart'              => 'kagstm_clear_cart',
			'wc_stm_show_countdown'          => 'kagstm_show_countdown',
			'wc_stm_enable_waitlist'         => 'kagstm_enable_waitlist',
			'wc_stm_admin_alerts'            => 'kagstm_admin_alerts',
			'wc_stm_broadcast_complete'      => 'kagstm_broadcast_complete',
			'wc_stm_broadcast_subject'       => 'kagstm_broadcast_subject',
			'wc_stm_broadcast_body'          => 'kagstm_broadcast_body',
			'wc_stm_bypass_roles'            => 'kagstm_bypass_roles',
			'wc_stm_product_exceptions'      => 'kagstm_product_exceptions',
			'wc_stm_last_known_state'        => 'kagstm_last_known_state',
			'wc_stm_stat_blocked_attempts'   => 'kagstm_stat_blocked_attempts',
			'wc_stm_subscriber_waitlist_v2'  => 'kagstm_subscriber_waitlist',
		);

		foreach ( $legacy_map as $old_key => $new_key ) {
			$old_value = get_option( $old_key, null );
			if ( null !== $old_value && false === get_option( $new_key, false ) ) {
				update_option( $new_key, $old_value );
			}
		}

		update_option( 'kagstm_legacy_migration_done', '1' );
		KAGSTM_Logger::log( 'Legacy "wc_stm_" settings migrated to the "kagstm_" prefix after the plugin rename.', 'info' );
	}

	/**
	 * Register the WooCommerce submenu page.
	 */
	public function register_admin_menu() {
		add_submenu_page(
			'woocommerce',
			__( 'Stock Take Mode', 'kagunda-stock-take-mode-for-woocommerce' ),
			__( 'Stock Take Mode', 'kagunda-stock-take-mode-for-woocommerce' ),
			'manage_options',
			'kagstm-settings',
			array( $this, 'render_settings_page' )
		);
	}

	/**
	 * Register all plugin settings with their sanitization callbacks.
	 */
	public function register_settings_fields() {
		$settings = array(
			'kagstm_enabled'                  => 'sanitize_text_field',
			'kagstm_start_datetime'           => 'sanitize_text_field',
			'kagstm_end_datetime'             => 'sanitize_text_field',
			'kagstm_message'                  => 'wp_kses_post',
			'kagstm_button_behavior'          => 'sanitize_text_field',
			'kagstm_button_text'              => 'sanitize_text_field',
			'kagstm_bg_color'                 => 'sanitize_hex_color',
			'kagstm_text_color'               => 'sanitize_hex_color',
			'kagstm_clear_cart'               => 'sanitize_text_field',
			'kagstm_show_countdown'           => 'sanitize_text_field',
			'kagstm_enable_waitlist'          => 'sanitize_text_field',
			'kagstm_admin_alerts'             => 'sanitize_text_field',
			'kagstm_show_admin_bar_indicator' => 'sanitize_text_field',
			'kagstm_broadcast_complete'       => 'sanitize_text_field',
			'kagstm_broadcast_subject'        => 'sanitize_text_field',
			'kagstm_broadcast_body'           => 'wp_kses_post',
			'kagstm_bypass_roles'             => array( $this, 'sanitize_array_values' ),
			'kagstm_product_exceptions'       => array( $this, 'sanitize_id_array' ),
			'kagstm_category_exceptions'      => array( $this, 'sanitize_id_array' ),
		);

		foreach ( $settings as $option_name => $sanitize_callback ) {
			register_setting( 'kagstm_settings_group', $option_name, $sanitize_callback );
		}
	}

	/**
	 * Sanitize an array of free-text values (e.g. role slugs).
	 *
	 * @param mixed $input Raw input.
	 * @return array
	 */
	public function sanitize_array_values( $input ) {
		return is_array( $input ) ? array_map( 'sanitize_text_field', $input ) : array();
	}

	/**
	 * Sanitize an array of numeric IDs (products or categories).
	 *
	 * @param mixed $input Raw input.
	 * @return array
	 */
	public function sanitize_id_array( $input ) {
		return is_array( $input ) ? array_values( array_filter( array_map( 'absint', $input ) ) ) : array();
	}

	/**
	 * Render admin notices for this plugin's screens.
	 */
	public function render_admin_notices() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only screen check, no data is processed.
		if ( ! isset( $_GET['page'] ) || 'kagstm-settings' !== sanitize_text_field( wp_unslash( $_GET['page'] ) ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only flag added by WordPress core's own settings API redirect.
		if ( isset( $_GET['settings-updated'] ) && 'true' === sanitize_text_field( wp_unslash( $_GET['settings-updated'] ) ) ) {
			?>
			<div class="notice notice-success is-dismissible">
				<p><?php esc_html_e( 'Stock Take Mode settings saved.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></p>
			</div>
			<?php
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only flag set by our own admin_init redirect after the nonce-verified import in handle_settings_import().
		if ( isset( $_GET['kagstm_import'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			if ( 'success' === sanitize_text_field( wp_unslash( $_GET['kagstm_import'] ) ) ) {
				?>
				<div class="notice notice-success is-dismissible">
					<p><?php esc_html_e( 'Configuration imported successfully.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></p>
				</div>
				<?php
			} else {
				?>
				<div class="notice notice-error is-dismissible">
					<p><?php esc_html_e( 'The configuration file could not be imported. Please check the file and try again.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></p>
				</div>
				<?php
			}
		}
	}

	/**
	 * Hook the store-facing restrictions on, track state transitions, and
	 * send the relevant notifications when stock-take mode starts or ends.
	 */
	public function maybe_init_restrictions() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		$is_active  = $this->is_stock_take_active();
		$last_state = get_option( 'kagstm_last_known_state', 'inactive' );

		if ( $is_active && 'inactive' === $last_state ) {
			update_option( 'kagstm_last_known_state', 'active' );
			KAGSTM_Logger::log( 'Stock Take Mode started.', 'info' );
			$this->send_admin_status_email( __( 'Initiated', 'kagunda-stock-take-mode-for-woocommerce' ) );
		} elseif ( ! $is_active && 'active' === $last_state ) {
			update_option( 'kagstm_last_known_state', 'inactive' );
			KAGSTM_Logger::log( 'Stock Take Mode ended.', 'info' );
			$this->send_admin_status_email( __( 'Expired / Deactivated', 'kagunda-stock-take-mode-for-woocommerce' ) );
			$this->maybe_broadcast_stock_take_completion();
		}

		if ( $is_active ) {
			$this->init_restrictions();
		}
	}

	/**
	 * Whether stock-take restrictions should currently be enforced for the
	 * current visitor.
	 *
	 * @return bool
	 */
	public function is_stock_take_active() {
		if ( '1' !== get_option( 'kagstm_enabled', '0' ) ) {
			return false;
		}

		if ( is_user_logged_in() ) {
			$current_user = wp_get_current_user();
			$bypass_roles = get_option( 'kagstm_bypass_roles', array( 'administrator', 'shop_manager' ) );
			if ( array_intersect( $current_user->roles, (array) $bypass_roles ) ) {
				return false;
			}
		}

		$start_dt_string = get_option( 'kagstm_start_datetime', '' );
		$end_dt_string   = get_option( 'kagstm_end_datetime', '' );

		if ( empty( $start_dt_string ) && empty( $end_dt_string ) ) {
			return true;
		}

		$timezone_string = function_exists( 'wc_timezone_string' ) ? wc_timezone_string() : wp_timezone_string();

		try {
			$timezone = new DateTimeZone( $timezone_string );
			$now      = new DateTimeImmutable( 'now', $timezone );

			if ( ! empty( $start_dt_string ) ) {
				$start_dt = new DateTimeImmutable( $start_dt_string, $timezone );
				if ( $now < $start_dt ) {
					return false;
				}
			}

			if ( ! empty( $end_dt_string ) ) {
				$end_dt = new DateTimeImmutable( $end_dt_string, $timezone );
				if ( $now > $end_dt ) {
					return false;
				}
			}
			return true;
		} catch ( Exception $e ) {
			$current_timestamp = current_time( 'timestamp' );
			if ( ! empty( $start_dt_string ) && $current_timestamp < strtotime( $start_dt_string ) ) {
				return false;
			}
			if ( ! empty( $end_dt_string ) && $current_timestamp > strtotime( $end_dt_string ) ) {
				return false;
			}
			return true;
		}
	}

	/**
	 * Get the list of product IDs excluded from restrictions, including
	 * every product that belongs to an excluded category.
	 *
	 * @return int[]
	 */
	private function get_effective_product_exceptions() {
		$product_exceptions  = (array) get_option( 'kagstm_product_exceptions', array() );
		$category_exceptions = (array) get_option( 'kagstm_category_exceptions', array() );

		if ( ! empty( $category_exceptions ) ) {
			$cached_key = 'kagstm_category_product_ids_cache';
			$cached     = get_transient( $cached_key );

			if ( false === $cached ) {
				$product_ids = get_posts(
					array(
						'post_type'      => 'product',
						'posts_per_page' => -1,
						'fields'         => 'ids',
						'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
							array(
								'taxonomy' => 'product_cat',
								'field'    => 'term_id',
								'terms'    => $category_exceptions,
							),
						),
					)
				);
				set_transient( $cached_key, $product_ids, 5 * MINUTE_IN_SECONDS );
				$cached = $product_ids;
			}

			$product_exceptions = array_merge( $product_exceptions, $cached );
		}

		return array_unique( array_map( 'absint', $product_exceptions ) );
	}

	/**
	 * Attach the storefront restriction hooks.
	 */
	private function init_restrictions() {
		add_filter( 'woocommerce_is_purchasable', array( $this, 'restrict_purchasable' ), 999, 2 );
		add_filter( 'woocommerce_variation_is_purchasable', array( $this, 'restrict_purchasable' ), 999, 2 );
		add_filter( 'woocommerce_add_to_cart_validation', array( $this, 'block_add_to_cart' ), 999, 3 );
		add_filter( 'woocommerce_store_api_is_purchasable', array( $this, 'restrict_purchasable' ), 999, 2 );
		add_filter( 'woocommerce_store_api_checkout_is_allowed', '__return_false', 999 );

		add_action( 'wp_ajax_woocommerce_add_to_cart', array( $this, 'block_ajax_add_to_cart' ), 1 );
		add_action( 'wp_ajax_nopriv_woocommerce_add_to_cart', array( $this, 'block_ajax_add_to_cart' ), 1 );

		add_action( 'wp', array( $this, 'apply_button_behavior_modifications' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_frontend_assets' ) );
		add_action( 'template_redirect', array( $this, 'restrict_checkout_page' ) );
		add_action( 'woocommerce_init', array( $this, 'maybe_clear_active_carts' ) );

		add_action( 'wp_body_open', array( $this, 'render_global_notice_banner' ), 1 );
	}

	/**
	 * Remove non-excluded items from every active cart while restrictions
	 * are in effect.
	 */
	public function maybe_clear_active_carts() {
		if ( '1' !== get_option( 'kagstm_clear_cart', '0' ) || ! WC()->cart ) {
			return;
		}

		$exceptions = $this->get_effective_product_exceptions();
		foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
			if ( ! in_array( $cart_item['product_id'], $exceptions, true ) ) {
				WC()->cart->remove_cart_item( $cart_item_key );
			}
		}
	}

	/**
	 * Filter callback: is a product purchasable while restrictions are active?
	 *
	 * @param bool       $purchasable Current purchasable state.
	 * @param WC_Product $product     Product object.
	 * @return bool
	 */
	public function restrict_purchasable( $purchasable, $product ) {
		if ( ! $product ) {
			return $purchasable;
		}

		$exceptions = $this->get_effective_product_exceptions();
		if ( in_array( $product->get_id(), $exceptions, true ) || in_array( $product->get_parent_id(), $exceptions, true ) ) {
			return $purchasable;
		}
		return false;
	}

	/**
	 * Block classic add-to-cart submissions unless the product is excepted.
	 *
	 * @param bool $passed     Whether validation currently passes.
	 * @param int  $product_id Product ID being added.
	 * @param int  $quantity   Quantity requested.
	 * @return bool
	 */
	public function block_add_to_cart( $passed, $product_id, $quantity ) {
		$exceptions = $this->get_effective_product_exceptions();
		if ( in_array( $product_id, $exceptions, true ) ) {
			return $passed;
		}

		$this->increment_counter( 'kagstm_stat_blocked_attempts' );
		wc_add_notice( wp_kses_post( $this->get_stock_take_message() ), 'error' );
		return false;
	}

	/**
	 * Block the legacy AJAX add-to-cart endpoint unless the product is excepted.
	 */
	public function block_ajax_add_to_cart() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- intercepting WooCommerce's own "woocommerce_add_to_cart" AJAX action; WooCommerce performs its own nonce check further down the line if we allow the request through.
		$product_id = isset( $_REQUEST['product_id'] ) ? absint( $_REQUEST['product_id'] ) : 0;
		$exceptions = $this->get_effective_product_exceptions();

		if ( $product_id && in_array( $product_id, $exceptions, true ) ) {
			return;
		}

		$this->increment_counter( 'kagstm_stat_blocked_attempts' );
		wp_send_json(
			array(
				'error'  => true,
				'notice' => wp_kses_post( $this->get_stock_take_message() ),
			)
		);
	}

	/**
	 * Get the customer-facing restriction message.
	 *
	 * @return string
	 */
	private function get_stock_take_message() {
		$custom_message = get_option( 'kagstm_message', '' );
		if ( ! empty( $custom_message ) ) {
			return $custom_message;
		}
		return __( 'Sorry, we are closed for stock intake.', 'kagunda-stock-take-mode-for-woocommerce' );
	}

	/**
	 * Prevent checkout completion while restrictions are active.
	 */
	public function restrict_checkout_page() {
		if ( ! is_checkout() || is_order_received_page() || ! WC()->cart ) {
			return;
		}

		$exceptions = $this->get_effective_product_exceptions();
		foreach ( WC()->cart->get_cart() as $item ) {
			if ( ! in_array( $item['product_id'], $exceptions, true ) ) {
				$this->increment_counter( 'kagstm_stat_blocked_attempts' );
				wc_add_notice( wp_kses_post( $this->get_stock_take_message() ), 'error' );
				wp_safe_redirect( wc_get_cart_url() );
				exit;
			}
		}
	}

	/**
	 * Apply the configured add-to-cart button behavior.
	 */
	public function apply_button_behavior_modifications() {
		$behavior = get_option( 'kagstm_button_behavior', 'hide' );

		if ( 'hide' === $behavior ) {
			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
			remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );
			add_filter( 'woocommerce_loop_add_to_cart_link', '__return_empty_string', 999 );
		} elseif ( 'disable_text' === $behavior ) {
			add_filter( 'woocommerce_product_single_add_to_cart_text', array( $this, 'filter_button_label_copy' ), 999 );
			add_filter( 'woocommerce_product_add_to_cart_text', array( $this, 'filter_button_label_copy' ), 999 );
			add_filter( 'woocommerce_loop_add_to_cart_link', array( $this, 'render_deactivated_loop_element' ), 999, 2 );
		}
		// 'inactive_only' is handled entirely client-side via the enqueued frontend script.
	}

	/**
	 * Filter callback: override the add-to-cart button label.
	 *
	 * @param string $text Original label.
	 * @return string
	 */
	public function filter_button_label_copy( $text ) {
		return esc_html( get_option( 'kagstm_button_text', __( 'Stock Take Active', 'kagunda-stock-take-mode-for-woocommerce' ) ) );
	}

	/**
	 * Filter callback: render a disabled loop add-to-cart link.
	 *
	 * @param string     $html    Original markup.
	 * @param WC_Product $product Product object.
	 * @return string
	 */
	public function render_deactivated_loop_element( $html, $product ) {
		$text = get_option( 'kagstm_button_text', __( 'Stock Take Active', 'kagunda-stock-take-mode-for-woocommerce' ) );
		return sprintf(
			'<a href="%1$s" class="button product_type_%2$s disabled kagstm-disabled-loop-button">%3$s</a>',
			esc_url( $product->get_permalink() ),
			esc_attr( $product->get_type() ),
			esc_html( $text )
		);
	}

	/**
	 * Render the sticky notice banner in wp_body_open.
	 */
	public function render_global_notice_banner() {
		$message = $this->get_stock_take_message();
		if ( empty( $message ) ) {
			return;
		}

		$end_dt_string   = get_option( 'kagstm_end_datetime', '' );
		$countdown       = get_option( 'kagstm_show_countdown', '0' );
		$enable_waitlist = get_option( 'kagstm_enable_waitlist', '0' );
		$target_iso      = '';

		if ( '1' === $countdown && ! empty( $end_dt_string ) ) {
			$timezone_string = function_exists( 'wc_timezone_string' ) ? wc_timezone_string() : wp_timezone_string();
			try {
				$timezone   = new DateTimeZone( $timezone_string );
				$end_dt     = new DateTimeImmutable( $end_dt_string, $timezone );
				$target_iso = $end_dt->format( 'c' );
			} catch ( Exception $e ) {
				$target_iso = gmdate( 'c', strtotime( $end_dt_string ) );
			}
		}
		?>
		<div class="kagstm-top-banner-wrapper">
			<div class="kagstm-top-banner-content">
				<span class="kagstm-banner-icon" aria-hidden="true">🛡️</span>
				<div class="kagstm-banner-text-inner"><?php echo wp_kses_post( $message ); ?></div>

				<?php if ( ! empty( $target_iso ) ) : ?>
					<div class="kagstm-countdown-container" data-deadline="<?php echo esc_attr( $target_iso ); ?>">
						<span class="kagstm-time-segment"><b class="days">00</b>d</span>
						<span class="kagstm-time-segment"><b class="hours">00</b>h</span>
						<span class="kagstm-time-segment"><b class="minutes">00</b>m</span>
						<span class="kagstm-time-segment"><b class="seconds">00</b>s</span>
					</div>
				<?php endif; ?>

				<?php if ( '1' === $enable_waitlist ) : ?>
					<div class="kagstm-waitlist-form-wrap">
						<input type="email" id="kagstm-subscriber-email" placeholder="<?php esc_attr_e( 'Notify me when open...', 'kagunda-stock-take-mode-for-woocommerce' ); ?>" required />
						<button type="button" id="kagstm-subscribe-btn"><?php esc_html_e( 'Join Waitlist', 'kagunda-stock-take-mode-for-woocommerce' ); ?></button>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * AJAX handler: capture a waitlist email address.
	 */
	public function handle_banner_subscription() {
		check_ajax_referer( 'kagstm-subscribe-nonce', 'nonce' );

		$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		if ( ! is_email( $email ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid email address.', 'kagunda-stock-take-mode-for-woocommerce' ) ) );
		}

		$subscribers = (array) get_option( 'kagstm_subscriber_waitlist', array() );

		$exists = false;
		foreach ( $subscribers as $sub ) {
			if ( $sub['email'] === $email ) {
				$exists = true;
				break;
			}
		}

		if ( ! $exists ) {
			$subscribers[] = array(
				'email' => $email,
				'date'  => current_time( 'mysql' ),
			);
			update_option( 'kagstm_subscriber_waitlist', $subscribers );
		}

		wp_send_json_success( array( 'message' => __( 'Success! You will be notified immediately.', 'kagunda-stock-take-mode-for-woocommerce' ) ) );
	}

	/**
	 * Compile the {token} placeholders in an email subject/body.
	 *
	 * @param string $subject_tpl     Subject template.
	 * @param string $body_tpl        Body template.
	 * @param string $recipient_email Recipient's email address.
	 * @return array{subject:string,body:string}
	 */
	private function get_compiled_email_template( $subject_tpl, $body_tpl, $recipient_email ) {
		$site_name = get_bloginfo( 'name' );
		$site_url  = home_url();

		if ( empty( $subject_tpl ) ) {
			$subject_tpl = __( 'Stock Count Completed - We Are Open!', 'kagunda-stock-take-mode-for-woocommerce' );
		}
		if ( empty( $body_tpl ) ) {
			$body_tpl = __( 'Hello,<br><br>Great news! Our scheduled stock intake has concluded successfully. Ordering and checkout are fully back online.<br><br>Visit our catalog here: <a href="{site_url}">{site_name}</a><br><br>Thank you for your patience!', 'kagunda-stock-take-mode-for-woocommerce' );
		}

		$tokens = array(
			'{site_name}'      => $site_name,
			'{site_url}'       => esc_url( $site_url ),
			'{customer_email}' => esc_html( $recipient_email ),
		);

		return array(
			'subject' => str_replace( array_keys( $tokens ), array_values( $tokens ), $subject_tpl ),
			'body'    => str_replace( array_keys( $tokens ), array_values( $tokens ), $body_tpl ),
		);
	}

	/**
	 * Email every waitlist subscriber once stock-take mode ends, then clear
	 * the list.
	 */
	private function maybe_broadcast_stock_take_completion() {
		if ( '1' !== get_option( 'kagstm_broadcast_complete', '0' ) ) {
			return;
		}

		$subscribers = (array) get_option( 'kagstm_subscriber_waitlist', array() );
		if ( empty( $subscribers ) ) {
			return;
		}

		$subject_template = get_option( 'kagstm_broadcast_subject', '' );
		$body_template    = get_option( 'kagstm_broadcast_body', '' );
		$headers          = array( 'Content-Type: text/html; charset=UTF-8' );
		$sent_count       = 0;

		foreach ( $subscribers as $subscriber ) {
			$compiled = $this->get_compiled_email_template( $subject_template, $body_template, $subscriber['email'] );
			if ( wp_mail( $subscriber['email'], $compiled['subject'], $compiled['body'], $headers ) ) {
				++$sent_count;
			}
		}

		KAGSTM_Logger::log( sprintf( 'Re-open broadcast sent to %1$d of %2$d waitlist subscribers.', $sent_count, count( $subscribers ) ), 'info' );

		delete_option( 'kagstm_subscriber_waitlist' );
	}

	/**
	 * AJAX handler: send a preview of the broadcast email to a test address.
	 */
	public function handle_admin_test_email() {
		check_ajax_referer( 'kagstm-admin-nonce', 'security' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized', 'kagunda-stock-take-mode-for-woocommerce' ) ) );
		}

		$test_email       = isset( $_POST['test_email'] ) ? sanitize_email( wp_unslash( $_POST['test_email'] ) ) : get_option( 'admin_email' );
		$subject_template = isset( $_POST['subject'] ) ? sanitize_text_field( wp_unslash( $_POST['subject'] ) ) : '';
		$body_template    = isset( $_POST['body'] ) ? wp_kses_post( wp_unslash( $_POST['body'] ) ) : '';

		if ( ! is_email( $test_email ) ) {
			wp_send_json_error( array( 'message' => __( 'Please provide a valid test email address.', 'kagunda-stock-take-mode-for-woocommerce' ) ) );
		}

		$compiled = $this->get_compiled_email_template( $subject_template, $body_template, $test_email );
		$headers  = array( 'Content-Type: text/html; charset=UTF-8' );

		/* translators: %s: subject line of the test email. */
		$sent = wp_mail( $test_email, sprintf( __( '[TEST] %s', 'kagunda-stock-take-mode-for-woocommerce' ), $compiled['subject'] ), $compiled['body'], $headers );

		if ( $sent ) {
			/* translators: %s: email address the test message was sent to. */
			wp_send_json_success( array( 'message' => sprintf( __( 'Test broadcast email sent to %s.', 'kagunda-stock-take-mode-for-woocommerce' ), $test_email ) ) );
		} else {
			wp_send_json_error( array( 'message' => __( 'The server rejected sending the email. Check your mail settings.', 'kagunda-stock-take-mode-for-woocommerce' ) ) );
		}
	}

	/**
	 * Stream the waitlist as a CSV download.
	 */
	public function handle_csv_export() {
		if ( ! isset( $_GET['action'] ) || 'kagstm_export_csv' !== $_GET['action'] ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized access.', 'kagunda-stock-take-mode-for-woocommerce' ) );
		}
		check_admin_referer( 'kagstm_csv_download', 'nonce' );

		$subscribers = (array) get_option( 'kagstm_subscriber_waitlist', array() );

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=stock-take-waitlist-' . gmdate( 'Y-m-d' ) . '.csv' );

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		$output = fopen( 'php://output', 'w' );
		fputcsv( $output, array( 'Email Address', 'Date Subscribed' ) );

		foreach ( $subscribers as $sub ) {
			fputcsv( $output, array( $sub['email'], $sub['date'] ) );
		}
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		fclose( $output );
		exit;
	}

	/**
	 * Stream the current settings as a downloadable JSON file.
	 */
	public function handle_settings_export() {
		if ( ! isset( $_GET['action'] ) || 'kagstm_export_settings' !== $_GET['action'] ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized access.', 'kagunda-stock-take-mode-for-woocommerce' ) );
		}
		check_admin_referer( 'kagstm_settings_export', 'nonce' );

		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=stock-take-mode-settings-' . gmdate( 'Y-m-d' ) . '.json' );
		echo KAGSTM_Import_Export::export_json(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	/**
	 * Handle an uploaded settings JSON file and apply it.
	 */
	public function handle_settings_import() {
		if ( ! isset( $_POST['kagstm_import_nonce'] ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized access.', 'kagunda-stock-take-mode-for-woocommerce' ) );
		}
		check_admin_referer( 'kagstm_settings_import', 'kagstm_import_nonce' );

		$redirect = admin_url( 'admin.php?page=kagstm-settings' );

		if ( ! isset( $_FILES['kagstm_import_file'] ) || ! is_array( $_FILES['kagstm_import_file'] ) ) {
			wp_safe_redirect( add_query_arg( 'kagstm_import', 'error', $redirect ) );
			exit;
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- file upload error code, sanitized with absint() below.
		$upload_error = isset( $_FILES['kagstm_import_file']['error'] ) ? absint( $_FILES['kagstm_import_file']['error'] ) : UPLOAD_ERR_NO_FILE;
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- server-generated temp path, sanitized with sanitize_text_field() and validated with is_uploaded_file() below.
		$tmp_name = isset( $_FILES['kagstm_import_file']['tmp_name'] ) ? sanitize_text_field( wp_unslash( $_FILES['kagstm_import_file']['tmp_name'] ) ) : '';

		if ( UPLOAD_ERR_OK !== $upload_error || empty( $tmp_name ) || ! is_uploaded_file( $tmp_name ) ) {
			wp_safe_redirect( add_query_arg( 'kagstm_import', 'error', $redirect ) );
			exit;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_get_contents -- reading a just-validated PHP temp upload, not an arbitrary path.
		$json   = file_get_contents( $tmp_name );
		$result = KAGSTM_Import_Export::import_json( $json );

		if ( is_wp_error( $result ) ) {
			KAGSTM_Logger::log( 'Settings import failed: ' . $result->get_error_message(), 'warning' );
			wp_safe_redirect( add_query_arg( 'kagstm_import', 'error', $redirect ) );
			exit;
		}

		KAGSTM_Logger::log( 'Settings imported from an uploaded configuration file.', 'info' );
		wp_safe_redirect( add_query_arg( 'kagstm_import', 'success', $redirect ) );
		exit;
	}

	/**
	 * Send an operational status email to the store admin.
	 *
	 * @param string $status Human-readable status label.
	 */
	private function send_admin_status_email( $status ) {
		if ( '1' !== get_option( 'kagstm_admin_alerts', '0' ) ) {
			return;
		}

		$to = get_option( 'admin_email' );
		/* translators: %s: status label, e.g. "Initiated". */
		$subject = sprintf( __( '[%1$s] Stock Take Mode Alert: %2$s', 'kagunda-stock-take-mode-for-woocommerce' ), get_bloginfo( 'name' ), $status );
		$body    = sprintf(
			/* translators: 1: status label, 2: timestamp. */
			__( 'Hello,<br><br>Stock Take Mode is now: <b>%1$s</b>.<br><br>Timestamp: %2$s', 'kagunda-stock-take-mode-for-woocommerce' ),
			esc_html( $status ),
			esc_html( current_time( 'mysql' ) )
		);
		$headers = array( 'Content-Type: text/html; charset=UTF-8' );

		wp_mail( $to, $subject, $body, $headers );
	}

	/**
	 * Increment a stored counter option by one.
	 *
	 * @param string $option_name Option name.
	 */
	private function increment_counter( $option_name ) {
		$count = (int) get_option( $option_name, 0 );
		update_option( $option_name, $count + 1 );
	}

	/**
	 * Register the dashboard analytics widget.
	 */
	public function register_dashboard_analytics_widget() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		wp_add_dashboard_widget(
			'kagstm_analytics_dashboard_widget',
			__( 'Stock Take Mode Analytics', 'kagunda-stock-take-mode-for-woocommerce' ),
			array( $this, 'render_dashboard_analytics_widget' )
		);
	}

	/**
	 * Render the dashboard analytics widget contents.
	 */
	public function render_dashboard_analytics_widget() {
		$blocked     = get_option( 'kagstm_stat_blocked_attempts', 0 );
		$subscribers = count( (array) get_option( 'kagstm_subscriber_waitlist', array() ) );
		$is_active   = $this->is_stock_take_active();
		?>
		<div class="kagstm-dashboard-widget">
			<p><?php esc_html_e( 'Activity tracked while Stock Take Mode has been running.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></p>
			<div style="display:grid; grid-template-columns: 1fr 1fr; gap:12px; text-align:center;">
				<div style="background:#f8fafc; padding:12px; border-radius:6px; border:1px solid #e2e8f0;">
					<span style="display:block; font-size:20px; font-weight:bold; color:#e11d48;"><?php echo esc_html( $blocked ); ?></span>
					<span style="font-size:11px; color:#64748b; font-weight:600;"><?php esc_html_e( 'Blocked Attempts', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span>
				</div>
				<div style="background:#f8fafc; padding:12px; border-radius:6px; border:1px solid #e2e8f0;">
					<span style="display:block; font-size:20px; font-weight:bold; color:#3b82f6;"><?php echo esc_html( $subscribers ); ?></span>
					<span style="font-size:11px; color:#64748b; font-weight:600;"><?php esc_html_e( 'Waitlist Subscribers', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span>
				</div>
			</div>
			<p style="margin-top:15px; font-size:12px; border-top:1px solid #eee; padding-top:10px;">
				<?php esc_html_e( 'Current state:', 'kagunda-stock-take-mode-for-woocommerce' ); ?>
				<?php if ( $is_active ) : ?>
					<strong style="color:#10b981;"><?php esc_html_e( 'Active', 'kagunda-stock-take-mode-for-woocommerce' ); ?></strong>
				<?php else : ?>
					<span style="color:#64748b;"><?php esc_html_e( 'Standby', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span>
				<?php endif; ?>
			</p>
		</div>
		<?php
	}

	/**
	 * Add a quick-status indicator (and toggle link) to the admin bar while
	 * stock-take mode is active.
	 *
	 * @param WP_Admin_Bar $wp_admin_bar Admin bar instance.
	 */
	public function render_admin_bar_indicator( $wp_admin_bar ) {
		if ( ! current_user_can( 'manage_options' ) || '1' !== get_option( 'kagstm_show_admin_bar_indicator', '1' ) ) {
			return;
		}

		if ( ! class_exists( 'WooCommerce' ) || ! $this->is_stock_take_active() ) {
			return;
		}

		$wp_admin_bar->add_node(
			array(
				'id'    => 'kagstm-status-indicator',
				'title' => '🛡️ ' . esc_html__( 'Stock Take Mode Active', 'kagunda-stock-take-mode-for-woocommerce' ),
				'href'  => esc_url( admin_url( 'admin.php?page=kagstm-settings' ) ),
				'meta'  => array( 'title' => esc_attr__( 'Purchasing is currently restricted. Click to manage.', 'kagunda-stock-take-mode-for-woocommerce' ) ),
			)
		);
	}

	/**
	 * Enqueue the frontend banner styles/scripts, only when restrictions
	 * are actually in effect.
	 */
	public function enqueue_frontend_assets() {
		wp_enqueue_style( 'kagstm-frontend', KAGSTM_PLUGIN_URL . 'assets/css/frontend.css', array(), KAGSTM_VERSION );

		$bg   = get_option( 'kagstm_bg_color', '#e11d48' );
		$text = get_option( 'kagstm_text_color', '#ffffff' );
		wp_add_inline_style(
			'kagstm-frontend',
			sprintf( ':root{--kagstm-bg:%1$s;--kagstm-text:%2$s;}', esc_attr( $bg ), esc_attr( $text ) )
		);

		wp_enqueue_script( 'kagstm-frontend', KAGSTM_PLUGIN_URL . 'assets/js/frontend.js', array(), KAGSTM_VERSION, true );

		wp_localize_script(
			'kagstm-frontend',
			'KAGSTM_Frontend',
			array(
				'ajaxUrl'        => admin_url( 'admin-ajax.php' ),
				'subscribeNonce' => wp_create_nonce( 'kagstm-subscribe-nonce' ),
				'buttonBehavior' => get_option( 'kagstm_button_behavior', 'hide' ),
				'i18n'           => array(
					'invalidEmail'    => __( 'Please enter a valid email address.', 'kagunda-stock-take-mode-for-woocommerce' ),
					'joining'         => __( 'Joining...', 'kagunda-stock-take-mode-for-woocommerce' ),
					'joinWaitlist'    => __( 'Join Waitlist', 'kagunda-stock-take-mode-for-woocommerce' ),
					'subscribeError'  => __( 'Subscription error. Please try again.', 'kagunda-stock-take-mode-for-woocommerce' ),
					'orderingFrozen'  => __( 'Ordering is currently paused for stock take.', 'kagunda-stock-take-mode-for-woocommerce' ),
				),
			)
		);
	}

	/**
	 * AJAX handler: product search used to populate the exceptions select field.
	 */
	public function ajax_search_products() {
		check_ajax_referer( 'kagstm-admin-nonce', 'security' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized' );
		}

		$term = isset( $_GET['term'] ) ? sanitize_text_field( wp_unslash( $_GET['term'] ) ) : '';
		if ( empty( $term ) ) {
			wp_send_json( array() );
		}

		$data_store = WC_Data_Store::load( 'product' );
		$ids        = $data_store->search_products( $term, '', true, false );
		$results    = array();

		foreach ( $ids as $id ) {
			$product = wc_get_product( $id );
			if ( $product ) {
				$results[] = array(
					'id'   => $id,
					'text' => $product->get_name() . ' (#' . $id . ')',
				);
			}
		}
		wp_send_json( $results );
	}

	/**
	 * Enqueue admin settings screen assets.
	 *
	 * @param string $hook Current admin page hook suffix.
	 */
	public function enqueue_admin_assets( $hook ) {
		if ( false === strpos( $hook, 'kagstm-settings' ) ) {
			return;
		}

		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_style( 'kagstm-select2', KAGSTM_PLUGIN_URL . 'assets/css/vendor/select2.min.css', array(), '4.1.0' );
		wp_enqueue_style( 'kagstm-admin', KAGSTM_PLUGIN_URL . 'assets/css/admin.css', array(), KAGSTM_VERSION );

		wp_enqueue_script( 'wp-color-picker' );
		wp_enqueue_script( 'kagstm-select2', KAGSTM_PLUGIN_URL . 'assets/js/vendor/select2.min.js', array( 'jquery' ), '4.1.0', true );
		wp_enqueue_script( 'kagstm-admin', KAGSTM_PLUGIN_URL . 'assets/js/admin.js', array( 'jquery', 'wp-color-picker', 'kagstm-select2' ), KAGSTM_VERSION, true );

		wp_localize_script(
			'kagstm-admin',
			'KAGSTM_Admin',
			array(
				'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
				'searchNonce'  => wp_create_nonce( 'kagstm-admin-nonce' ),
				'i18n'         => array(
					'searchProducts'   => __( 'Search exceptions...', 'kagunda-stock-take-mode-for-woocommerce' ),
					'searchCategories' => __( 'Search categories...', 'kagunda-stock-take-mode-for-woocommerce' ),
					'dispatching'      => __( 'Sending...', 'kagunda-stock-take-mode-for-woocommerce' ),
					'testEmailFailed'  => __( 'The test email request failed.', 'kagunda-stock-take-mode-for-woocommerce' ),
				),
			)
		);
	}

	/**
	 * Build a status badge for the settings screen.
	 *
	 * @param string $start Start datetime string.
	 * @param string $end   End datetime string.
	 * @return array{class:string,label:string}
	 */
	private function get_datetime_status_badge( $start, $end ) {
		if ( '1' !== get_option( 'kagstm_enabled', '0' ) ) {
			return array( 'class' => 'kagstm-status-disabled', 'label' => __( 'Disabled', 'kagunda-stock-take-mode-for-woocommerce' ) );
		}
		if ( empty( $start ) && empty( $end ) ) {
			return array( 'class' => 'kagstm-status-always-live', 'label' => __( 'Always Active', 'kagunda-stock-take-mode-for-woocommerce' ) );
		}

		$timezone_string = function_exists( 'wc_timezone_string' ) ? wc_timezone_string() : wp_timezone_string();

		try {
			$timezone = new DateTimeZone( $timezone_string );
			$now      = new DateTimeImmutable( 'now', $timezone );

			if ( ! empty( $start ) ) {
				$start_dt = new DateTimeImmutable( $start, $timezone );
				if ( $now < $start_dt ) {
					return array( 'class' => 'kagstm-status-standby', 'label' => __( 'Waiting for Start', 'kagunda-stock-take-mode-for-woocommerce' ) );
				}
			}
			if ( ! empty( $end ) ) {
				$end_dt = new DateTimeImmutable( $end, $timezone );
				if ( $now > $end_dt ) {
					return array( 'class' => 'kagstm-status-expired', 'label' => __( 'Expired', 'kagunda-stock-take-mode-for-woocommerce' ) );
				}
			}
			return array( 'class' => 'kagstm-status-active', 'label' => __( 'Active Now', 'kagunda-stock-take-mode-for-woocommerce' ) );
		} catch ( Exception $e ) {
			return array( 'class' => 'kagstm-status-unknown', 'label' => __( 'Unknown', 'kagunda-stock-take-mode-for-woocommerce' ) );
		}
	}

	/**
	 * Render the settings page.
	 */
	public function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$enabled                  = get_option( 'kagstm_enabled', '0' );
		$start_datetime           = get_option( 'kagstm_start_datetime', '' );
		$end_datetime             = get_option( 'kagstm_end_datetime', '' );
		$message                  = get_option( 'kagstm_message', '' );
		$button_behavior          = get_option( 'kagstm_button_behavior', 'hide' );
		$button_text              = get_option( 'kagstm_button_text', __( 'Stock Take Active', 'kagunda-stock-take-mode-for-woocommerce' ) );
		$bypass_roles             = get_option( 'kagstm_bypass_roles', array( 'administrator', 'shop_manager' ) );
		$bg_color                 = get_option( 'kagstm_bg_color', '#e11d48' );
		$text_color               = get_option( 'kagstm_text_color', '#ffffff' );
		$clear_cart               = get_option( 'kagstm_clear_cart', '0' );
		$show_countdown           = get_option( 'kagstm_show_countdown', '0' );
		$enable_waitlist          = get_option( 'kagstm_enable_waitlist', '0' );
		$admin_alerts             = get_option( 'kagstm_admin_alerts', '0' );
		$show_admin_bar_indicator = get_option( 'kagstm_show_admin_bar_indicator', '1' );
		$broadcast_complete       = get_option( 'kagstm_broadcast_complete', '0' );
		$broadcast_subject        = get_option( 'kagstm_broadcast_subject', __( 'Stock Count Completed - We Are Open!', 'kagunda-stock-take-mode-for-woocommerce' ) );
		$broadcast_body           = get_option( 'kagstm_broadcast_body', '' );
		$product_exceptions       = (array) get_option( 'kagstm_product_exceptions', array() );
		$category_exceptions      = (array) get_option( 'kagstm_category_exceptions', array() );
		$subscribers              = (array) get_option( 'kagstm_subscriber_waitlist', array() );
		$status_badge             = $this->get_datetime_status_badge( $start_datetime, $end_datetime );
		?>
		<div class="wrap kagstm-wrap">
			<div class="kagstm-header">
				<h1>🛡️ <?php esc_html_e( 'Stock Take Mode for WooCommerce', 'kagunda-stock-take-mode-for-woocommerce' ); ?></h1>
				<p class="kagstm-brand-sub"><?php esc_html_e( 'Pause purchasing during inventory counts, with a countdown banner, waitlist capture, and re-open notifications.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></p>
			</div>

			<div class="kagstm-container">
				<div class="kagstm-tabs-nav">
					<a href="#tab-core" class="nav-tab kagstm-nav-tab nav-tab-active"><?php esc_html_e( 'Rules', 'kagunda-stock-take-mode-for-woocommerce' ); ?></a>
					<a href="#tab-ui" class="nav-tab kagstm-nav-tab"><?php esc_html_e( 'Design & Engagement', 'kagunda-stock-take-mode-for-woocommerce' ); ?></a>
					<a href="#tab-subscribers" class="nav-tab kagstm-nav-tab">
						<?php
						/* translators: %d: number of waitlist subscribers. */
						echo esc_html( sprintf( __( 'Waitlist (%d)', 'kagunda-stock-take-mode-for-woocommerce' ), count( $subscribers ) ) );
						?>
					</a>
					<a href="#tab-tools" class="nav-tab kagstm-nav-tab"><?php esc_html_e( 'Import / Export', 'kagunda-stock-take-mode-for-woocommerce' ); ?></a>
				</div>

				<form method="post" action="options.php">
					<?php settings_fields( 'kagstm_settings_group' ); ?>

					<div id="tab-core" class="kagstm-tab-content active">
						<div class="kagstm-row">
							<div class="kagstm-row-label"><?php esc_html_e( 'Restrictions', 'kagunda-stock-take-mode-for-woocommerce' ); ?></div>
							<div>
								<label class="kagstm-toggle-switch">
									<input type="checkbox" name="kagstm_enabled" value="1" <?php checked( $enabled, '1' ); ?>>
									<span class="kagstm-slider"></span>
								</label>
								<div style="margin-top: 8px;">
									<span class="kagstm-status-badge <?php echo esc_attr( $status_badge['class'] ); ?>"><?php echo esc_html( $status_badge['label'] ); ?></span>
								</div>
							</div>
						</div>
						<div class="kagstm-row">
							<div class="kagstm-row-label"><?php esc_html_e( 'Admin Email Alerts', 'kagunda-stock-take-mode-for-woocommerce' ); ?><span><?php esc_html_e( 'Email the store admin when stock take mode starts or ends.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span></div>
							<div>
								<label class="kagstm-toggle-switch">
									<input type="checkbox" name="kagstm_admin_alerts" value="1" <?php checked( $admin_alerts, '1' ); ?>>
									<span class="kagstm-slider"></span>
								</label>
							</div>
						</div>
						<div class="kagstm-row">
							<div class="kagstm-row-label"><?php esc_html_e( 'Admin Bar Indicator', 'kagunda-stock-take-mode-for-woocommerce' ); ?><span><?php esc_html_e( 'Show a status badge in the admin toolbar while active.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span></div>
							<div>
								<label class="kagstm-toggle-switch">
									<input type="checkbox" name="kagstm_show_admin_bar_indicator" value="1" <?php checked( $show_admin_bar_indicator, '1' ); ?>>
									<span class="kagstm-slider"></span>
								</label>
							</div>
						</div>

						<div class="kagstm-row">
							<div class="kagstm-row-label">
								<?php esc_html_e( 'Start Window', 'kagunda-stock-take-mode-for-woocommerce' ); ?>
								<span>
									<?php
									printf(
										/* translators: %s: store timezone string. */
										esc_html__( 'Leave blank to activate immediately. Uses store time: %s.', 'kagunda-stock-take-mode-for-woocommerce' ),
										'<code>' . esc_html( function_exists( 'wc_timezone_string' ) ? wc_timezone_string() : wp_timezone_string() ) . '</code>'
									);
									?>
								</span>
							</div>
							<div>
								<input type="datetime-local" name="kagstm_start_datetime" class="kagstm-datetime-field" value="<?php echo esc_attr( $start_datetime ); ?>">
							</div>
						</div>
						<div class="kagstm-row">
							<div class="kagstm-row-label"><?php esc_html_e( 'End Window', 'kagunda-stock-take-mode-for-woocommerce' ); ?><span><?php esc_html_e( 'Leave blank to stay in stock-take mode until manually turned off.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span></div>
							<div>
								<input type="datetime-local" name="kagstm_end_datetime" class="kagstm-datetime-field" value="<?php echo esc_attr( $end_datetime ); ?>">
							</div>
						</div>

						<div class="kagstm-row">
							<div class="kagstm-row-label"><?php esc_html_e( 'Clear Active Carts', 'kagunda-stock-take-mode-for-woocommerce' ); ?></div>
							<div>
								<label class="kagstm-toggle-switch">
									<input type="checkbox" name="kagstm_clear_cart" value="1" <?php checked( $clear_cart, '1' ); ?>>
									<span class="kagstm-slider"></span>
								</label>
							</div>
						</div>
						<div class="kagstm-row">
							<div class="kagstm-row-label"><?php esc_html_e( 'Bypass Roles', 'kagunda-stock-take-mode-for-woocommerce' ); ?></div>
							<div>
								<?php
								global $wp_roles;
								foreach ( $wp_roles->roles as $key => $role ) {
									$checked = in_array( $key, $bypass_roles, true ) ? 'checked' : '';
									printf(
										'<label style="margin-right:20px; display:inline-block; padding: 4px 0;"><input type="checkbox" name="kagstm_bypass_roles[]" value="%1$s" %2$s> %3$s</label>',
										esc_attr( $key ),
										esc_attr( $checked ),
										esc_html( translate_user_role( $role['name'] ) )
									);
								}
								?>
							</div>
						</div>
						<div class="kagstm-row">
							<div class="kagstm-row-label"><?php esc_html_e( 'Product Exceptions', 'kagunda-stock-take-mode-for-woocommerce' ); ?></div>
							<div>
								<select name="kagstm_product_exceptions[]" class="kagstm-product-select" multiple style="width:100%; max-width:550px;">
									<?php
									foreach ( $product_exceptions as $product_id ) {
										$product = wc_get_product( $product_id );
										if ( $product ) {
											printf(
												'<option value="%1$d" selected>%2$s (#%1$d)</option>',
												absint( $product_id ),
												esc_html( $product->get_name() )
											);
										}
									}
									?>
								</select>
							</div>
						</div>
						<div class="kagstm-row">
							<div class="kagstm-row-label"><?php esc_html_e( 'Category Exceptions', 'kagunda-stock-take-mode-for-woocommerce' ); ?><span><?php esc_html_e( 'Every product in these categories stays purchasable.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span></div>
							<div>
								<select name="kagstm_category_exceptions[]" class="kagstm-category-select" multiple style="width:100%; max-width:550px;">
									<?php
									$categories = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
									if ( ! is_wp_error( $categories ) ) {
										foreach ( $categories as $category ) {
											$selected = in_array( $category->term_id, $category_exceptions, true ) ? 'selected' : '';
											printf(
												'<option value="%1$d" %2$s>%3$s</option>',
												absint( $category->term_id ),
												esc_attr( $selected ),
												esc_html( $category->name )
											);
										}
									}
									?>
								</select>
							</div>
						</div>
					</div>

					<div id="tab-ui" class="kagstm-tab-content">
						<div class="kagstm-row">
							<div class="kagstm-row-label"><?php esc_html_e( 'Countdown Timer', 'kagunda-stock-take-mode-for-woocommerce' ); ?></div>
							<div>
								<label class="kagstm-toggle-switch">
									<input type="checkbox" name="kagstm_show_countdown" value="1" <?php checked( $show_countdown, '1' ); ?>>
									<span class="kagstm-slider"></span>
								</label>
							</div>
						</div>
						<div class="kagstm-row">
							<div class="kagstm-row-label"><?php esc_html_e( 'Waitlist Signup Form', 'kagunda-stock-take-mode-for-woocommerce' ); ?><span><?php esc_html_e( 'Adds an email field to the banner.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span></div>
							<div>
								<label class="kagstm-toggle-switch">
									<input type="checkbox" name="kagstm_enable_waitlist" value="1" <?php checked( $enable_waitlist, '1' ); ?>>
									<span class="kagstm-slider"></span>
								</label>
							</div>
						</div>
						<div class="kagstm-row">
							<div class="kagstm-row-label"><?php esc_html_e( 'Auto Broadcast on Re-open', 'kagunda-stock-take-mode-for-woocommerce' ); ?><span><?php esc_html_e( 'Email the waitlist automatically once stock take ends.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span></div>
							<div>
								<label class="kagstm-toggle-switch">
									<input type="checkbox" name="kagstm_broadcast_complete" value="1" <?php checked( $broadcast_complete, '1' ); ?>>
									<span class="kagstm-slider"></span>
								</label>
							</div>
						</div>
						<div class="kagstm-row">
							<div class="kagstm-row-label">
								<?php esc_html_e( 'Broadcast Subject', 'kagunda-stock-take-mode-for-woocommerce' ); ?>
								<span><?php esc_html_e( 'Placeholders:', 'kagunda-stock-take-mode-for-woocommerce' ); ?><br><br><span class="kagstm-token">{site_name}</span> <span class="kagstm-token">{site_url}</span></span>
							</div>
							<div>
								<input type="text" name="kagstm_broadcast_subject" class="kagstm-input-text" value="<?php echo esc_attr( $broadcast_subject ); ?>">
							</div>
						</div>
						<div class="kagstm-row">
							<div class="kagstm-row-label">
								<?php esc_html_e( 'Broadcast Body', 'kagunda-stock-take-mode-for-woocommerce' ); ?>
								<span><?php esc_html_e( 'Placeholders:', 'kagunda-stock-take-mode-for-woocommerce' ); ?><br><span class="kagstm-token">{site_name}</span> <span class="kagstm-token">{site_url}</span> <span class="kagstm-token">{customer_email}</span></span>
							</div>
							<div>
								<?php wp_editor( $broadcast_body, 'kagstm_broadcast_body', array( 'textarea_name' => 'kagstm_broadcast_body', 'textarea_rows' => 6 ) ); ?>

								<div class="kagstm-test-box">
									<p style="margin:0 0 8px 0; font-weight:600; font-size:12px; color:#475569;"><?php esc_html_e( 'Send a test email', 'kagunda-stock-take-mode-for-woocommerce' ); ?></p>
									<div style="display:flex; gap:6px; flex-wrap:wrap;">
										<input type="email" id="kagstm-test-target-input" class="regular-text" style="padding:4px 10px; font-size:12px;" value="<?php echo esc_attr( get_option( 'admin_email' ) ); ?>">
										<button type="button" id="kagstm-trigger-test-mail" class="button button-secondary button-small"><?php esc_html_e( 'Send Test Email', 'kagunda-stock-take-mode-for-woocommerce' ); ?></button>
									</div>
								</div>
							</div>
						</div>

						<div class="kagstm-row">
							<div class="kagstm-row-label"><?php esc_html_e( 'Notice Message', 'kagunda-stock-take-mode-for-woocommerce' ); ?><span><?php esc_html_e( 'Defaults to "Sorry, we are closed for stock intake." if left empty.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span></div>
							<div><?php wp_editor( $message, 'kagstm_message', array( 'textarea_name' => 'kagstm_message', 'textarea_rows' => 4 ) ); ?></div>
						</div>
						<div class="kagstm-row">
							<div class="kagstm-row-label"><?php esc_html_e( 'Add-to-Cart Button Behavior', 'kagunda-stock-take-mode-for-woocommerce' ); ?></div>
							<div>
								<select name="kagstm_button_behavior" class="kagstm-input-select">
									<option value="hide" <?php selected( $button_behavior, 'hide' ); ?>><?php esc_html_e( 'Hide add-to-cart buttons entirely', 'kagunda-stock-take-mode-for-woocommerce' ); ?></option>
									<option value="disable_text" <?php selected( $button_behavior, 'disable_text' ); ?>><?php esc_html_e( 'Replace with custom text', 'kagunda-stock-take-mode-for-woocommerce' ); ?></option>
									<option value="inactive_only" <?php selected( $button_behavior, 'inactive_only' ); ?>><?php esc_html_e( 'Keep visible but disabled', 'kagunda-stock-take-mode-for-woocommerce' ); ?></option>
								</select>
							</div>
						</div>
						<div class="kagstm-row">
							<div class="kagstm-row-label"><?php esc_html_e( 'Disabled Button Text', 'kagunda-stock-take-mode-for-woocommerce' ); ?></div>
							<div><input type="text" name="kagstm_button_text" class="kagstm-input-text" value="<?php echo esc_attr( $button_text ); ?>"></div>
						</div>
						<div class="kagstm-row">
							<div class="kagstm-row-label"><?php esc_html_e( 'Banner Background Color', 'kagunda-stock-take-mode-for-woocommerce' ); ?></div>
							<div><input type="text" name="kagstm_bg_color" class="kagstm-color-field" value="<?php echo esc_attr( $bg_color ); ?>"></div>
						</div>
						<div class="kagstm-row">
							<div class="kagstm-row-label"><?php esc_html_e( 'Banner Text Color', 'kagunda-stock-take-mode-for-woocommerce' ); ?></div>
							<div><input type="text" name="kagstm_text_color" class="kagstm-color-field" value="<?php echo esc_attr( $text_color ); ?>"></div>
						</div>
					</div>

					<div class="kagstm-footer">
						<span></span>
						<?php submit_button( __( 'Save Changes', 'kagunda-stock-take-mode-for-woocommerce' ), 'primary button-large', 'submit', false ); ?>
					</div>
				</form>

				<div id="tab-subscribers" class="kagstm-tab-content">
					<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px; flex-wrap:wrap; gap:10px;">
						<div>
							<h3 style="margin:0 0 4px 0; font-size:16px;"><?php esc_html_e( 'Waitlist Subscribers', 'kagunda-stock-take-mode-for-woocommerce' ); ?></h3>
							<p style="margin:0; color:#64748b; font-size:12px;"><?php esc_html_e( 'Customers waiting to be notified when the store re-opens.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></p>
						</div>
						<?php if ( ! empty( $subscribers ) ) : ?>
							<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=kagstm-settings&action=kagstm_export_csv' ), 'kagstm_csv_download', 'nonce' ) ); ?>" class="button button-secondary"><?php esc_html_e( 'Export CSV', 'kagunda-stock-take-mode-for-woocommerce' ); ?></a>
						<?php endif; ?>
					</div>

					<div class="kagstm-table-wrapper">
						<table class="kagstm-data-table">
							<thead>
								<tr>
									<th style="width: 80px;">#</th>
									<th><?php esc_html_e( 'Email Address', 'kagunda-stock-take-mode-for-woocommerce' ); ?></th>
									<th><?php esc_html_e( 'Subscribed On', 'kagunda-stock-take-mode-for-woocommerce' ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php if ( empty( $subscribers ) ) : ?>
									<tr>
										<td colspan="3" class="kagstm-empty-row"><?php esc_html_e( 'No subscriptions yet.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></td>
									</tr>
								<?php else : ?>
									<?php
									$index = 1;
									foreach ( array_reverse( $subscribers ) as $sub ) :
										?>
										<tr>
											<td><?php echo esc_html( $index++ ); ?></td>
											<td><strong><?php echo esc_html( $sub['email'] ); ?></strong></td>
											<td><?php echo esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $sub['date'] ) ) ); ?></td>
										</tr>
									<?php endforeach; ?>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>

				<div id="tab-tools" class="kagstm-tab-content">
					<h3 style="margin-top:0;"><?php esc_html_e( 'Export Settings', 'kagunda-stock-take-mode-for-woocommerce' ); ?></h3>
					<p style="color:#64748b; font-size:13px;"><?php esc_html_e( 'Download your current configuration as a JSON file, useful for backups or setting up another store.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></p>
					<p>
						<a class="button button-secondary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=kagstm-settings&action=kagstm_export_settings' ), 'kagstm_settings_export', 'nonce' ) ); ?>"><?php esc_html_e( 'Download Configuration', 'kagunda-stock-take-mode-for-woocommerce' ); ?></a>
					</p>

					<hr>

					<h3><?php esc_html_e( 'Import Settings', 'kagunda-stock-take-mode-for-woocommerce' ); ?></h3>
					<p style="color:#64748b; font-size:13px;"><?php esc_html_e( 'Upload a configuration file previously exported from this plugin.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></p>
					<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin.php?page=kagstm-settings' ) ); ?>">
						<?php wp_nonce_field( 'kagstm_settings_import', 'kagstm_import_nonce' ); ?>
						<div class="kagstm-import-export">
							<input type="file" name="kagstm_import_file" accept="application/json" required>
							<?php submit_button( __( 'Import Configuration', 'kagunda-stock-take-mode-for-woocommerce' ), 'secondary', 'kagstm_do_import', false ); ?>
						</div>
					</form>
				</div>
			</div>
		</div>
		<?php
	}
}

Kagunda_Stock_Take_Mode_For_WooCommerce::instance();
