/**
 * Frontend behaviors for Kagunda Stock Take Mode for WooCommerce.
 * Enqueued via wp_enqueue_script(); reads its configuration from the
 * localized "KAGSTM_Frontend" object rather than inline <script> blocks.
 */
( function () {
	'use strict';

	document.addEventListener( 'DOMContentLoaded', function () {
		if ( typeof window.KAGSTM_Frontend === 'undefined' ) {
			return;
		}

		var settings = window.KAGSTM_Frontend;

		initCountdown();
		initWaitlistForm();
		applyButtonBehavior();

		function initCountdown() {
			var clock = document.querySelector( '.kagstm-countdown-container' );
			if ( ! clock ) {
				return;
			}

			var deadline = new Date( clock.getAttribute( 'data-deadline' ) ).getTime();
			if ( isNaN( deadline ) ) {
				return;
			}

			var timer = setInterval( updateClock, 1000 );
			updateClock();

			function updateClock() {
				var remaining = deadline - new Date().getTime();

				if ( remaining <= 0 ) {
					clock.style.display = 'none';
					clearInterval( timer );
					return;
				}

				setSegment( 'days', Math.floor( remaining / ( 1000 * 60 * 60 * 24 ) ) );
				setSegment( 'hours', Math.floor( ( remaining / ( 1000 * 60 * 60 ) ) % 24 ) );
				setSegment( 'minutes', Math.floor( ( remaining / 1000 / 60 ) % 60 ) );
				setSegment( 'seconds', Math.floor( ( remaining / 1000 ) % 60 ) );
			}

			function setSegment( className, value ) {
				var el = clock.querySelector( '.' + className );
				if ( el ) {
					el.textContent = ( '0' + value ).slice( -2 );
				}
			}
		}

		function initWaitlistForm() {
			var button = document.getElementById( 'kagstm-subscribe-btn' );
			if ( ! button ) {
				return;
			}

			button.addEventListener( 'click', function () {
				var emailInput = document.getElementById( 'kagstm-subscriber-email' );

				if ( ! emailInput || ! emailInput.checkValidity() ) {
					window.alert( settings.i18n.invalidEmail );
					return;
				}

				button.disabled = true;
				button.textContent = settings.i18n.joining;

				var formData = new FormData();
				formData.append( 'action', 'kagstm_subscribe_email' );
				formData.append( 'email', emailInput.value );
				formData.append( 'nonce', settings.subscribeNonce );

				fetch( settings.ajaxUrl, { method: 'POST', body: formData, credentials: 'same-origin' } )
					.then( function ( response ) { return response.json(); } )
					.then( function ( response ) {
						if ( response.success ) {
							var wrap = document.querySelector( '.kagstm-waitlist-form-wrap' );
							if ( wrap ) {
								wrap.textContent = response.data.message;
							}
						} else {
							window.alert( response.data.message );
							button.disabled = false;
							button.textContent = settings.i18n.joinWaitlist;
						}
					} )
					.catch( function () {
						window.alert( settings.i18n.subscribeError );
						button.disabled = false;
						button.textContent = settings.i18n.joinWaitlist;
					} );
			} );
		}

		function applyButtonBehavior() {
			if ( ! settings.buttonBehavior ) {
				return;
			}

			var selector = '.add_to_cart_button, .single_add_to_cart_button, .woocommerce-variation-add-to-cart-button .single_add_to_cart_button';

			if ( 'hide' === settings.buttonBehavior ) {
				document.querySelectorAll( selector ).forEach( function ( btn ) {
					btn.style.setProperty( 'display', 'none', 'important' );
				} );
			} else if ( 'inactive_only' === settings.buttonBehavior ) {
				document.querySelectorAll( selector ).forEach( function ( btn ) {
					btn.classList.add( 'disabled' );
					btn.disabled = true;
					btn.style.setProperty( 'opacity', '0.6', 'important' );
					btn.style.setProperty( 'cursor', 'not-allowed', 'important' );
					btn.style.setProperty( 'pointer-events', 'none', 'important' );
					btn.setAttribute( 'title', settings.i18n.orderingFrozen );
				} );
			}
		}
	} );
} )();
