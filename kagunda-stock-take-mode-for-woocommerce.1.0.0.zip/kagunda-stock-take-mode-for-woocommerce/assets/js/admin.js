/**
 * Admin settings screen behaviors for Kagunda Stock Take Mode for WooCommerce.
 * Reads its configuration from the localized "KAGSTM_Admin" object.
 */
jQuery( function ( $ ) {
	'use strict';

	if ( typeof window.KAGSTM_Admin === 'undefined' ) {
		return;
	}

	var settings = window.KAGSTM_Admin;

	$( '.kagstm-color-field' ).wpColorPicker();

	$( '.kagstm-product-select' ).select2( {
		width: '100%',
		placeholder: settings.i18n.searchProducts,
		minimumInputLength: 3,
		ajax: {
			url: settings.ajaxUrl,
			dataType: 'json',
			delay: 250,
			data: function ( params ) {
				return {
					term: params.term,
					action: 'kagstm_json_search_products',
					security: settings.searchNonce,
				};
			},
			processResults: function ( data ) {
				return { results: data };
			},
			cache: true,
		},
	} );

	$( '.kagstm-category-select' ).select2( {
		width: '100%',
		placeholder: settings.i18n.searchCategories,
	} );

	$( '.kagstm-nav-tab' ).on( 'click', function ( e ) {
		e.preventDefault();
		$( '.kagstm-nav-tab' ).removeClass( 'nav-tab-active' );
		$( this ).addClass( 'nav-tab-active' );
		$( '.kagstm-tab-content' ).removeClass( 'active' ).hide();
		$( $( this ).attr( 'href' ) ).addClass( 'active' ).show();
	} );

	$( '#kagstm-trigger-test-mail' ).on( 'click', function ( e ) {
		e.preventDefault();

		var button = $( this );
		var originalText = button.text();
		var testEmail = $( '#kagstm-test-target-input' ).val();
		var subjectTxt = $( 'input[name="kagstm_broadcast_subject"]' ).val();
		var bodyTxt = ( typeof tinyMCE !== 'undefined' && tinyMCE.get( 'kagstm_broadcast_body' ) )
			? tinyMCE.get( 'kagstm_broadcast_body' ).getContent()
			: $( 'textarea[name="kagstm_broadcast_body"]' ).val();

		button.prop( 'disabled', true ).text( settings.i18n.dispatching );

		$.post( settings.ajaxUrl, {
			action: 'kagstm_send_test_email',
			security: settings.searchNonce,
			test_email: testEmail,
			subject: subjectTxt,
			body: bodyTxt,
		} ).done( function ( response ) {
			if ( response.success ) {
				window.alert( response.data.message );
			} else {
				window.alert( response.data.message );
			}
		} ).fail( function () {
			window.alert( settings.i18n.testEmailFailed );
		} ).always( function () {
			button.prop( 'disabled', false ).text( originalText );
		} );
	} );
} );
