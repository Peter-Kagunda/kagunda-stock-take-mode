=== Kagunda Stock Take Mode for WooCommerce ===
Contributors: kagunda
Tags: woocommerce, stock, inventory, maintenance, waitlist
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Requires Plugins: woocommerce
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Pause purchasing on your WooCommerce store during stock counts, with a countdown banner, waitlist capture, and automatic re-open notifications.

== Description ==

Kagunda Stock Take Mode for WooCommerce lets store owners temporarily pause purchasing across the whole store, or on specific products, while they run an inventory count, perform maintenance, or run a seasonal stock-take.

= Features =

* **Restriction toggle:** Turn purchasing off store-wide with one switch, or schedule a start/end window.
* **Product & category exceptions:** Keep specific products, or entire categories, purchasable while everything else is paused.
* **Role bypass:** Let administrators, shop managers, or any other role keep shopping normally.
* **Countdown banner:** A sticky site-wide banner with a live countdown to your scheduled re-open time.
* **Waitlist capture:** Visitors can leave their email to be notified the moment the store re-opens.
* **Automatic re-open broadcast:** Optionally email every waitlist subscriber automatically once stock-take mode ends.
* **Admin bar indicator:** A quick status badge in the toolbar while restrictions are active, linking straight to settings.
* **Dashboard widget:** See blocked purchase attempts and waitlist size at a glance.
* **Settings import/export:** Download your configuration as JSON to back it up or copy it to another store.
* **WooCommerce log integration:** Key events are recorded under WooCommerce > Status > Logs for troubleshooting.

== Installation ==

1. Make sure WooCommerce is installed and active.
2. Download the plugin ZIP file, or install it directly from the WordPress.org plugin directory.
3. Activate the plugin.
4. Go to WooCommerce > Stock Take Mode to configure it.

== Configuration ==

* **Rules:** Turn the system on/off, set a start/end window, choose bypass roles, and set product/category exceptions.
* **Design & Engagement:** Customize the banner colors, the customer-facing message, the add-to-cart button behavior, and your re-open email.
* **Waitlist:** View and export subscriber emails to CSV.
* **Import/Export:** Download or upload your configuration as a JSON file.

== Frequently Asked Questions ==

= Does this require WooCommerce? =

Yes. WooCommerce must be installed and active.

= Will my settings be kept if I update from an older 1.0.0-beta build? =

If you previously used this plugin under an earlier working name, the plugin performs a one-time, automatic migration of your saved settings the first time it runs after updating.

= Can I add custom CSS or JavaScript? =

No. To keep the plugin secure, it does not accept arbitrary CSS, JavaScript, or PHP from the settings screen. Banner appearance is controlled through the provided color pickers.

== Changelog ==

= 1.0.0 =
* Initial public release.

== Upgrade Notice ==

= 1.0.0 =
Initial public release.
