<?php
/**
 * Waitlist storage for Stock Take Mode for WooCommerce.
 *
 * Subscribers are kept in a single non-autoloaded option. The class also
 * plugs into the WordPress personal data export and erase tools.
 *
 * @package Kagunda_Stock_Take_Mode_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Waitlist data access.
 */
class KAGSTM_Waitlist {

	/**
	 * Option that stores the list.
	 */
	const OPTION = 'kagstm_subscriber_waitlist';

	/**
	 * Register privacy tool integrations.
	 */
	public static function init() {
		add_filter( 'wp_privacy_personal_data_exporters', array( __CLASS__, 'register_exporter' ) );
		add_filter( 'wp_privacy_personal_data_erasers', array( __CLASS__, 'register_eraser' ) );
		add_action( 'admin_init', array( __CLASS__, 'add_privacy_policy_content' ) );
	}

	/**
	 * Maximum number of subscribers that can be stored.
	 *
	 * @return int
	 */
	public static function max_size() {
		return max( 1, (int) apply_filters( 'kagstm_waitlist_max', 5000 ) );
	}

	/**
	 * All subscribers, oldest first.
	 *
	 * @return array[] Each item has "email" and "date".
	 */
	public static function all() {
		$entries = get_option( self::OPTION, array() );
		if ( ! is_array( $entries ) ) {
			return array();
		}

		$clean = array();
		foreach ( $entries as $item ) {
			if ( is_array( $item ) && ! empty( $item['email'] ) && is_string( $item['email'] ) ) {
				$clean[] = array(
					'email' => $item['email'],
					'date'  => isset( $item['date'] ) && is_string( $item['date'] ) ? $item['date'] : '',
				);
			}
		}

		return $clean;
	}

	/**
	 * Number of subscribers.
	 *
	 * @return int
	 */
	public static function count() {
		return count( self::all() );
	}

	/**
	 * Every subscriber e-mail address.
	 *
	 * @return string[]
	 */
	public static function emails() {
		return wp_list_pluck( self::all(), 'email' );
	}

	/**
	 * Persist the list without autoloading it on every request.
	 *
	 * @param array $entries Subscriber list.
	 */
	private static function save( array $entries ) {
		if ( empty( $entries ) ) {
			delete_option( self::OPTION );
			return;
		}
		update_option( self::OPTION, array_values( $entries ), false );
	}

	/**
	 * Add an e-mail address.
	 *
	 * @param string $email Sanitized, validated e-mail address.
	 * @return string One of: added, exists, full.
	 */
	public static function add( $email ) {
		$entries = self::all();

		foreach ( $entries as $item ) {
			if ( 0 === strcasecmp( $item['email'], $email ) ) {
				return 'exists';
			}
		}

		if ( count( $entries ) >= self::max_size() ) {
			return 'full';
		}

		$entries[] = array(
			'email' => $email,
			'date'  => current_time( 'mysql' ),
		);
		self::save( $entries );

		return 'added';
	}

	/**
	 * Remove one e-mail address.
	 *
	 * @param string $email E-mail address.
	 * @return bool True when something was removed.
	 */
	public static function remove( $email ) {
		$entries = self::all();
		$kept    = array();

		foreach ( $entries as $item ) {
			if ( 0 !== strcasecmp( $item['email'], $email ) ) {
				$kept[] = $item;
			}
		}

		if ( count( $kept ) === count( $entries ) ) {
			return false;
		}

		self::save( $kept );
		return true;
	}

	/**
	 * Remove every subscriber.
	 */
	public static function clear() {
		delete_option( self::OPTION );
	}

	/**
	 * Soft rate limit for the public sign-up form.
	 *
	 * Only a hash of the visitor address is used, and only inside a short-lived
	 * transient, so no personal data is stored.
	 *
	 * @return bool True when the visitor has reached the limit.
	 */
	public static function is_rate_limited() {
		$key   = self::rate_limit_key();
		$limit = max( 1, (int) apply_filters( 'kagstm_waitlist_rate_limit', 8 ) );
		return (int) get_transient( $key ) >= $limit;
	}

	/**
	 * Record one sign-up attempt for the current visitor.
	 */
	public static function record_attempt() {
		$key = self::rate_limit_key();
		set_transient( $key, (int) get_transient( $key ) + 1, 10 * MINUTE_IN_SECONDS );
	}

	/**
	 * Transient key for the current visitor.
	 *
	 * @return string
	 */
	private static function rate_limit_key() {
		$ip = '';
		if ( class_exists( 'WC_Geolocation' ) ) {
			$ip = (string) WC_Geolocation::get_ip_address();
		}
		if ( '' === $ip && isset( $_SERVER['REMOTE_ADDR'] ) ) {
			$ip = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
		}
		return 'kagstm_rl_' . md5( $ip );
	}

	/**
	 * Add the personal data exporter.
	 *
	 * @param array $exporters Registered exporters.
	 * @return array
	 */
	public static function register_exporter( $exporters ) {
		$exporters['kagstm-waitlist'] = array(
			'exporter_friendly_name' => __( 'Stock Take Mode waitlist', 'kagunda-stock-take-mode-for-woocommerce' ),
			'callback'               => array( __CLASS__, 'export_personal_data' ),
		);
		return $exporters;
	}

	/**
	 * Add the personal data eraser.
	 *
	 * @param array $erasers Registered erasers.
	 * @return array
	 */
	public static function register_eraser( $erasers ) {
		$erasers['kagstm-waitlist'] = array(
			'eraser_friendly_name' => __( 'Stock Take Mode waitlist', 'kagunda-stock-take-mode-for-woocommerce' ),
			'callback'             => array( __CLASS__, 'erase_personal_data' ),
		);
		return $erasers;
	}

	/**
	 * Export callback for the WordPress privacy tools.
	 *
	 * @param string $email_address Address being exported.
	 * @return array
	 */
	public static function export_personal_data( $email_address ) {
		$export = array();

		foreach ( self::all() as $item ) {
			if ( 0 === strcasecmp( $item['email'], $email_address ) ) {
				$export[] = array(
					'group_id'    => 'kagstm-waitlist',
					'group_label' => __( 'Stock Take Mode waitlist', 'kagunda-stock-take-mode-for-woocommerce' ),
					'item_id'     => 'kagstm-waitlist-' . md5( $item['email'] ),
					'data'        => array(
						array(
							'name'  => __( 'Email address', 'kagunda-stock-take-mode-for-woocommerce' ),
							'value' => $item['email'],
						),
						array(
							'name'  => __( 'Subscribed on', 'kagunda-stock-take-mode-for-woocommerce' ),
							'value' => $item['date'],
						),
					),
				);
			}
		}

		return array(
			'data' => $export,
			'done' => true,
		);
	}

	/**
	 * Erase callback for the WordPress privacy tools.
	 *
	 * @param string $email_address Address being erased.
	 * @return array
	 */
	public static function erase_personal_data( $email_address ) {
		$removed = self::remove( $email_address );

		return array(
			'items_removed'  => $removed,
			'items_retained' => false,
			'messages'       => array(),
			'done'           => true,
		);
	}

	/**
	 * Suggest privacy policy text for the site's privacy policy page.
	 */
	public static function add_privacy_policy_content() {
		if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
			return;
		}

		$content = '<h2>' . esc_html__( 'Stock Take Mode waitlist', 'kagunda-stock-take-mode-for-woocommerce' ) . '</h2>'
			. '<p>' . esc_html__( 'If you leave your email address in the store notice while we are closed for a stock take, we store that address, together with the date and time you signed up, in this site\'s database. We use it only to send you a single email when the store re-opens, after which it is deleted. The address is never shared with third parties.', 'kagunda-stock-take-mode-for-woocommerce' ) . '</p>';

		wp_add_privacy_policy_content( __( 'Stock Take Mode for WooCommerce', 'kagunda-stock-take-mode-for-woocommerce' ), $content );
	}
}
