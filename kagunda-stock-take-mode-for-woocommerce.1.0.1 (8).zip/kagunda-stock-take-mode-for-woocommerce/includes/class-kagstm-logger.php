<?php
/**
 * Logger for Stock Take Mode for WooCommerce.
 *
 * Writes to WooCommerce's native logging system so store owners can review
 * activity under WooCommerce > Status > Logs.
 *
 * @package Kagunda_Stock_Take_Mode_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Thin wrapper around wc_get_logger().
 */
class KAGSTM_Logger {

	/**
	 * Cached WC_Logger instance.
	 *
	 * @var WC_Logger|null
	 */
	private static $logger = null;

	/**
	 * Log a message to the WooCommerce status logs.
	 *
	 * @param string $message The message to log.
	 * @param string $level   Severity: emergency, alert, critical, error, warning, notice, info or debug.
	 */
	public static function log( $message, $level = 'info' ) {
		if ( ! function_exists( 'wc_get_logger' ) ) {
			return;
		}

		if ( null === self::$logger ) {
			self::$logger = wc_get_logger();
		}

		self::$logger->log(
			$level,
			$message,
			array( 'source' => 'kagunda-stock-take-mode-for-woocommerce' )
		);
	}
}
