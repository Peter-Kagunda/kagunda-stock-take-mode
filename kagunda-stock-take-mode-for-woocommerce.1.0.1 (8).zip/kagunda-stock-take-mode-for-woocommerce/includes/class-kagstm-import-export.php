<?php
/**
 * Settings import/export helper for Stock Take Mode for WooCommerce.
 *
 * Lets a store owner download their configuration as JSON and re-import it
 * on the same or another site. No code is ever executed: only the fixed
 * allow-list of known settings is read or written, and every value passes
 * through the same sanitizers as the settings screen.
 *
 * @package Kagunda_Stock_Take_Mode_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * JSON import/export.
 */
class KAGSTM_Import_Export {

	/**
	 * Largest import file accepted, in bytes.
	 */
	const MAX_FILE_SIZE = 262144;

	/**
	 * Build a JSON string with the current settings.
	 *
	 * @return string
	 */
	public static function export_json() {
		$data = array();

		foreach ( KAGSTM_Settings::portable_keys() as $key ) {
			$data[ $key ] = KAGSTM_Settings::get( $key );
		}

		return wp_json_encode(
			array(
				'plugin'   => 'kagunda-stock-take-mode-for-woocommerce',
				'version'  => defined( 'KAGSTM_VERSION' ) ? KAGSTM_VERSION : '',
				'settings' => $data,
			),
			JSON_PRETTY_PRINT
		);
	}

	/**
	 * Validate and apply a previously exported JSON payload.
	 *
	 * @param string $json Raw JSON string supplied by the store owner.
	 * @return int|WP_Error Number of settings imported, or an error.
	 */
	public static function import_json( $json ) {
		if ( ! is_string( $json ) || strlen( $json ) > self::MAX_FILE_SIZE ) {
			return new WP_Error( 'kagstm_invalid_file', __( 'That file is empty or too large to be a configuration export.', 'kagunda-stock-take-mode-for-woocommerce' ) );
		}

		$decoded = json_decode( $json, true );

		if ( ! is_array( $decoded ) || empty( $decoded['settings'] ) || ! is_array( $decoded['settings'] ) ) {
			return new WP_Error( 'kagstm_invalid_file', __( 'That file does not look like a valid configuration export.', 'kagunda-stock-take-mode-for-woocommerce' ) );
		}

		$allowed  = KAGSTM_Settings::portable_keys();
		$imported = 0;

		foreach ( $decoded['settings'] as $key => $value ) {
			if ( ! in_array( $key, $allowed, true ) ) {
				continue; // Ignore anything outside the allow-list.
			}

			update_option( KAGSTM_Settings::PREFIX . $key, KAGSTM_Settings::sanitize( $key, $value ) );
			++$imported;
		}

		return $imported;
	}
}
