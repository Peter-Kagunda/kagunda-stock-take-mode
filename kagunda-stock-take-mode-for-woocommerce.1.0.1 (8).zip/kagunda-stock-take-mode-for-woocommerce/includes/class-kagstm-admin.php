<?php
/**
 * Admin screens and handlers for Stock Take Mode for WooCommerce.
 *
 * @package Kagunda_Stock_Take_Mode_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings screen, dashboard widget, admin bar and admin-post handlers.
 */
class KAGSTM_Admin {

	/**
	 * Settings page slug.
	 */
	const PAGE = 'kagstm-settings';

	/**
	 * Singleton instance.
	 *
	 * @var KAGSTM_Admin|null
	 */
	private static $instance = null;

	/**
	 * Get the singleton instance.
	 *
	 * @return KAGSTM_Admin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Wire up hooks.
	 */
	private function __construct() {
		add_action( 'admin_menu', array( $this, 'register_admin_menu' ), 56 );
		add_action( 'admin_init', array( 'KAGSTM_Settings', 'register' ) );
		add_action( 'admin_notices', array( $this, 'render_admin_notices' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
		add_filter( 'option_page_capability_' . KAGSTM_Settings::OPTION_GROUP, array( 'KAGSTM_Settings', 'capability' ) );
		add_filter( 'plugin_action_links_' . KAGSTM_PLUGIN_BASENAME, array( $this, 'add_action_links' ) );

		add_action( 'wp_ajax_kagstm_json_search_products', array( $this, 'ajax_search_products' ) );
		add_action( 'wp_ajax_kagstm_send_test_email', array( $this, 'handle_admin_test_email' ) );

		add_action( 'admin_post_kagstm_toggle', array( $this, 'handle_toggle' ) );
		add_action( 'admin_post_kagstm_export_csv', array( $this, 'handle_csv_export' ) );
		add_action( 'admin_post_kagstm_export_settings', array( $this, 'handle_settings_export' ) );
		add_action( 'admin_post_kagstm_import_settings', array( $this, 'handle_settings_import' ) );
		add_action( 'admin_post_kagstm_remove_subscriber', array( $this, 'handle_remove_subscriber' ) );
		add_action( 'admin_post_kagstm_clear_waitlist', array( $this, 'handle_clear_waitlist' ) );
		add_action( 'admin_post_kagstm_send_broadcast', array( $this, 'handle_send_broadcast' ) );
		add_action( 'admin_post_kagstm_reset_stats', array( $this, 'handle_reset_stats' ) );

		add_action( 'wp_dashboard_setup', array( $this, 'register_dashboard_analytics_widget' ) );
		add_action( 'admin_bar_menu', array( $this, 'render_admin_bar_indicator' ), 100 );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_admin_bar_styles' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_bar_styles' ) );
	}

	/**
	 * Add a "Settings" link on the Plugins screen.
	 *
	 * @param string[] $links Existing links.
	 * @return string[]
	 */
	public function add_action_links( $links ) {
		$settings = sprintf(
			'<a href="%1$s">%2$s</a>',
			esc_url( $this->settings_url() ),
			esc_html__( 'Settings', 'kagunda-stock-take-mode-for-woocommerce' )
		);
		array_unshift( $links, $settings );
		return $links;
	}

	/**
	 * URL of the settings screen.
	 *
	 * @param array $args Extra query args.
	 * @return string
	 */
	private function settings_url( $args = array() ) {
		return add_query_arg( $args, admin_url( 'admin.php?page=' . self::PAGE ) );
	}

	/**
	 * Build a nonce-protected admin-post URL.
	 *
	 * @param string $action Action name without the "kagstm_" prefix.
	 * @param array  $args   Extra query args.
	 * @return string
	 */
	private function action_url( $action, $args = array() ) {
		$args['action'] = 'kagstm_' . $action;
		return wp_nonce_url( add_query_arg( $args, admin_url( 'admin-post.php' ) ), 'kagstm_' . $action );
	}

	/**
	 * Register the WooCommerce submenu page.
	 */
	public function register_admin_menu() {
		add_submenu_page(
			'woocommerce',
			__( 'Stock Take Mode', 'kagunda-stock-take-mode-for-woocommerce' ),
			__( 'Stock Take Mode', 'kagunda-stock-take-mode-for-woocommerce' ),
			KAGSTM_Settings::capability(),
			self::PAGE,
			array( $this, 'render_settings_page' )
		);
	}

	// ----- Notices -----.

	/**
	 * Whether the current admin screen is this plugin's settings page.
	 *
	 * @return bool
	 */
	private function is_settings_screen() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only screen check, no data is processed.
		return isset( $_GET['page'] ) && self::PAGE === sanitize_key( wp_unslash( $_GET['page'] ) );
	}

	/**
	 * Render admin notices.
	 */
	public function render_admin_notices() {
		if ( ! class_exists( 'WooCommerce' ) && current_user_can( KAGSTM_Settings::capability() ) ) {
			printf(
				'<div class="notice notice-error"><p>%s</p></div>',
				esc_html__( 'Stock Take Mode for WooCommerce needs WooCommerce to be installed and active.', 'kagunda-stock-take-mode-for-woocommerce' )
			);
		}

		if ( ! $this->is_settings_screen() ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only flag set by WordPress core's settings redirect.
		if ( isset( $_GET['settings-updated'] ) && 'true' === sanitize_text_field( wp_unslash( $_GET['settings-updated'] ) ) ) {
			$this->print_notice( 'success', __( 'Stock Take Mode settings saved.', 'kagunda-stock-take-mode-for-woocommerce' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only flag added by our own nonce-verified admin-post handlers.
		$code = isset( $_GET['kagstm_notice'] ) ? sanitize_key( wp_unslash( $_GET['kagstm_notice'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- numeric display value from our own redirect.
		$count = isset( $_GET['kagstm_count'] ) ? absint( $_GET['kagstm_count'] ) : 0;

		$messages = array(
			'started'            => array( 'success', __( 'Stock Take Mode is now active.', 'kagunda-stock-take-mode-for-woocommerce' ) ),
			'stopped'            => array( 'success', __( 'Stock Take Mode is now off. The store is open for purchasing.', 'kagunda-stock-take-mode-for-woocommerce' ) ),
			'import_success'     => array( 'success', __( 'Configuration imported successfully.', 'kagunda-stock-take-mode-for-woocommerce' ) ),
			'import_error'       => array( 'error', __( 'The configuration file could not be imported. Please check the file and try again.', 'kagunda-stock-take-mode-for-woocommerce' ) ),
			'subscriber_removed' => array( 'success', __( 'Subscriber removed from the waitlist.', 'kagunda-stock-take-mode-for-woocommerce' ) ),
			'waitlist_cleared'   => array( 'success', __( 'The waitlist was cleared.', 'kagunda-stock-take-mode-for-woocommerce' ) ),
			'stats_reset'        => array( 'success', __( 'The blocked-attempts counter was reset.', 'kagunda-stock-take-mode-for-woocommerce' ) ),
			'broadcast_none'     => array( 'warning', __( 'There is nobody on the waitlist to email.', 'kagunda-stock-take-mode-for-woocommerce' ) ),
		);

		if ( 'broadcast_queued' === $code ) {
			/* translators: %d: number of subscribers. */
			$this->print_notice( 'success', sprintf( _n( 'Re-open email queued for %d subscriber. It will be sent in the background.', 'Re-open email queued for %d subscribers. They will be sent in the background.', $count, 'kagunda-stock-take-mode-for-woocommerce' ), $count ) );
		} elseif ( isset( $messages[ $code ] ) ) {
			$this->print_notice( $messages[ $code ][0], $messages[ $code ][1] );
		}

		$start = KAGSTM_Settings::to_timestamp( (string) KAGSTM_Settings::get( 'start_datetime' ) );
		$end   = KAGSTM_Settings::to_timestamp( (string) KAGSTM_Settings::get( 'end_datetime' ) );
		if ( null !== $start && null !== $end && $end <= $start ) {
			$this->print_notice( 'warning', __( 'The end time is not after the start time, so Stock Take Mode will never become active. Please adjust the schedule.', 'kagunda-stock-take-mode-for-woocommerce' ) );
		}
	}

	/**
	 * Print a dismissible admin notice.
	 *
	 * @param string $type    success, error or warning.
	 * @param string $message Already-translated plain text.
	 */
	private function print_notice( $type, $message ) {
		printf(
			'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
			esc_attr( $type ),
			esc_html( $message )
		);
	}

	// ----- admin-post handlers -----.

	/**
	 * Redirect after an action, back to where it was triggered when possible.
	 *
	 * @param string $notice Notice code.
	 * @param int    $count  Optional number for the notice.
	 */
	private function finish( $notice, $count = 0 ) {
		$args = array( 'kagstm_notice' => $notice );
		if ( $count ) {
			$args['kagstm_count'] = $count;
		}
		wp_safe_redirect( $this->settings_url( $args ) );
		exit;
	}

	/**
	 * Start or stop Stock Take Mode with one click.
	 */
	public function handle_toggle() {
		if ( ! current_user_can( KAGSTM_Settings::capability() ) ) {
			wp_die( esc_html__( 'Unauthorized access.', 'kagunda-stock-take-mode-for-woocommerce' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'kagstm_toggle' );

		$mode = isset( $_GET['mode'] ) ? sanitize_key( wp_unslash( $_GET['mode'] ) ) : '';

		if ( 'on' === $mode ) {
			update_option( 'kagstm_enabled', '1' );

			$start = KAGSTM_Settings::to_timestamp( (string) KAGSTM_Settings::get( 'start_datetime' ) );
			$end   = KAGSTM_Settings::to_timestamp( (string) KAGSTM_Settings::get( 'end_datetime' ) );
			if ( null !== $start && $start > time() ) {
				update_option( 'kagstm_start_datetime', '' );
			}
			if ( null !== $end && $end <= time() ) {
				update_option( 'kagstm_end_datetime', '' );
			}
			$notice = 'started';
		} else {
			update_option( 'kagstm_enabled', '0' );
			$notice = 'stopped';
		}

		KAGSTM_Logger::log( 'on' === $mode ? 'Stock Take Mode switched on from the quick action.' : 'Stock Take Mode switched off from the quick action.', 'info' );
		KAGSTM_Core::instance()->sync_state();
		$this->finish( $notice );
	}

	/**
	 * Stream the waitlist as a CSV download.
	 */
	public function handle_csv_export() {
		if ( ! current_user_can( KAGSTM_Settings::capability() ) ) {
			wp_die( esc_html__( 'Unauthorized access.', 'kagunda-stock-take-mode-for-woocommerce' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'kagstm_export_csv' );

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=stock-take-waitlist-' . gmdate( 'Y-m-d' ) . '.csv' );

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- streaming a download to php://output.
		$output = fopen( 'php://output', 'w' );
		fputcsv( $output, array( 'Email Address', 'Date Subscribed' ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.prevent_path_disclosure_fputcsv -- false positive, no path is involved.

		foreach ( KAGSTM_Waitlist::all() as $subscriber ) {
			fputcsv( $output, array( $this->csv_safe( $subscriber['email'] ), $this->csv_safe( $subscriber['date'] ) ) );
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- closing the php://output stream.
		fclose( $output );
		exit;
	}

	/**
	 * Neutralise spreadsheet formula injection in CSV cells.
	 *
	 * @param string $value Cell value.
	 * @return string
	 */
	private function csv_safe( $value ) {
		$value = (string) $value;
		if ( '' !== $value && in_array( $value[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) ) {
			return "'" . $value;
		}
		return $value;
	}

	/**
	 * Stream the current settings as a downloadable JSON file.
	 */
	public function handle_settings_export() {
		if ( ! current_user_can( KAGSTM_Settings::capability() ) ) {
			wp_die( esc_html__( 'Unauthorized access.', 'kagunda-stock-take-mode-for-woocommerce' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'kagstm_export_settings' );

		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=stock-take-mode-settings-' . gmdate( 'Y-m-d' ) . '.json' );
		echo KAGSTM_Import_Export::export_json(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON download, encoded by wp_json_encode().
		exit;
	}

	/**
	 * Handle an uploaded settings JSON file and apply it.
	 */
	public function handle_settings_import() {
		if ( ! current_user_can( KAGSTM_Settings::capability() ) ) {
			wp_die( esc_html__( 'Unauthorized access.', 'kagunda-stock-take-mode-for-woocommerce' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'kagstm_import_settings', 'kagstm_import_nonce' );

		if ( ! isset( $_FILES['kagstm_import_file'] ) || ! is_array( $_FILES['kagstm_import_file'] ) ) {
			$this->finish( 'import_error' );
		}

		$file = $_FILES['kagstm_import_file']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each member is validated below.

		$upload_error = isset( $file['error'] ) ? absint( $file['error'] ) : UPLOAD_ERR_NO_FILE;
		$tmp_name     = isset( $file['tmp_name'] ) ? sanitize_text_field( $file['tmp_name'] ) : '';
		$name         = isset( $file['name'] ) ? sanitize_file_name( wp_unslash( $file['name'] ) ) : '';
		$size         = isset( $file['size'] ) ? absint( $file['size'] ) : 0;

		if ( UPLOAD_ERR_OK !== $upload_error || '' === $tmp_name || ! is_uploaded_file( $tmp_name ) ) {
			$this->finish( 'import_error' );
		}
		if ( 'json' !== strtolower( pathinfo( $name, PATHINFO_EXTENSION ) ) || $size > KAGSTM_Import_Export::MAX_FILE_SIZE ) {
			$this->finish( 'import_error' );
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- reading a just-validated PHP temp upload, not a remote or arbitrary path.
		$json   = file_get_contents( $tmp_name );
		$result = KAGSTM_Import_Export::import_json( $json );

		if ( is_wp_error( $result ) ) {
			KAGSTM_Logger::log( 'Settings import failed: ' . $result->get_error_message(), 'warning' );
			$this->finish( 'import_error' );
		}

		KAGSTM_Logger::log( 'Settings imported from an uploaded configuration file.', 'info' );
		KAGSTM_Core::instance()->sync_state();
		$this->finish( 'import_success' );
	}

	/**
	 * Remove one subscriber from the waitlist.
	 */
	public function handle_remove_subscriber() {
		if ( ! current_user_can( KAGSTM_Settings::capability() ) ) {
			wp_die( esc_html__( 'Unauthorized access.', 'kagunda-stock-take-mode-for-woocommerce' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'kagstm_remove_subscriber' );

		$email = isset( $_GET['email'] ) ? sanitize_email( wp_unslash( $_GET['email'] ) ) : '';
		if ( is_email( $email ) ) {
			KAGSTM_Waitlist::remove( $email );
		}

		$this->finish( 'subscriber_removed' );
	}

	/**
	 * Remove every subscriber from the waitlist.
	 */
	public function handle_clear_waitlist() {
		if ( ! current_user_can( KAGSTM_Settings::capability() ) ) {
			wp_die( esc_html__( 'Unauthorized access.', 'kagunda-stock-take-mode-for-woocommerce' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'kagstm_clear_waitlist' );

		KAGSTM_Waitlist::clear();
		KAGSTM_Logger::log( 'Waitlist cleared by an administrator.', 'info' );
		$this->finish( 'waitlist_cleared' );
	}

	/**
	 * Queue the re-open e-mail for the whole waitlist right now.
	 */
	public function handle_send_broadcast() {
		if ( ! current_user_can( KAGSTM_Settings::capability() ) ) {
			wp_die( esc_html__( 'Unauthorized access.', 'kagunda-stock-take-mode-for-woocommerce' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'kagstm_send_broadcast' );

		$queued = KAGSTM_Core::instance()->start_broadcast( true );
		if ( 0 === $queued ) {
			$this->finish( 'broadcast_none' );
		}
		$this->finish( 'broadcast_queued', $queued );
	}

	/**
	 * Reset the blocked-attempts counter.
	 */
	public function handle_reset_stats() {
		if ( ! current_user_can( KAGSTM_Settings::capability() ) ) {
			wp_die( esc_html__( 'Unauthorized access.', 'kagunda-stock-take-mode-for-woocommerce' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'kagstm_reset_stats' );

		delete_option( 'kagstm_stat_blocked_attempts' );
		$this->finish( 'stats_reset' );
	}

	// ----- AJAX -----.

	/**
	 * AJAX handler: product search for the exceptions field.
	 */
	public function ajax_search_products() {
		check_ajax_referer( 'kagstm-admin-nonce', 'security' );
		if ( ! current_user_can( KAGSTM_Settings::capability() ) ) {
			wp_send_json_error( 'Unauthorized', 403 );
		}

		$term = isset( $_GET['term'] ) ? sanitize_text_field( wp_unslash( $_GET['term'] ) ) : '';
		if ( '' === $term ) {
			wp_send_json( array() );
		}

		$data_store = WC_Data_Store::load( 'product' );
		$ids        = $data_store->search_products( $term, '', true, false, 30 );
		$results    = array();

		foreach ( $ids as $id ) {
			$product = wc_get_product( $id );
			if ( $product ) {
				$results[] = array(
					'id'   => $id,
					'text' => $product->get_name() . ' (#' . $id . ')',
				);
			}
		}
		wp_send_json( $results );
	}

	/**
	 * AJAX handler: send a preview of the broadcast e-mail to a test address.
	 */
	public function handle_admin_test_email() {
		check_ajax_referer( 'kagstm-admin-nonce', 'security' );
		if ( ! current_user_can( KAGSTM_Settings::capability() ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized', 'kagunda-stock-take-mode-for-woocommerce' ) ), 403 );
		}

		$test_email = isset( $_POST['test_email'] ) ? sanitize_email( wp_unslash( $_POST['test_email'] ) ) : (string) get_option( 'admin_email' );
		$subject    = isset( $_POST['subject'] ) ? sanitize_text_field( wp_unslash( $_POST['subject'] ) ) : '';
		$body       = isset( $_POST['body'] ) ? wp_kses_post( wp_unslash( $_POST['body'] ) ) : '';

		if ( ! is_email( $test_email ) ) {
			wp_send_json_error( array( 'message' => __( 'Please provide a valid test email address.', 'kagunda-stock-take-mode-for-woocommerce' ) ) );
		}

		$compiled = KAGSTM_Core::instance()->get_compiled_email_template( $subject, $body, $test_email );

		/* translators: %s: subject line of the test email. */
		$sent = wp_mail( $test_email, sprintf( __( '[TEST] %s', 'kagunda-stock-take-mode-for-woocommerce' ), $compiled['subject'] ), $compiled['body'], array( 'Content-Type: text/html; charset=UTF-8' ) );

		if ( $sent ) {
			/* translators: %s: email address the test message was sent to. */
			wp_send_json_success( array( 'message' => sprintf( __( 'Test broadcast email sent to %s.', 'kagunda-stock-take-mode-for-woocommerce' ), $test_email ) ) );
		}
		wp_send_json_error( array( 'message' => __( 'The server rejected sending the email. Check your mail settings.', 'kagunda-stock-take-mode-for-woocommerce' ) ) );
	}

	// ----- Dashboard widget and admin bar -----.

	/**
	 * Register the dashboard analytics widget.
	 */
	public function register_dashboard_analytics_widget() {
		if ( ! current_user_can( KAGSTM_Settings::capability() ) ) {
			return;
		}

		wp_add_dashboard_widget(
			'kagstm_analytics_dashboard_widget',
			__( 'Stock Take Mode', 'kagunda-stock-take-mode-for-woocommerce' ),
			array( $this, 'render_dashboard_analytics_widget' )
		);
	}

	/**
	 * Render the dashboard widget.
	 */
	public function render_dashboard_analytics_widget() {
		$status  = $this->get_status_info();
		$blocked = (int) get_option( 'kagstm_stat_blocked_attempts', 0 );
		?>
		<div class="kagstm-dashboard-widget">
			<p class="kagstm-widget-status">
				<span class="kagstm-status-badge <?php echo esc_attr( $status['class'] ); ?>"><?php echo esc_html( $status['label'] ); ?></span>
				<span><?php echo esc_html( $status['detail'] ); ?></span>
			</p>
			<div class="kagstm-widget-grid">
				<div class="kagstm-widget-stat">
					<span class="kagstm-widget-number kagstm-num-rose"><?php echo esc_html( number_format_i18n( $blocked ) ); ?></span>
					<span class="kagstm-widget-label"><?php esc_html_e( 'Blocked Attempts', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span>
				</div>
				<div class="kagstm-widget-stat">
					<span class="kagstm-widget-number kagstm-num-blue"><?php echo esc_html( number_format_i18n( KAGSTM_Waitlist::count() ) ); ?></span>
					<span class="kagstm-widget-label"><?php esc_html_e( 'Waitlist Subscribers', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span>
				</div>
			</div>
			<p class="kagstm-widget-footer">
				<a href="<?php echo esc_url( $this->settings_url() ); ?>"><?php esc_html_e( 'Manage Stock Take Mode', 'kagunda-stock-take-mode-for-woocommerce' ); ?></a>
			</p>
		</div>
		<?php
	}

	/**
	 * Style the admin bar indicator.
	 */
	public function enqueue_admin_bar_styles() {
		if ( ! is_admin_bar_showing() ) {
			return;
		}

		wp_add_inline_style(
			'admin-bar',
			'#wpadminbar #wp-admin-bar-kagstm-status > .ab-item{background:#e11d48;color:#fff;}'
			. '#wpadminbar #wp-admin-bar-kagstm-status:hover > .ab-item,#wpadminbar #wp-admin-bar-kagstm-status > .ab-item:focus{background:#be123c;color:#fff;}'
			. '#wpadminbar #wp-admin-bar-kagstm-status .ab-icon:before{content:"\f315";top:2px;color:#fff;}'
		);
	}

	/**
	 * Add a status indicator to the admin bar while the window is open.
	 *
	 * @param WP_Admin_Bar $wp_admin_bar Admin bar instance.
	 */
	public function render_admin_bar_indicator( $wp_admin_bar ) {
		if ( ! current_user_can( KAGSTM_Settings::capability() ) || '1' !== KAGSTM_Settings::get( 'show_admin_bar_indicator' ) ) {
			return;
		}

		$core       = KAGSTM_Core::instance();
		$previewing = $core->is_preview();

		if ( ! class_exists( 'WooCommerce' ) || ( ! $core->is_window_active() && ! $previewing ) ) {
			return;
		}

		$label = $previewing
			? __( 'Previewing Stock Take Mode', 'kagunda-stock-take-mode-for-woocommerce' )
			: __( 'Stock Take Mode Active', 'kagunda-stock-take-mode-for-woocommerce' );

		$wp_admin_bar->add_node(
			array(
				'id'    => 'kagstm-status',
				'title' => '<span class="ab-icon dashicons" aria-hidden="true"></span><span class="ab-label">' . esc_html( $label ) . '</span>',
				'href'  => $this->settings_url(),
				'meta'  => array( 'title' => __( 'Purchasing is currently restricted. Click to manage.', 'kagunda-stock-take-mode-for-woocommerce' ) ),
			)
		);

		$wp_admin_bar->add_node(
			array(
				'id'     => 'kagstm-status-settings',
				'parent' => 'kagstm-status',
				'title'  => esc_html__( 'Open settings', 'kagunda-stock-take-mode-for-woocommerce' ),
				'href'   => $this->settings_url(),
			)
		);

		if ( $core->is_window_active() ) {
			$wp_admin_bar->add_node(
				array(
					'id'     => 'kagstm-status-stop',
					'parent' => 'kagstm-status',
					'title'  => esc_html__( 'Turn off Stock Take Mode', 'kagunda-stock-take-mode-for-woocommerce' ),
					'href'   => $this->action_url( 'toggle', array( 'mode' => 'off' ) ),
				)
			);
		}
	}

	// ----- Assets -----.

	/**
	 * Enqueue admin assets on the settings screen and the dashboard.
	 *
	 * @param string $hook Current admin page hook suffix.
	 */
	public function enqueue_admin_assets( $hook ) {
		$is_settings  = false !== strpos( (string) $hook, self::PAGE );
		$is_dashboard = 'index.php' === $hook && current_user_can( KAGSTM_Settings::capability() );

		if ( ! $is_settings && ! $is_dashboard ) {
			return;
		}

		wp_enqueue_style( 'kagstm-admin', KAGSTM_PLUGIN_URL . 'assets/css/admin.css', array(), KAGSTM_VERSION );

		if ( ! $is_settings ) {
			return;
		}

		$has_select = wp_script_is( 'selectWoo', 'registered' );

		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );

		$deps = array( 'jquery', 'wp-color-picker' );
		if ( $has_select ) {
			wp_enqueue_script( 'selectWoo' );
			if ( wp_style_is( 'woocommerce_admin_styles', 'registered' ) ) {
				wp_enqueue_style( 'woocommerce_admin_styles' );
			}
			$deps[] = 'selectWoo';
		}

		wp_enqueue_script( 'kagstm-admin', KAGSTM_PLUGIN_URL . 'assets/js/admin.js', $deps, KAGSTM_VERSION, true );

		wp_localize_script(
			'kagstm-admin',
			'KAGSTM_Admin',
			array(
				'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
				'searchNonce' => wp_create_nonce( 'kagstm-admin-nonce' ),
				'nowLocal'    => wp_date( 'Y-m-d\TH:i' ),
				'hasSelect'   => $has_select,
				'i18n'        => array(
					'searchProducts'   => __( 'Search products...', 'kagunda-stock-take-mode-for-woocommerce' ),
					'searchCategories' => __( 'Choose categories...', 'kagunda-stock-take-mode-for-woocommerce' ),
					'dispatching'      => __( 'Sending...', 'kagunda-stock-take-mode-for-woocommerce' ),
					'testEmailFailed'  => __( 'The test email request failed.', 'kagunda-stock-take-mode-for-woocommerce' ),
					'previewFallback'  => __( 'Your notice message appears here.', 'kagunda-stock-take-mode-for-woocommerce' ),
					'confirmClear'     => __( 'Remove every subscriber from the waitlist? This cannot be undone.', 'kagunda-stock-take-mode-for-woocommerce' ),
					'confirmBroadcast' => __( 'Email the whole waitlist now and then clear it?', 'kagunda-stock-take-mode-for-woocommerce' ),
					'confirmRemove'    => __( 'Remove this subscriber?', 'kagunda-stock-take-mode-for-woocommerce' ),
				),
			)
		);
	}

	// ----- Settings page -----.

	/**
	 * Describe the current status for the header card, widget and badges.
	 *
	 * @return array{state:string,class:string,label:string,detail:string}
	 */
	private function get_status_info() {
		$state  = KAGSTM_Settings::window_state();
		$format = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );
		$start  = KAGSTM_Settings::to_timestamp( (string) KAGSTM_Settings::get( 'start_datetime' ) );
		$end    = KAGSTM_Settings::to_timestamp( (string) KAGSTM_Settings::get( 'end_datetime' ) );

		switch ( $state ) {
			case 'active':
				$detail = __( 'Purchasing is paused until you turn it off.', 'kagunda-stock-take-mode-for-woocommerce' );
				if ( null !== $end ) {
					/* translators: 1: end date and time, 2: human readable time difference, e.g. "2 days". */
					$detail = sprintf( __( 'Purchasing is paused. Ends %1$s (in %2$s).', 'kagunda-stock-take-mode-for-woocommerce' ), wp_date( $format, $end ), human_time_diff( time(), $end ) );
				}
				return array(
					'state'  => $state,
					'class'  => 'kagstm-status-active',
					'label'  => __( 'Active', 'kagunda-stock-take-mode-for-woocommerce' ),
					'detail' => $detail,
				);

			case 'waiting':
				return array(
					'state'  => $state,
					'class'  => 'kagstm-status-standby',
					'label'  => __( 'Scheduled', 'kagunda-stock-take-mode-for-woocommerce' ),
					/* translators: 1: start date and time, 2: human readable time difference. */
					'detail' => sprintf( __( 'Starts %1$s (in %2$s). The store is open until then.', 'kagunda-stock-take-mode-for-woocommerce' ), wp_date( $format, (int) $start ), human_time_diff( time(), (int) $start ) ),
				);

			case 'expired':
				return array(
					'state'  => $state,
					'class'  => 'kagstm-status-expired',
					'label'  => __( 'Ended', 'kagunda-stock-take-mode-for-woocommerce' ),
					'detail' => __( 'The scheduled window has ended and the store is open. Turn the switch off or set new dates.', 'kagunda-stock-take-mode-for-woocommerce' ),
				);

			default:
				return array(
					'state'  => 'disabled',
					'class'  => 'kagstm-status-disabled',
					'label'  => __( 'Off', 'kagunda-stock-take-mode-for-woocommerce' ),
					'detail' => __( 'The store is open. Turn on Stock Take Mode to pause purchasing.', 'kagunda-stock-take-mode-for-woocommerce' ),
				);
		}
	}

	/**
	 * Print a labelled on/off switch row.
	 *
	 * @param string $key         Setting key without prefix.
	 * @param string $label       Row label.
	 * @param string $description Help text.
	 * @param string $extra_html  Trusted, pre-escaped HTML printed under the switch.
	 */
	private function render_switch_row( $key, $label, $description = '', $extra_html = '' ) {
		$value = KAGSTM_Settings::get( $key );
		?>
		<div class="kagstm-row">
			<div class="kagstm-row-label">
				<label for="kagstm_<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label>
				<?php if ( '' !== $description ) : ?>
					<span><?php echo esc_html( $description ); ?></span>
				<?php endif; ?>
			</div>
			<div>
				<label class="kagstm-toggle-switch">
					<input type="checkbox" id="kagstm_<?php echo esc_attr( $key ); ?>" name="kagstm_<?php echo esc_attr( $key ); ?>" value="1" <?php checked( $value, '1' ); ?>>
					<span class="kagstm-slider"></span>
				</label>
				<?php echo wp_kses_post( $extra_html ); ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Render the settings page.
	 */
	public function render_settings_page() {
		if ( ! current_user_can( KAGSTM_Settings::capability() ) ) {
			return;
		}

		$status = $this->get_status_info();
		$state  = $status['state'];

		$start_datetime  = (string) KAGSTM_Settings::get( 'start_datetime' );
		$end_datetime    = (string) KAGSTM_Settings::get( 'end_datetime' );
		$bypass_roles    = KAGSTM_Settings::get( 'bypass_roles' );
		$product_ids     = KAGSTM_Settings::get( 'product_exceptions' );
		$category_ids    = KAGSTM_Settings::get( 'category_exceptions' );
		$bg_color        = (string) KAGSTM_Settings::get( 'bg_color' );
		$text_color      = (string) KAGSTM_Settings::get( 'text_color' );
		$button_behavior = KAGSTM_Settings::get( 'button_behavior' );
		$position        = KAGSTM_Settings::get( 'banner_position' );
		$scope           = KAGSTM_Settings::get( 'banner_scope' );
		$subscribers     = KAGSTM_Waitlist::all();
		$subscriber_num  = count( $subscribers );
		$blocked         = (int) get_option( 'kagstm_stat_blocked_attempts', 0 );
		$shop_url        = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
		$preview_url     = add_query_arg( 'kagstm_preview', '1', $shop_url );
		$timezone        = wp_timezone_string();
		$message         = (string) KAGSTM_Settings::get( 'message' );
		$show_limit      = 200;

		$presets = array(
			'rose'    => array( __( 'Rose', 'kagunda-stock-take-mode-for-woocommerce' ), '#e11d48', '#ffffff' ),
			'slate'   => array( __( 'Slate', 'kagunda-stock-take-mode-for-woocommerce' ), '#1e293b', '#ffffff' ),
			'indigo'  => array( __( 'Indigo', 'kagunda-stock-take-mode-for-woocommerce' ), '#4f46e5', '#ffffff' ),
			'emerald' => array( __( 'Emerald', 'kagunda-stock-take-mode-for-woocommerce' ), '#047857', '#ffffff' ),
			'amber'   => array( __( 'Amber', 'kagunda-stock-take-mode-for-woocommerce' ), '#fbbf24', '#1f2937' ),
		);
		?>
		<div class="wrap kagstm-wrap">
			<h1 class="kagstm-screen-title"><?php esc_html_e( 'Stock Take Mode for WooCommerce', 'kagunda-stock-take-mode-for-woocommerce' ); ?></h1>

			<div class="kagstm-header">
				<span class="kagstm-header-icon" aria-hidden="true">
					<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" focusable="false"><path d="M12 2.5 4.5 5.5v5.7c0 4.6 3.1 8.6 7.5 10.3 4.4-1.7 7.5-5.7 7.5-10.3V5.5L12 2.5Z"/><path d="M10 9.5v5M14 9.5v5"/></svg>
				</span>
				<div class="kagstm-header-text">
					<p class="kagstm-header-title"><?php esc_html_e( 'Stock Take Mode', 'kagunda-stock-take-mode-for-woocommerce' ); ?> <span class="kagstm-version">v<?php echo esc_html( KAGSTM_VERSION ); ?></span></p>
					<p class="kagstm-brand-sub"><?php esc_html_e( 'Pause purchasing during inventory counts, with a countdown banner, waitlist capture, and re-open notifications.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></p>
				</div>
			</div>

			<div class="kagstm-status-card">
				<div class="kagstm-status-main">
					<span class="kagstm-status-badge <?php echo esc_attr( $status['class'] ); ?>"><?php echo esc_html( $status['label'] ); ?></span>
					<p class="kagstm-status-detail"><?php echo esc_html( $status['detail'] ); ?></p>
				</div>
				<div class="kagstm-status-metrics">
					<div><strong><?php echo esc_html( number_format_i18n( $blocked ) ); ?></strong><span><?php esc_html_e( 'Blocked attempts', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span></div>
					<div><strong><?php echo esc_html( number_format_i18n( $subscriber_num ) ); ?></strong><span><?php esc_html_e( 'On waitlist', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span></div>
				</div>
				<div class="kagstm-status-actions">
					<?php if ( 'active' === $state ) : ?>
						<a class="button button-large kagstm-btn-stop" href="<?php echo esc_url( $this->action_url( 'toggle', array( 'mode' => 'off' ) ) ); ?>"><?php esc_html_e( 'Stop now', 'kagunda-stock-take-mode-for-woocommerce' ); ?></a>
					<?php else : ?>
						<a class="button button-primary button-large" href="<?php echo esc_url( $this->action_url( 'toggle', array( 'mode' => 'on' ) ) ); ?>"><?php esc_html_e( 'Start now', 'kagunda-stock-take-mode-for-woocommerce' ); ?></a>
					<?php endif; ?>
					<a class="button button-large" href="<?php echo esc_url( $preview_url ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Preview as customer', 'kagunda-stock-take-mode-for-woocommerce' ); ?></a>
				</div>
			</div>

			<div class="kagstm-container">
				<div class="kagstm-tabs-nav" role="tablist">
					<a href="#tab-core" class="nav-tab kagstm-nav-tab nav-tab-active" role="tab"><?php esc_html_e( 'Rules', 'kagunda-stock-take-mode-for-woocommerce' ); ?></a>
					<a href="#tab-ui" class="nav-tab kagstm-nav-tab" role="tab"><?php esc_html_e( 'Design & Engagement', 'kagunda-stock-take-mode-for-woocommerce' ); ?></a>
					<a href="#tab-subscribers" class="nav-tab kagstm-nav-tab" role="tab">
						<?php
						/* translators: %d: number of waitlist subscribers. */
						echo esc_html( sprintf( __( 'Waitlist (%d)', 'kagunda-stock-take-mode-for-woocommerce' ), $subscriber_num ) );
						?>
					</a>
					<a href="#tab-tools" class="nav-tab kagstm-nav-tab" role="tab"><?php esc_html_e( 'Import / Export', 'kagunda-stock-take-mode-for-woocommerce' ); ?></a>
				</div>

				<form method="post" action="options.php" id="kagstm-settings-form">
					<?php settings_fields( KAGSTM_Settings::OPTION_GROUP ); ?>

					<div id="tab-core" class="kagstm-tab-content active">
						<?php
						$this->render_switch_row(
							'enabled',
							__( 'Restrictions', 'kagunda-stock-take-mode-for-woocommerce' ),
							__( 'Master switch. When on, purchasing is paused for the schedule below.', 'kagunda-stock-take-mode-for-woocommerce' )
						);
						$this->render_switch_row(
							'admin_alerts',
							__( 'Admin Email Alerts', 'kagunda-stock-take-mode-for-woocommerce' ),
							__( 'Email the store admin when stock take mode starts or ends.', 'kagunda-stock-take-mode-for-woocommerce' )
						);
						$this->render_switch_row(
							'show_admin_bar_indicator',
							__( 'Admin Bar Indicator', 'kagunda-stock-take-mode-for-woocommerce' ),
							__( 'Show a status badge with a quick "turn off" link in the toolbar while active.', 'kagunda-stock-take-mode-for-woocommerce' )
						);
						?>

						<div class="kagstm-row">
							<div class="kagstm-row-label">
								<label for="kagstm_start_datetime"><?php esc_html_e( 'Start Window', 'kagunda-stock-take-mode-for-woocommerce' ); ?></label>
								<span>
									<?php
									printf(
										/* translators: %s: store timezone string. */
										esc_html__( 'Leave blank to activate immediately. Uses store time: %s.', 'kagunda-stock-take-mode-for-woocommerce' ),
										'<code>' . esc_html( $timezone ) . '</code>'
									);
									?>
								</span>
							</div>
							<div>
								<input type="datetime-local" id="kagstm_start_datetime" name="kagstm_start_datetime" class="kagstm-datetime-field" value="<?php echo esc_attr( $start_datetime ); ?>">
							</div>
						</div>
						<div class="kagstm-row">
							<div class="kagstm-row-label">
								<label for="kagstm_end_datetime"><?php esc_html_e( 'End Window', 'kagunda-stock-take-mode-for-woocommerce' ); ?></label>
								<span><?php esc_html_e( 'Leave blank to stay in stock-take mode until manually turned off.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span>
							</div>
							<div>
								<input type="datetime-local" id="kagstm_end_datetime" name="kagstm_end_datetime" class="kagstm-datetime-field" value="<?php echo esc_attr( $end_datetime ); ?>">
								<div class="kagstm-quick-end" role="group" aria-label="<?php esc_attr_e( 'Quick end time', 'kagunda-stock-take-mode-for-woocommerce' ); ?>">
									<span><?php esc_html_e( 'Ends in:', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span>
									<button type="button" class="button button-small" data-hours="1"><?php esc_html_e( '1 hour', 'kagunda-stock-take-mode-for-woocommerce' ); ?></button>
									<button type="button" class="button button-small" data-hours="4"><?php esc_html_e( '4 hours', 'kagunda-stock-take-mode-for-woocommerce' ); ?></button>
									<button type="button" class="button button-small" data-hours="24"><?php esc_html_e( '1 day', 'kagunda-stock-take-mode-for-woocommerce' ); ?></button>
									<button type="button" class="button button-small" data-hours="72"><?php esc_html_e( '3 days', 'kagunda-stock-take-mode-for-woocommerce' ); ?></button>
									<button type="button" class="button-link kagstm-clear-dates"><?php esc_html_e( 'Clear dates', 'kagunda-stock-take-mode-for-woocommerce' ); ?></button>
								</div>
							</div>
						</div>

						<?php
						$this->render_switch_row(
							'clear_cart',
							__( 'Clear Active Carts', 'kagunda-stock-take-mode-for-woocommerce' ),
							__( 'Remove restricted items from customers\' carts while Stock Take Mode is active.', 'kagunda-stock-take-mode-for-woocommerce' )
						);
						?>

						<div class="kagstm-row">
							<div class="kagstm-row-label"><?php esc_html_e( 'Bypass Roles', 'kagunda-stock-take-mode-for-woocommerce' ); ?><span><?php esc_html_e( 'These roles can keep shopping normally. Use "Preview as customer" to see what everyone else sees.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span></div>
							<div class="kagstm-checks">
								<?php foreach ( wp_roles()->roles as $role_key => $role ) : ?>
									<label>
										<input type="checkbox" name="kagstm_bypass_roles[]" value="<?php echo esc_attr( $role_key ); ?>" <?php checked( in_array( $role_key, $bypass_roles, true ) ); ?>>
										<?php echo esc_html( translate_user_role( $role['name'] ) ); ?>
									</label>
								<?php endforeach; ?>
							</div>
						</div>

						<div class="kagstm-row">
							<div class="kagstm-row-label"><label for="kagstm_product_exceptions"><?php esc_html_e( 'Product Exceptions', 'kagunda-stock-take-mode-for-woocommerce' ); ?></label><span><?php esc_html_e( 'These products stay purchasable.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span></div>
							<div>
								<select id="kagstm_product_exceptions" name="kagstm_product_exceptions[]" class="kagstm-product-select" multiple>
									<?php
									foreach ( $product_ids as $product_id ) {
										$product = wc_get_product( $product_id );
										if ( $product ) {
											printf(
												'<option value="%1$d" selected>%2$s (#%1$d)</option>',
												absint( $product_id ),
												esc_html( $product->get_name() )
											);
										}
									}
									?>
								</select>
							</div>
						</div>

						<div class="kagstm-row">
							<div class="kagstm-row-label"><label for="kagstm_category_exceptions"><?php esc_html_e( 'Category Exceptions', 'kagunda-stock-take-mode-for-woocommerce' ); ?></label><span><?php esc_html_e( 'Every product in these categories stays purchasable.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span></div>
							<div>
								<select id="kagstm_category_exceptions" name="kagstm_category_exceptions[]" class="kagstm-category-select" multiple>
									<?php
									$categories = get_terms(
										array(
											'taxonomy'   => 'product_cat',
											'hide_empty' => false,
										)
									);
									if ( ! is_wp_error( $categories ) ) {
										foreach ( $categories as $category ) {
											printf(
												'<option value="%1$d" %2$s>%3$s</option>',
												absint( $category->term_id ),
												selected( in_array( $category->term_id, $category_ids, true ), true, false ),
												esc_html( $category->name )
											);
										}
									}
									?>
								</select>
							</div>
						</div>
					</div>

					<div id="tab-ui" class="kagstm-tab-content">
						<div class="kagstm-row">
							<div class="kagstm-row-label"><?php esc_html_e( 'Live Preview', 'kagunda-stock-take-mode-for-woocommerce' ); ?><span><?php esc_html_e( 'A quick look at your banner. The real banner picks up your theme fonts.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span></div>
							<div>
								<div class="kagstm-preview" id="kagstm-preview" style="--kagstm-bg:<?php echo esc_attr( $bg_color ); ?>;--kagstm-text:<?php echo esc_attr( $text_color ); ?>;" aria-hidden="true">
									<span class="kagstm-preview-icon">
										<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" focusable="false"><path d="M12 2.5 4.5 5.5v5.7c0 4.6 3.1 8.6 7.5 10.3 4.4-1.7 7.5-5.7 7.5-10.3V5.5L12 2.5Z"/><path d="M10 9.5v5M14 9.5v5"/></svg>
									</span>
									<span class="kagstm-preview-text" id="kagstm-preview-text"></span>
									<span class="kagstm-preview-clock" id="kagstm-preview-clock">02d 14h 32m 08s</span>
									<span class="kagstm-preview-form" id="kagstm-preview-form"><span class="kagstm-preview-input"><?php esc_html_e( 'Notify me when open...', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span><span class="kagstm-preview-btn"><?php esc_html_e( 'Join Waitlist', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span></span>
								</div>
							</div>
						</div>

						<div class="kagstm-row">
							<div class="kagstm-row-label"><?php esc_html_e( 'Notice Message', 'kagunda-stock-take-mode-for-woocommerce' ); ?><span><?php esc_html_e( 'Defaults to "Sorry, we are closed for stock intake." if left empty.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span></div>
							<div>
							<?php
							wp_editor(
								$message,
								'kagstm_message',
								array(
									'textarea_name' => 'kagstm_message',
									'textarea_rows' => 4,
									'media_buttons' => false,
								)
							);
							?>
									</div>
						</div>

						<div class="kagstm-row">
							<div class="kagstm-row-label"><?php esc_html_e( 'Banner Colors', 'kagunda-stock-take-mode-for-woocommerce' ); ?><span><?php esc_html_e( 'Pick a preset or choose your own colors.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span></div>
							<div>
								<div class="kagstm-presets" role="group" aria-label="<?php esc_attr_e( 'Color presets', 'kagunda-stock-take-mode-for-woocommerce' ); ?>">
									<?php foreach ( $presets as $preset ) : ?>
										<button type="button" class="kagstm-preset" data-bg="<?php echo esc_attr( $preset[1] ); ?>" data-text="<?php echo esc_attr( $preset[2] ); ?>" style="background:<?php echo esc_attr( $preset[1] ); ?>;color:<?php echo esc_attr( $preset[2] ); ?>;"><?php echo esc_html( $preset[0] ); ?></button>
									<?php endforeach; ?>
								</div>
								<div class="kagstm-color-pair">
									<label for="kagstm_bg_color"><?php esc_html_e( 'Background', 'kagunda-stock-take-mode-for-woocommerce' ); ?></label>
									<input type="text" id="kagstm_bg_color" name="kagstm_bg_color" class="kagstm-color-field" value="<?php echo esc_attr( $bg_color ); ?>" data-default-color="#e11d48">
									<label for="kagstm_text_color"><?php esc_html_e( 'Text', 'kagunda-stock-take-mode-for-woocommerce' ); ?></label>
									<input type="text" id="kagstm_text_color" name="kagstm_text_color" class="kagstm-color-field" value="<?php echo esc_attr( $text_color ); ?>" data-default-color="#ffffff">
								</div>
							</div>
						</div>

						<div class="kagstm-row">
							<div class="kagstm-row-label"><label for="kagstm_banner_position"><?php esc_html_e( 'Banner Position', 'kagunda-stock-take-mode-for-woocommerce' ); ?></label></div>
							<div>
								<select id="kagstm_banner_position" name="kagstm_banner_position" class="kagstm-input-select">
									<option value="top_sticky" <?php selected( $position, 'top_sticky' ); ?>><?php esc_html_e( 'Top of the page, stays visible while scrolling', 'kagunda-stock-take-mode-for-woocommerce' ); ?></option>
									<option value="top_static" <?php selected( $position, 'top_static' ); ?>><?php esc_html_e( 'Top of the page, scrolls away', 'kagunda-stock-take-mode-for-woocommerce' ); ?></option>
									<option value="bottom" <?php selected( $position, 'bottom' ); ?>><?php esc_html_e( 'Bottom of the screen', 'kagunda-stock-take-mode-for-woocommerce' ); ?></option>
								</select>
							</div>
						</div>
						<div class="kagstm-row">
							<div class="kagstm-row-label"><label for="kagstm_banner_scope"><?php esc_html_e( 'Show Banner On', 'kagunda-stock-take-mode-for-woocommerce' ); ?></label></div>
							<div>
								<select id="kagstm_banner_scope" name="kagstm_banner_scope" class="kagstm-input-select">
									<option value="all" <?php selected( $scope, 'all' ); ?>><?php esc_html_e( 'Every page of the site', 'kagunda-stock-take-mode-for-woocommerce' ); ?></option>
									<option value="shop" <?php selected( $scope, 'shop' ); ?>><?php esc_html_e( 'Shop, product, cart and checkout pages only', 'kagunda-stock-take-mode-for-woocommerce' ); ?></option>
								</select>
							</div>
						</div>

						<?php
						$this->render_switch_row( 'show_countdown', __( 'Countdown Timer', 'kagunda-stock-take-mode-for-woocommerce' ), __( 'Shows a live countdown to your End Window in the banner.', 'kagunda-stock-take-mode-for-woocommerce' ) );
						$this->render_switch_row( 'enable_waitlist', __( 'Waitlist Signup Form', 'kagunda-stock-take-mode-for-woocommerce' ), __( 'Adds an email field to the banner.', 'kagunda-stock-take-mode-for-woocommerce' ) );
						?>

						<div class="kagstm-row">
							<div class="kagstm-row-label"><label for="kagstm_waitlist_note"><?php esc_html_e( 'Waitlist Privacy Note', 'kagunda-stock-take-mode-for-woocommerce' ); ?></label><span><?php esc_html_e( 'Small print shown under the email field. Leave blank to hide it.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span></div>
							<div><input type="text" id="kagstm_waitlist_note" name="kagstm_waitlist_note" class="kagstm-input-text" value="<?php echo esc_attr( (string) KAGSTM_Settings::get( 'waitlist_note' ) ); ?>"></div>
						</div>

						<?php
						$this->render_switch_row( 'broadcast_complete', __( 'Auto Broadcast on Re-open', 'kagunda-stock-take-mode-for-woocommerce' ), __( 'Email the waitlist automatically once stock take ends.', 'kagunda-stock-take-mode-for-woocommerce' ) );
						?>

						<div class="kagstm-row">
							<div class="kagstm-row-label">
								<label for="kagstm_broadcast_subject"><?php esc_html_e( 'Broadcast Subject', 'kagunda-stock-take-mode-for-woocommerce' ); ?></label>
								<span><?php esc_html_e( 'Placeholders:', 'kagunda-stock-take-mode-for-woocommerce' ); ?> <span class="kagstm-token">{site_name}</span> <span class="kagstm-token">{site_url}</span></span>
							</div>
							<div><input type="text" id="kagstm_broadcast_subject" name="kagstm_broadcast_subject" class="kagstm-input-text" value="<?php echo esc_attr( (string) KAGSTM_Settings::get( 'broadcast_subject' ) ); ?>"></div>
						</div>
						<div class="kagstm-row">
							<div class="kagstm-row-label">
								<?php esc_html_e( 'Broadcast Body', 'kagunda-stock-take-mode-for-woocommerce' ); ?>
								<span><?php esc_html_e( 'Placeholders:', 'kagunda-stock-take-mode-for-woocommerce' ); ?> <span class="kagstm-token">{site_name}</span> <span class="kagstm-token">{site_url}</span> <span class="kagstm-token">{shop_url}</span> <span class="kagstm-token">{customer_email}</span></span>
							</div>
							<div>
								<?php
								wp_editor(
									(string) KAGSTM_Settings::get( 'broadcast_body' ),
									'kagstm_broadcast_body',
									array(
										'textarea_name' => 'kagstm_broadcast_body',
										'textarea_rows' => 6,
										'media_buttons' => false,
									)
								);
								?>
								<div class="kagstm-test-box">
									<label for="kagstm-test-target-input" class="kagstm-test-title"><?php esc_html_e( 'Send a test email', 'kagunda-stock-take-mode-for-woocommerce' ); ?></label>
									<div class="kagstm-test-controls">
										<input type="email" id="kagstm-test-target-input" class="regular-text" value="<?php echo esc_attr( get_option( 'admin_email' ) ); ?>">
										<button type="button" id="kagstm-trigger-test-mail" class="button button-secondary"><?php esc_html_e( 'Send Test Email', 'kagunda-stock-take-mode-for-woocommerce' ); ?></button>
									</div>
									<p class="kagstm-test-result" id="kagstm-test-result" role="status" aria-live="polite"></p>
								</div>
							</div>
						</div>

						<div class="kagstm-row">
							<div class="kagstm-row-label"><label for="kagstm_button_behavior"><?php esc_html_e( 'Add-to-Cart Button Behavior', 'kagunda-stock-take-mode-for-woocommerce' ); ?></label></div>
							<div>
								<select id="kagstm_button_behavior" name="kagstm_button_behavior" class="kagstm-input-select">
									<option value="hide" <?php selected( $button_behavior, 'hide' ); ?>><?php esc_html_e( 'Hide add-to-cart buttons entirely', 'kagunda-stock-take-mode-for-woocommerce' ); ?></option>
									<option value="disable_text" <?php selected( $button_behavior, 'disable_text' ); ?>><?php esc_html_e( 'Replace with custom text', 'kagunda-stock-take-mode-for-woocommerce' ); ?></option>
									<option value="inactive_only" <?php selected( $button_behavior, 'inactive_only' ); ?>><?php esc_html_e( 'Keep visible but disabled', 'kagunda-stock-take-mode-for-woocommerce' ); ?></option>
								</select>
							</div>
						</div>
						<div class="kagstm-row">
							<div class="kagstm-row-label"><label for="kagstm_button_text"><?php esc_html_e( 'Disabled Button Text', 'kagunda-stock-take-mode-for-woocommerce' ); ?></label><span><?php esc_html_e( 'Used when the behavior is "Replace with custom text".', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span></div>
							<div><input type="text" id="kagstm_button_text" name="kagstm_button_text" class="kagstm-input-text" value="<?php echo esc_attr( (string) KAGSTM_Settings::get( 'button_text' ) ); ?>"></div>
						</div>
					</div>

					<div class="kagstm-footer" id="kagstm-form-footer">
						<span><?php esc_html_e( 'Changes apply to the storefront as soon as you save.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span>
						<?php submit_button( __( 'Save Changes', 'kagunda-stock-take-mode-for-woocommerce' ), 'primary button-large', 'submit', false ); ?>
					</div>
				</form>

				<div id="tab-subscribers" class="kagstm-tab-content">
					<div class="kagstm-tab-head">
						<div>
							<h2><?php esc_html_e( 'Waitlist Subscribers', 'kagunda-stock-take-mode-for-woocommerce' ); ?></h2>
							<p><?php esc_html_e( 'Customers waiting to be notified when the store re-opens.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></p>
						</div>
						<?php if ( $subscriber_num > 0 ) : ?>
							<div class="kagstm-tab-actions">
								<input type="search" id="kagstm-waitlist-search" class="kagstm-search" placeholder="<?php esc_attr_e( 'Search emails...', 'kagunda-stock-take-mode-for-woocommerce' ); ?>" aria-label="<?php esc_attr_e( 'Search waitlist emails', 'kagunda-stock-take-mode-for-woocommerce' ); ?>">
								<a href="<?php echo esc_url( $this->action_url( 'export_csv' ) ); ?>" class="button"><?php esc_html_e( 'Export CSV', 'kagunda-stock-take-mode-for-woocommerce' ); ?></a>
								<a href="<?php echo esc_url( $this->action_url( 'send_broadcast' ) ); ?>" class="button" data-confirm="broadcast"><?php esc_html_e( 'Email everyone now', 'kagunda-stock-take-mode-for-woocommerce' ); ?></a>
								<a href="<?php echo esc_url( $this->action_url( 'clear_waitlist' ) ); ?>" class="button kagstm-btn-danger" data-confirm="clear"><?php esc_html_e( 'Clear list', 'kagunda-stock-take-mode-for-woocommerce' ); ?></a>
							</div>
						<?php endif; ?>
					</div>

					<div class="kagstm-table-wrapper">
						<table class="kagstm-data-table" id="kagstm-waitlist-table">
							<thead>
								<tr>
									<th class="kagstm-col-num">#</th>
									<th><?php esc_html_e( 'Email Address', 'kagunda-stock-take-mode-for-woocommerce' ); ?></th>
									<th><?php esc_html_e( 'Subscribed On', 'kagunda-stock-take-mode-for-woocommerce' ); ?></th>
									<th class="kagstm-col-action"><span class="kagstm-sr-only"><?php esc_html_e( 'Actions', 'kagunda-stock-take-mode-for-woocommerce' ); ?></span></th>
								</tr>
							</thead>
							<tbody>
								<?php if ( empty( $subscribers ) ) : ?>
									<tr>
										<td colspan="4" class="kagstm-empty-row"><?php esc_html_e( 'No subscriptions yet.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></td>
									</tr>
								<?php else : ?>
									<?php
									$index = 1;
									foreach ( array_slice( array_reverse( $subscribers ), 0, $show_limit ) as $subscriber ) :
										$timestamp = strtotime( $subscriber['date'] );
										?>
										<tr>
											<td><?php echo esc_html( $index++ ); ?></td>
											<td class="kagstm-email-cell"><strong><?php echo esc_html( $subscriber['email'] ); ?></strong></td>
											<td><?php echo esc_html( $timestamp ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp ) : '' ); ?></td>
											<td class="kagstm-col-action"><a href="<?php echo esc_url( $this->action_url( 'remove_subscriber', array( 'email' => $subscriber['email'] ) ) ); ?>" data-confirm="remove"><?php esc_html_e( 'Remove', 'kagunda-stock-take-mode-for-woocommerce' ); ?></a></td>
										</tr>
									<?php endforeach; ?>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
					<?php if ( $subscriber_num > $show_limit ) : ?>
						<p class="description">
							<?php
							/* translators: 1: number shown, 2: total subscribers. */
							echo esc_html( sprintf( __( 'Showing the newest %1$d of %2$d subscribers. Export the CSV for the full list.', 'kagunda-stock-take-mode-for-woocommerce' ), $show_limit, $subscriber_num ) );
							?>
						</p>
					<?php endif; ?>
				</div>

				<div id="tab-tools" class="kagstm-tab-content">
					<h2><?php esc_html_e( 'Export Settings', 'kagunda-stock-take-mode-for-woocommerce' ); ?></h2>
					<p class="kagstm-help"><?php esc_html_e( 'Download your current configuration as a JSON file, useful for backups or setting up another store.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></p>
					<p><a class="button button-secondary" href="<?php echo esc_url( $this->action_url( 'export_settings' ) ); ?>"><?php esc_html_e( 'Download Configuration', 'kagunda-stock-take-mode-for-woocommerce' ); ?></a></p>

					<hr>

					<h2><?php esc_html_e( 'Import Settings', 'kagunda-stock-take-mode-for-woocommerce' ); ?></h2>
					<p class="kagstm-help"><?php esc_html_e( 'Upload a configuration file previously exported from this plugin. It replaces your current settings.', 'kagunda-stock-take-mode-for-woocommerce' ); ?></p>
					<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="kagstm_import_settings">
						<?php wp_nonce_field( 'kagstm_import_settings', 'kagstm_import_nonce' ); ?>
						<div class="kagstm-import-export">
							<label class="kagstm-sr-only" for="kagstm_import_file"><?php esc_html_e( 'Configuration file', 'kagunda-stock-take-mode-for-woocommerce' ); ?></label>
							<input type="file" id="kagstm_import_file" name="kagstm_import_file" accept=".json,application/json" required>
							<?php submit_button( __( 'Import Configuration', 'kagunda-stock-take-mode-for-woocommerce' ), 'secondary', 'kagstm_do_import', false ); ?>
						</div>
					</form>

					<hr>

					<h2><?php esc_html_e( 'Statistics', 'kagunda-stock-take-mode-for-woocommerce' ); ?></h2>
					<p class="kagstm-help">
						<?php
						/* translators: %s: number of blocked purchase attempts. */
						echo esc_html( sprintf( _n( '%s purchase attempt has been blocked so far.', '%s purchase attempts have been blocked so far.', $blocked, 'kagunda-stock-take-mode-for-woocommerce' ), number_format_i18n( $blocked ) ) );
						?>
					</p>
					<p><a class="button button-secondary" href="<?php echo esc_url( $this->action_url( 'reset_stats' ) ); ?>"><?php esc_html_e( 'Reset counter', 'kagunda-stock-take-mode-for-woocommerce' ); ?></a></p>
				</div>
			</div>
		</div>
		<?php
	}
}
