<?php
/**
 * Store-facing engine for Stock Take Mode for WooCommerce.
 *
 * Handles state tracking, purchasing restrictions, the storefront banner,
 * waitlist sign-ups and the re-open broadcast.
 *
 * @package Kagunda_Stock_Take_Mode_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Core engine.
 */
class KAGSTM_Core {

	/**
	 * Singleton instance.
	 *
	 * @var KAGSTM_Core|null
	 */
	private static $instance = null;

	/**
	 * Whether an admin is previewing the customer view (null = not yet known).
	 *
	 * @var bool|null
	 */
	private $preview = null;

	/**
	 * Per-request cache of effective product exceptions.
	 *
	 * @var int[]|null
	 */
	private $exceptions = null;

	/**
	 * Whether the banner has already been printed on this request.
	 *
	 * @var bool
	 */
	private $banner_rendered = false;

	/**
	 * Whether cron events need re-scheduling at shutdown.
	 *
	 * @var bool
	 */
	private $reschedule_pending = false;

	/**
	 * Get the singleton instance.
	 *
	 * @return KAGSTM_Core
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Wire up hooks.
	 */
	private function __construct() {
		add_action( 'init', array( $this, 'maybe_upgrade' ), 1 );
		add_action( 'init', array( $this, 'maybe_init_restrictions' ), 10 );

		add_action( 'kagstm_check_state', array( $this, 'sync_state' ) );
		add_action( 'kagstm_process_broadcast_queue', array( $this, 'process_broadcast_queue' ) );

		add_action( 'wp_ajax_kagstm_subscribe_email', array( $this, 'handle_banner_subscription' ) );
		add_action( 'wp_ajax_nopriv_kagstm_subscribe_email', array( $this, 'handle_banner_subscription' ) );

		add_action( 'updated_option', array( $this, 'on_option_change' ) );
		add_action( 'added_option', array( $this, 'on_option_change' ) );
		add_action( 'woocommerce_update_product', array( $this, 'flush_category_cache' ) );
		add_action( 'woocommerce_new_product', array( $this, 'flush_category_cache' ) );
	}

	// ----- Upgrades -----.

	/**
	 * Run one-time upgrade routines.
	 */
	public function maybe_upgrade() {
		$this->maybe_migrate_legacy_options();

		if ( get_option( 'kagstm_db_version', '' ) === KAGSTM_VERSION ) {
			return;
		}

		// 1.0.1: the waitlist and counter should never be autoloaded.
		foreach ( array( KAGSTM_Waitlist::OPTION, 'kagstm_stat_blocked_attempts' ) as $option_name ) {
			$value = get_option( $option_name, null );
			if ( null === $value ) {
				continue;
			}
			if ( function_exists( 'wp_set_option_autoload' ) ) {
				wp_set_option_autoload( $option_name, false );
			} else {
				delete_option( $option_name );
				add_option( $option_name, $value, '', 'no' );
			}
		}

		$this->schedule_events();
		update_option( 'kagstm_db_version', KAGSTM_VERSION );
	}

	/**
	 * One-time, best-effort migration from the plugin's earlier "wc_stm_"
	 * option prefix to the current "kagstm_" prefix.
	 */
	private function maybe_migrate_legacy_options() {
		if ( '1' === get_option( 'kagstm_legacy_migration_done', '' ) ) {
			return;
		}

		$legacy_map = array(
			'wc_stm_enabled'                => 'kagstm_enabled',
			'wc_stm_start_datetime'         => 'kagstm_start_datetime',
			'wc_stm_end_datetime'           => 'kagstm_end_datetime',
			'wc_stm_message'                => 'kagstm_message',
			'wc_stm_button_behavior'        => 'kagstm_button_behavior',
			'wc_stm_button_text'            => 'kagstm_button_text',
			'wc_stm_bg_color'               => 'kagstm_bg_color',
			'wc_stm_text_color'             => 'kagstm_text_color',
			'wc_stm_clear_cart'             => 'kagstm_clear_cart',
			'wc_stm_show_countdown'         => 'kagstm_show_countdown',
			'wc_stm_enable_waitlist'        => 'kagstm_enable_waitlist',
			'wc_stm_admin_alerts'           => 'kagstm_admin_alerts',
			'wc_stm_broadcast_complete'     => 'kagstm_broadcast_complete',
			'wc_stm_broadcast_subject'      => 'kagstm_broadcast_subject',
			'wc_stm_broadcast_body'         => 'kagstm_broadcast_body',
			'wc_stm_bypass_roles'           => 'kagstm_bypass_roles',
			'wc_stm_product_exceptions'     => 'kagstm_product_exceptions',
			'wc_stm_last_known_state'       => 'kagstm_last_known_state',
			'wc_stm_stat_blocked_attempts'  => 'kagstm_stat_blocked_attempts',
			'wc_stm_subscriber_waitlist_v2' => 'kagstm_subscriber_waitlist',
		);

		foreach ( $legacy_map as $old_key => $new_key ) {
			$old_value = get_option( $old_key, null );
			if ( null !== $old_value && false === get_option( $new_key, false ) ) {
				update_option( $new_key, $old_value );
			}
		}

		update_option( 'kagstm_legacy_migration_done', '1' );
		KAGSTM_Logger::log( 'Legacy "wc_stm_" settings migrated to the "kagstm_" prefix after the plugin rename.', 'info' );
	}

	// ----- State -----.

	/**
	 * Whether the current visitor is a staff member who bypasses restrictions.
	 *
	 * @return bool
	 */
	public function user_bypasses() {
		if ( ! is_user_logged_in() ) {
			return false;
		}

		$user = wp_get_current_user();
		return (bool) array_intersect( (array) $user->roles, KAGSTM_Settings::get( 'bypass_roles' ) );
	}

	/**
	 * Whether the current visitor asked to see the store as a customer.
	 *
	 * Only users who can manage the plugin can use this, and it only changes
	 * what that user sees on that page load.
	 *
	 * @return bool
	 */
	public function is_preview() {
		if ( null === $this->preview ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only display flag, gated by a capability check below.
			$requested     = isset( $_GET['kagstm_preview'] ) && ! is_admin();
			$this->preview = $requested && is_user_logged_in() && current_user_can( KAGSTM_Settings::capability() );
		}
		return $this->preview;
	}

	/**
	 * Whether the configured window is currently open, for everybody.
	 *
	 * @return bool
	 */
	public function is_window_active() {
		return (bool) apply_filters( 'kagstm_is_window_active', 'active' === KAGSTM_Settings::window_state() );
	}

	/**
	 * Whether restrictions apply to the current visitor.
	 *
	 * @return bool
	 */
	public function is_stock_take_active() {
		if ( $this->is_preview() ) {
			return true;
		}

		return $this->is_window_active() && ! $this->user_bypasses();
	}

	/**
	 * Track start/end transitions and send the matching notifications.
	 *
	 * Uses the global window state, never the current visitor, so staff
	 * browsing the site can not trigger a false "ended" transition.
	 */
	public function sync_state() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		$is_active  = $this->is_window_active();
		$last_state = get_option( 'kagstm_last_known_state', 'inactive' );

		if ( $is_active && 'active' !== $last_state ) {
			// update_option() only returns true for the request that really changed the value.
			if ( update_option( 'kagstm_last_known_state', 'active' ) ) {
				KAGSTM_Logger::log( 'Stock Take Mode started.', 'info' );
				$this->send_admin_status_email( __( 'Initiated', 'kagunda-stock-take-mode-for-woocommerce' ) );
				do_action( 'kagstm_started' );
			}
		} elseif ( ! $is_active && 'active' === $last_state ) {
			if ( update_option( 'kagstm_last_known_state', 'inactive' ) ) {
				KAGSTM_Logger::log( 'Stock Take Mode ended.', 'info' );
				$this->send_admin_status_email( __( 'Expired / Deactivated', 'kagunda-stock-take-mode-for-woocommerce' ) );
				$this->start_broadcast();
				do_action( 'kagstm_ended' );
			}
		}
	}

	/**
	 * Track state, then hook the storefront restrictions when they apply.
	 */
	public function maybe_init_restrictions() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		$this->sync_state();

		if ( $this->is_stock_take_active() ) {
			$this->init_restrictions();
		}
	}

	/**
	 * Flag that cron events must be re-scheduled once this request ends.
	 *
	 * @param string $option Name of the option that changed.
	 */
	public function on_option_change( $option ) {
		if ( in_array( $option, array( 'kagstm_enabled', 'kagstm_start_datetime', 'kagstm_end_datetime' ), true ) ) {
			if ( ! $this->reschedule_pending ) {
				$this->reschedule_pending = true;
				add_action( 'shutdown', array( $this, 'schedule_events' ) );
			}
		}
	}

	/**
	 * Schedule a state check at the exact start and end times so waitlist
	 * e-mails go out promptly even when nobody is visiting the store.
	 */
	public function schedule_events() {
		wp_clear_scheduled_hook( 'kagstm_check_state' );

		if ( '1' !== KAGSTM_Settings::get( 'enabled' ) ) {
			return;
		}

		foreach ( array( 'start_datetime', 'end_datetime' ) as $key ) {
			$timestamp = KAGSTM_Settings::to_timestamp( (string) KAGSTM_Settings::get( $key ) );
			if ( null !== $timestamp && $timestamp + 2 > time() ) {
				wp_schedule_single_event( $timestamp + 2, 'kagstm_check_state' );
			}
		}
	}

	// ----- Exceptions and restrictions -----.

	/**
	 * Delete the cached list of products in excepted categories.
	 */
	public function flush_category_cache() {
		delete_transient( 'kagstm_category_product_ids_cache' );
		$this->exceptions = null;
	}

	/**
	 * Product IDs excluded from restrictions, including every product in an
	 * excluded category.
	 *
	 * @return int[]
	 */
	public function get_effective_product_exceptions() {
		if ( null !== $this->exceptions ) {
			return $this->exceptions;
		}

		$product_exceptions  = KAGSTM_Settings::get( 'product_exceptions' );
		$category_exceptions = KAGSTM_Settings::get( 'category_exceptions' );

		if ( ! empty( $category_exceptions ) ) {
			$cache_key = 'kagstm_category_product_ids_cache';
			$cached    = get_transient( $cache_key );

			if ( false === $cached ) {
				$cached = get_posts(
					array(
						'post_type'      => 'product',
						'post_status'    => 'publish',
						'posts_per_page' => -1,
						'fields'         => 'ids',
						'no_found_rows'  => true,
						'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- results are cached in a transient.
							array(
								'taxonomy' => 'product_cat',
								'field'    => 'term_id',
								'terms'    => $category_exceptions,
							),
						),
					)
				);
				set_transient( $cache_key, $cached, 5 * MINUTE_IN_SECONDS );
			}

			$product_exceptions = array_merge( $product_exceptions, (array) $cached );
		}

		$this->exceptions = array_values( array_unique( array_map( 'absint', $product_exceptions ) ) );
		return $this->exceptions;
	}

	/**
	 * Whether a product (or its parent) is on the exceptions list.
	 *
	 * @param int $product_id   Product or variation ID.
	 * @param int $parent_id    Parent product ID, when known.
	 * @return bool
	 */
	private function is_excepted( $product_id, $parent_id = 0 ) {
		$exceptions = $this->get_effective_product_exceptions();
		return in_array( absint( $product_id ), $exceptions, true ) || ( $parent_id && in_array( absint( $parent_id ), $exceptions, true ) );
	}

	/**
	 * Attach the storefront restriction hooks.
	 */
	private function init_restrictions() {
		add_filter( 'woocommerce_is_purchasable', array( $this, 'restrict_purchasable' ), 999, 2 );
		add_filter( 'woocommerce_variation_is_purchasable', array( $this, 'restrict_purchasable' ), 999, 2 );
		add_filter( 'woocommerce_add_to_cart_validation', array( $this, 'block_add_to_cart' ), 999, 4 );

		// Cart and Checkout blocks (Store API).
		add_action( 'woocommerce_store_api_validate_add_to_cart', array( $this, 'block_store_api_add_to_cart' ), 10, 1 );
		add_action( 'woocommerce_store_api_cart_errors', array( $this, 'block_store_api_checkout' ), 10, 2 );

		// Classic checkout submissions.
		add_action( 'woocommerce_after_checkout_validation', array( $this, 'block_classic_checkout' ), 10, 2 );

		add_action( 'wp_ajax_woocommerce_add_to_cart', array( $this, 'block_ajax_add_to_cart' ), 1 );
		add_action( 'wp_ajax_nopriv_woocommerce_add_to_cart', array( $this, 'block_ajax_add_to_cart' ), 1 );

		add_action( 'wp', array( $this, 'apply_button_behavior_modifications' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_frontend_assets' ) );
		add_action( 'template_redirect', array( $this, 'restrict_checkout_page' ) );
		add_action( 'wp_loaded', array( $this, 'maybe_clear_active_carts' ), 30 );

		add_action( 'wp_body_open', array( $this, 'render_global_notice_banner' ), 1 );
		add_action( 'wp_footer', array( $this, 'render_global_notice_banner' ), 1 );
	}

	/**
	 * Remove non-excepted items from the visitor's cart.
	 */
	public function maybe_clear_active_carts() {
		if ( '1' !== KAGSTM_Settings::get( 'clear_cart' ) || $this->is_preview() || ! function_exists( 'WC' ) || ! WC()->cart ) {
			return;
		}
		if ( is_admin() && ! wp_doing_ajax() ) {
			return;
		}

		$removed = 0;
		foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
			if ( ! $this->is_excepted( $cart_item['product_id'] ) ) {
				WC()->cart->remove_cart_item( $cart_item_key );
				++$removed;
			}
		}

		if ( $removed && ! wp_doing_ajax() && ! defined( 'REST_REQUEST' ) && function_exists( 'wc_add_notice' ) ) {
			wc_add_notice( __( 'Some items were removed from your cart because we are temporarily closed for a stock take.', 'kagunda-stock-take-mode-for-woocommerce' ), 'notice' );
		}
	}

	/**
	 * Filter callback: is a product purchasable while restrictions are active?
	 *
	 * @param bool       $purchasable Current purchasable state.
	 * @param WC_Product $product     Product object.
	 * @return bool
	 */
	public function restrict_purchasable( $purchasable, $product ) {
		if ( ! $product instanceof WC_Product ) {
			return $purchasable;
		}

		if ( $this->is_excepted( $product->get_id(), $product->get_parent_id() ) ) {
			return $purchasable;
		}

		return false;
	}

	/**
	 * Block classic add-to-cart submissions unless the product is excepted.
	 *
	 * @param bool $passed       Whether validation currently passes.
	 * @param int  $product_id   Product ID being added.
	 * @param int  $quantity     Quantity requested.
	 * @param int  $variation_id Variation ID, if any.
	 * @return bool
	 */
	public function block_add_to_cart( $passed, $product_id, $quantity = 1, $variation_id = 0 ) {
		if ( $this->is_excepted( $product_id, 0 ) || ( $variation_id && $this->is_excepted( $variation_id, $product_id ) ) ) {
			return $passed;
		}

		$this->record_blocked_attempt();
		wc_add_notice( wp_kses_post( $this->get_stock_take_message() ), 'error' );
		return false;
	}

	/**
	 * Block Store API (block-based cart) add-to-cart requests.
	 *
	 * @param WC_Product $product Product being added.
	 * @throws \Automattic\WooCommerce\StoreApi\Exceptions\RouteException When the product is not excepted.
	 */
	public function block_store_api_add_to_cart( $product ) {
		if ( ! $product instanceof WC_Product || $this->is_excepted( $product->get_id(), $product->get_parent_id() ) ) {
			return;
		}

		$this->record_blocked_attempt();

		if ( class_exists( '\Automattic\WooCommerce\StoreApi\Exceptions\RouteException' ) ) {
			throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException( 'kagstm_stock_take_active', esc_html( wp_strip_all_tags( $this->get_stock_take_message() ) ), 403 );
		}
	}

	/**
	 * Add a validation error to the block-based cart/checkout.
	 *
	 * @param WP_Error $errors Error collection.
	 * @param WC_Cart  $cart   Cart being validated.
	 */
	public function block_store_api_checkout( $errors, $cart ) {
		if ( ! $errors instanceof WP_Error || ! $cart instanceof WC_Cart || ! $this->cart_has_restricted_items( $cart ) ) {
			return;
		}

		$errors->add( 'kagstm_stock_take_active', wp_strip_all_tags( $this->get_stock_take_message() ) );
	}

	/**
	 * Add a validation error to classic checkout submissions.
	 *
	 * @param array    $data   Posted checkout data.
	 * @param WP_Error $errors Error collection.
	 */
	public function block_classic_checkout( $data, $errors ) {
		unset( $data );

		if ( ! $errors instanceof WP_Error || ! function_exists( 'WC' ) || ! WC()->cart || ! $this->cart_has_restricted_items( WC()->cart ) ) {
			return;
		}

		$this->record_blocked_attempt();
		$errors->add( 'kagstm_stock_take_active', wp_strip_all_tags( $this->get_stock_take_message() ) );
	}

	/**
	 * Whether a cart holds anything that is not on the exceptions list.
	 *
	 * @param WC_Cart $cart Cart object.
	 * @return bool
	 */
	private function cart_has_restricted_items( $cart ) {
		foreach ( $cart->get_cart() as $item ) {
			if ( ! $this->is_excepted( $item['product_id'] ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Block the legacy AJAX add-to-cart endpoint unless the product is excepted.
	 */
	public function block_ajax_add_to_cart() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- intercepting WooCommerce's own AJAX action; WooCommerce performs its own checks when we let the request through.
		$product_id = isset( $_REQUEST['product_id'] ) ? absint( $_REQUEST['product_id'] ) : 0;

		if ( $product_id && $this->is_excepted( $product_id ) ) {
			return;
		}

		$this->record_blocked_attempt();
		wp_send_json(
			array(
				'error'  => true,
				'notice' => wp_kses_post( $this->get_stock_take_message() ),
			)
		);
	}

	/**
	 * Count a blocked purchase attempt (not while an admin previews).
	 */
	private function record_blocked_attempt() {
		if ( $this->is_preview() ) {
			return;
		}
		$count = (int) get_option( 'kagstm_stat_blocked_attempts', 0 );
		if ( 0 === $count ) {
			add_option( 'kagstm_stat_blocked_attempts', 1, '', 'no' );
			return;
		}
		update_option( 'kagstm_stat_blocked_attempts', $count + 1, false );
	}

	/**
	 * Get the customer-facing restriction message.
	 *
	 * @return string
	 */
	public function get_stock_take_message() {
		$message = (string) KAGSTM_Settings::get( 'message' );
		if ( '' === trim( wp_strip_all_tags( $message ) ) ) {
			$message = __( 'Sorry, we are closed for stock intake.', 'kagunda-stock-take-mode-for-woocommerce' );
		}
		return (string) apply_filters( 'kagstm_message', $message );
	}

	/**
	 * Keep customers with restricted carts out of the classic checkout page.
	 */
	public function restrict_checkout_page() {
		if ( ! function_exists( 'is_checkout' ) || ! is_checkout() || is_order_received_page() || ! function_exists( 'WC' ) || ! WC()->cart ) {
			return;
		}

		if ( $this->cart_has_restricted_items( WC()->cart ) ) {
			$this->record_blocked_attempt();
			wc_add_notice( wp_kses_post( $this->get_stock_take_message() ), 'error' );
			wp_safe_redirect( wc_get_cart_url() );
			exit;
		}
	}

	/**
	 * Apply the configured add-to-cart button behavior.
	 */
	public function apply_button_behavior_modifications() {
		$behavior = KAGSTM_Settings::get( 'button_behavior' );

		if ( 'hide' === $behavior ) {
			$single_id = function_exists( 'is_singular' ) && is_singular( 'product' ) ? (int) get_queried_object_id() : 0;
			if ( ! $single_id || ! $this->is_excepted( $single_id ) ) {
				remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
			}
			add_filter( 'woocommerce_loop_add_to_cart_link', array( $this, 'filter_hide_loop_button' ), 999, 2 );
		} elseif ( 'disable_text' === $behavior ) {
			add_filter( 'woocommerce_product_single_add_to_cart_text', array( $this, 'filter_button_label_copy' ), 999, 2 );
			add_filter( 'woocommerce_product_add_to_cart_text', array( $this, 'filter_button_label_copy' ), 999, 2 );
			add_filter( 'woocommerce_loop_add_to_cart_link', array( $this, 'render_deactivated_loop_element' ), 999, 2 );
		}
		// "inactive_only" is handled client-side by the enqueued script.
	}

	/**
	 * Filter callback: hide the loop add-to-cart button for restricted products.
	 *
	 * @param string     $html    Original markup.
	 * @param WC_Product $product Product object.
	 * @return string
	 */
	public function filter_hide_loop_button( $html, $product ) {
		if ( $product instanceof WC_Product && $this->is_excepted( $product->get_id(), $product->get_parent_id() ) ) {
			return $html;
		}
		return '';
	}

	/**
	 * Filter callback: override the add-to-cart button label.
	 *
	 * @param string          $text    Original label.
	 * @param WC_Product|null $product Product object.
	 * @return string
	 */
	public function filter_button_label_copy( $text, $product = null ) {
		if ( $product instanceof WC_Product && $this->is_excepted( $product->get_id(), $product->get_parent_id() ) ) {
			return $text;
		}
		return (string) KAGSTM_Settings::get( 'button_text' );
	}

	/**
	 * Filter callback: render a disabled loop add-to-cart link.
	 *
	 * @param string     $html    Original markup.
	 * @param WC_Product $product Product object.
	 * @return string
	 */
	public function render_deactivated_loop_element( $html, $product ) {
		if ( $this->is_excepted( $product->get_id(), $product->get_parent_id() ) ) {
			return $html;
		}

		return sprintf(
			'<a href="%1$s" class="button product_type_%2$s disabled kagstm-disabled-loop-button" aria-disabled="true">%3$s</a>',
			esc_url( $product->get_permalink() ),
			esc_attr( $product->get_type() ),
			esc_html( KAGSTM_Settings::get( 'button_text' ) )
		);
	}

	// ----- Storefront banner -----.

	/**
	 * Whether the banner should be printed on the current page.
	 *
	 * @return bool
	 */
	private function should_show_banner() {
		if ( 'shop' === KAGSTM_Settings::get( 'banner_scope' ) ) {
			$is_shop_area = ( function_exists( 'is_woocommerce' ) && is_woocommerce() )
				|| ( function_exists( 'is_cart' ) && is_cart() )
				|| ( function_exists( 'is_checkout' ) && is_checkout() );
			if ( ! $is_shop_area ) {
				return (bool) apply_filters( 'kagstm_show_banner', false );
			}
		}

		return (bool) apply_filters( 'kagstm_show_banner', true );
	}

	/**
	 * Enqueue the frontend banner styles and script.
	 */
	public function enqueue_frontend_assets() {
		wp_enqueue_style( 'kagstm-frontend', KAGSTM_PLUGIN_URL . 'assets/css/frontend.css', array(), KAGSTM_VERSION );

		wp_add_inline_style(
			'kagstm-frontend',
			sprintf(
				':root{--kagstm-bg:%1$s;--kagstm-text:%2$s;}',
				sanitize_hex_color( KAGSTM_Settings::get( 'bg_color' ) ),
				sanitize_hex_color( KAGSTM_Settings::get( 'text_color' ) )
			)
		);

		wp_enqueue_script( 'kagstm-frontend', KAGSTM_PLUGIN_URL . 'assets/js/frontend.js', array(), KAGSTM_VERSION, true );

		wp_localize_script(
			'kagstm-frontend',
			'KAGSTM_Frontend',
			array(
				'ajaxUrl'        => admin_url( 'admin-ajax.php' ),
				'subscribeNonce' => wp_create_nonce( 'kagstm-subscribe-nonce' ),
				'buttonBehavior' => KAGSTM_Settings::get( 'button_behavior' ),
				'exceptions'     => $this->get_effective_product_exceptions(),
				'i18n'           => array(
					'invalidEmail'   => __( 'Please enter a valid email address.', 'kagunda-stock-take-mode-for-woocommerce' ),
					'joining'        => __( 'Joining...', 'kagunda-stock-take-mode-for-woocommerce' ),
					'joinWaitlist'   => __( 'Join Waitlist', 'kagunda-stock-take-mode-for-woocommerce' ),
					'subscribeError' => __( 'Subscription error. Please try again.', 'kagunda-stock-take-mode-for-woocommerce' ),
					'orderingFrozen' => __( 'Ordering is currently paused for stock take.', 'kagunda-stock-take-mode-for-woocommerce' ),
					'backSoon'       => __( 'We are about to re-open. Reloading shortly...', 'kagunda-stock-take-mode-for-woocommerce' ),
				),
			)
		);
	}

	/**
	 * Print the notice banner (once) via wp_body_open, or wp_footer as a
	 * fallback for themes that do not call wp_body_open().
	 */
	public function render_global_notice_banner() {
		if ( $this->banner_rendered || ! $this->should_show_banner() ) {
			return;
		}

		$message = $this->get_stock_take_message();
		if ( '' === trim( $message ) ) {
			return;
		}

		$this->banner_rendered = true;

		$position        = KAGSTM_Settings::get( 'banner_position' );
		$enable_waitlist = '1' === KAGSTM_Settings::get( 'enable_waitlist' );
		$note            = (string) KAGSTM_Settings::get( 'waitlist_note' );
		$deadline_iso    = '';

		if ( '1' === KAGSTM_Settings::get( 'show_countdown' ) ) {
			$end_ts = KAGSTM_Settings::to_timestamp( (string) KAGSTM_Settings::get( 'end_datetime' ) );
			if ( null !== $end_ts && $end_ts > time() ) {
				$deadline_iso = gmdate( 'c', $end_ts );
			}
		}

		$classes = 'kagstm-top-banner-wrapper kagstm-pos-' . sanitize_html_class( $position );
		?>
		<div class="<?php echo esc_attr( $classes ); ?>" role="region" aria-label="<?php esc_attr_e( 'Store notice', 'kagunda-stock-take-mode-for-woocommerce' ); ?>">
			<div class="kagstm-top-banner-content">
				<span class="kagstm-banner-icon" aria-hidden="true">
					<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" focusable="false"><path d="M12 2.5 4.5 5.5v5.7c0 4.6 3.1 8.6 7.5 10.3 4.4-1.7 7.5-5.7 7.5-10.3V5.5L12 2.5Z"/><path d="M10 9.5v5M14 9.5v5"/></svg>
				</span>
				<div class="kagstm-banner-text-inner" role="status"><?php echo wp_kses_post( $message ); ?></div>

				<?php if ( '' !== $deadline_iso ) : ?>
					<div class="kagstm-countdown-container" role="timer" aria-label="<?php esc_attr_e( 'Time until we re-open', 'kagunda-stock-take-mode-for-woocommerce' ); ?>" data-deadline="<?php echo esc_attr( $deadline_iso ); ?>" data-server-now="<?php echo esc_attr( (string) ( time() * 1000 ) ); ?>">
						<span class="kagstm-time-segment"><b class="days">00</b>d</span>
						<span class="kagstm-time-segment"><b class="hours">00</b>h</span>
						<span class="kagstm-time-segment"><b class="minutes">00</b>m</span>
						<span class="kagstm-time-segment"><b class="seconds">00</b>s</span>
					</div>
				<?php endif; ?>

				<?php if ( $enable_waitlist ) : ?>
					<form class="kagstm-waitlist-form-wrap" novalidate>
						<label class="kagstm-sr-only" for="kagstm-subscriber-email"><?php esc_html_e( 'Email address', 'kagunda-stock-take-mode-for-woocommerce' ); ?></label>
						<input type="email" id="kagstm-subscriber-email" name="email" autocomplete="email" placeholder="<?php esc_attr_e( 'Notify me when open...', 'kagunda-stock-take-mode-for-woocommerce' ); ?>" required />
						<input type="text" name="kagstm_website" class="kagstm-hp" tabindex="-1" autocomplete="off" aria-hidden="true" />
						<button type="submit" id="kagstm-subscribe-btn"><?php esc_html_e( 'Join Waitlist', 'kagunda-stock-take-mode-for-woocommerce' ); ?></button>
						<?php if ( '' !== $note ) : ?>
							<span class="kagstm-waitlist-note"><?php echo esc_html( $note ); ?></span>
						<?php endif; ?>
						<span class="kagstm-waitlist-feedback" role="status" aria-live="polite"></span>
					</form>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	// ----- Waitlist sign-up -----.

	/**
	 * AJAX handler: capture a waitlist e-mail address.
	 */
	public function handle_banner_subscription() {
		if ( ! check_ajax_referer( 'kagstm-subscribe-nonce', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Your session expired. Please refresh the page and try again.', 'kagunda-stock-take-mode-for-woocommerce' ) ) );
		}

		if ( '1' !== KAGSTM_Settings::get( 'enable_waitlist' ) ) {
			wp_send_json_error( array( 'message' => __( 'The waitlist is not available right now.', 'kagunda-stock-take-mode-for-woocommerce' ) ) );
		}

		$success = array( 'message' => __( 'You are on the list! We will email you when we re-open.', 'kagunda-stock-take-mode-for-woocommerce' ) );

		// Honeypot: real visitors never see or fill this field. Pretend it worked.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified above.
		if ( ! empty( $_POST['kagstm_website'] ) ) {
			wp_send_json_success( $success );
		}

		if ( KAGSTM_Waitlist::is_rate_limited() ) {
			wp_send_json_error( array( 'message' => __( 'Too many attempts. Please try again in a few minutes.', 'kagunda-stock-take-mode-for-woocommerce' ) ) );
		}
		KAGSTM_Waitlist::record_attempt();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified above.
		$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		if ( ! is_email( $email ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid email address.', 'kagunda-stock-take-mode-for-woocommerce' ) ) );
		}

		$result = KAGSTM_Waitlist::add( $email );

		if ( 'full' === $result ) {
			wp_send_json_error( array( 'message' => __( 'The waitlist is full right now. Please check back soon.', 'kagunda-stock-take-mode-for-woocommerce' ) ) );
		}

		if ( 'added' === $result ) {
			do_action( 'kagstm_waitlist_subscribed', $email );
		}

		// Same answer whether or not the address was already listed, so the form can not be used to probe who has signed up.
		wp_send_json_success( $success );
	}

	// ----- E-mail -----.

	/**
	 * Compile the {token} placeholders in an e-mail subject and body.
	 *
	 * @param string $subject_tpl     Subject template.
	 * @param string $body_tpl        Body template.
	 * @param string $recipient_email Recipient address.
	 * @return array{subject:string,body:string}
	 */
	public function get_compiled_email_template( $subject_tpl, $body_tpl, $recipient_email ) {
		if ( '' === $subject_tpl ) {
			$subject_tpl = __( 'Stock Count Completed - We Are Open!', 'kagunda-stock-take-mode-for-woocommerce' );
		}
		if ( '' === trim( wp_strip_all_tags( $body_tpl ) ) ) {
			$body_tpl = __( 'Hello,<br><br>Great news! Our scheduled stock intake has concluded successfully. Ordering and checkout are fully back online.<br><br>Visit our catalog here: <a href="{shop_url}">{site_name}</a><br><br>Thank you for your patience!', 'kagunda-stock-take-mode-for-woocommerce' );
		}

		$site_name = get_bloginfo( 'name' );
		$shop_url  = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );

		$plain = array(
			'{site_name}'      => wp_specialchars_decode( $site_name, ENT_QUOTES ),
			'{site_url}'       => home_url( '/' ),
			'{shop_url}'       => $shop_url,
			'{customer_email}' => $recipient_email,
		);
		$html  = array(
			'{site_name}'      => esc_html( $site_name ),
			'{site_url}'       => esc_url( home_url( '/' ) ),
			'{shop_url}'       => esc_url( $shop_url ),
			'{customer_email}' => esc_html( $recipient_email ),
		);

		return array(
			'subject' => str_replace( array_keys( $plain ), array_values( $plain ), $subject_tpl ),
			'body'    => str_replace( array_keys( $html ), array_values( $html ), $body_tpl ),
		);
	}

	/**
	 * Queue the re-open e-mail for every waitlist subscriber.
	 *
	 * E-mails are sent in small batches by WP-Cron so a large list can never
	 * slow down or time out the request that noticed the store re-opened.
	 *
	 * @param bool $force Send even if automatic broadcast is switched off.
	 * @return int Number of subscribers queued.
	 */
	public function start_broadcast( $force = false ) {
		if ( ! $force && '1' !== KAGSTM_Settings::get( 'broadcast_complete' ) ) {
			return 0;
		}

		$emails = KAGSTM_Waitlist::emails();
		if ( empty( $emails ) ) {
			return 0;
		}

		$queue = get_option( 'kagstm_broadcast_queue', array() );
		$queue = is_array( $queue ) ? array_values( array_unique( array_merge( $queue, $emails ) ) ) : $emails;

		update_option( 'kagstm_broadcast_queue', $queue, false );
		KAGSTM_Waitlist::clear();

		KAGSTM_Logger::log( sprintf( 'Re-open broadcast queued for %d waitlist subscribers.', count( $emails ) ), 'info' );

		if ( ! wp_next_scheduled( 'kagstm_process_broadcast_queue' ) ) {
			wp_schedule_single_event( time() + 5, 'kagstm_process_broadcast_queue' );
		}

		return count( $emails );
	}

	/**
	 * Cron callback: send the next batch of queued re-open e-mails.
	 */
	public function process_broadcast_queue() {
		$queue = get_option( 'kagstm_broadcast_queue', array() );
		if ( ! is_array( $queue ) || empty( $queue ) ) {
			delete_option( 'kagstm_broadcast_queue' );
			return;
		}

		$batch_size = max( 1, (int) apply_filters( 'kagstm_broadcast_batch_size', 25 ) );
		$batch      = array_splice( $queue, 0, $batch_size );
		$subject    = (string) KAGSTM_Settings::get( 'broadcast_subject' );
		$body       = (string) KAGSTM_Settings::get( 'broadcast_body' );
		$headers    = array( 'Content-Type: text/html; charset=UTF-8' );
		$sent       = 0;

		foreach ( $batch as $email ) {
			$compiled = $this->get_compiled_email_template( $subject, $body, $email );
			if ( wp_mail( $email, $compiled['subject'], $compiled['body'], $headers ) ) {
				++$sent;
			}
		}

		KAGSTM_Logger::log( sprintf( 'Re-open broadcast batch: %1$d of %2$d sent, %3$d remaining.', $sent, count( $batch ), count( $queue ) ), 'info' );

		if ( empty( $queue ) ) {
			delete_option( 'kagstm_broadcast_queue' );
			return;
		}

		update_option( 'kagstm_broadcast_queue', $queue, false );
		wp_schedule_single_event( time() + MINUTE_IN_SECONDS, 'kagstm_process_broadcast_queue' );
	}

	/**
	 * Send an operational status e-mail to the store admin.
	 *
	 * @param string $status Human-readable status label.
	 */
	private function send_admin_status_email( $status ) {
		if ( '1' !== KAGSTM_Settings::get( 'admin_alerts' ) ) {
			return;
		}

		$to = get_option( 'admin_email' );
		/* translators: 1: site name, 2: status label, e.g. "Initiated". */
		$subject = sprintf( __( '[%1$s] Stock Take Mode Alert: %2$s', 'kagunda-stock-take-mode-for-woocommerce' ), wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ), $status );
		$body    = sprintf(
			/* translators: 1: status label, 2: timestamp. */
			__( 'Hello,<br><br>Stock Take Mode is now: <b>%1$s</b>.<br><br>Timestamp: %2$s', 'kagunda-stock-take-mode-for-woocommerce' ),
			esc_html( $status ),
			esc_html( current_time( 'mysql' ) )
		);

		wp_mail( $to, $subject, $body, array( 'Content-Type: text/html; charset=UTF-8' ) );
	}
}
