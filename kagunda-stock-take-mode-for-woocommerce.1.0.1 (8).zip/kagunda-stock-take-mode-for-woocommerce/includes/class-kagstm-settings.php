<?php
/**
 * Settings registry for Stock Take Mode for WooCommerce.
 *
 * Single source of truth for option defaults and sanitization, shared by the
 * settings screen, the import tool and the front-end engine.
 *
 * @package Kagunda_Stock_Take_Mode_For_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Option defaults, getters and sanitizers.
 */
class KAGSTM_Settings {

	/**
	 * Settings API option group.
	 */
	const OPTION_GROUP = 'kagstm_settings_group';

	/**
	 * Prefix applied to every option name.
	 */
	const PREFIX = 'kagstm_';

	/**
	 * Cached defaults (built lazily so translations are loaded first).
	 *
	 * @var array|null
	 */
	private static $defaults = null;

	/**
	 * Default value for every setting, keyed without the option prefix.
	 *
	 * @return array
	 */
	public static function defaults() {
		if ( null === self::$defaults ) {
			self::$defaults = array(
				'enabled'                  => '0',
				'start_datetime'           => '',
				'end_datetime'             => '',
				'message'                  => '',
				'button_behavior'          => 'hide',
				'button_text'              => __( 'Stock Take Active', 'kagunda-stock-take-mode-for-woocommerce' ),
				'bg_color'                 => '#e11d48',
				'text_color'               => '#ffffff',
				'clear_cart'               => '0',
				'show_countdown'           => '0',
				'enable_waitlist'          => '0',
				'admin_alerts'             => '0',
				'show_admin_bar_indicator' => '1',
				'broadcast_complete'       => '0',
				'broadcast_subject'        => __( 'Stock Count Completed - We Are Open!', 'kagunda-stock-take-mode-for-woocommerce' ),
				'broadcast_body'           => '',
				'bypass_roles'             => array( 'administrator', 'shop_manager' ),
				'product_exceptions'       => array(),
				'category_exceptions'      => array(),
				// Added in 1.0.1.
				'banner_position'          => 'top_sticky',
				'banner_scope'             => 'all',
				'waitlist_note'            => __( "We'll email you once, when we re-open.", 'kagunda-stock-take-mode-for-woocommerce' ),
			);
		}

		return self::$defaults;
	}

	/**
	 * Keys that fall back to their default when saved empty.
	 *
	 * @return string[]
	 */
	private static function fallback_when_empty() {
		return array( 'button_text', 'bg_color', 'text_color', 'broadcast_subject', 'button_behavior', 'banner_position', 'banner_scope' );
	}

	/**
	 * Keys that are portable between sites (import/export allow-list).
	 *
	 * @return string[]
	 */
	public static function portable_keys() {
		return array_keys( self::defaults() );
	}

	/**
	 * Read a setting.
	 *
	 * @param string $key Option key without the prefix.
	 * @return mixed
	 */
	public static function get( $key ) {
		$defaults = self::defaults();
		$default  = isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
		$value    = get_option( self::PREFIX . $key, $default );

		if ( is_array( $default ) ) {
			return is_array( $value ) ? $value : array();
		}

		if ( ( '' === $value || null === $value || false === $value ) && in_array( $key, self::fallback_when_empty(), true ) ) {
			return $default;
		}

		return $value;
	}

	/**
	 * Capability required to manage the plugin.
	 *
	 * @return string
	 */
	public static function capability() {
		$capability = apply_filters( 'kagstm_capability', 'manage_options' );
		return is_string( $capability ) && '' !== $capability ? $capability : 'manage_options';
	}

	/**
	 * Register every setting with the Settings API.
	 */
	public static function register() {
		foreach ( self::defaults() as $key => $default ) {
			$key_copy = $key;
			register_setting(
				self::OPTION_GROUP,
				self::PREFIX . $key,
				array(
					'type'              => is_array( $default ) ? 'array' : 'string',
					'sanitize_callback' => static function ( $value ) use ( $key_copy ) {
						return KAGSTM_Settings::sanitize( $key_copy, $value );
					},
					'default'           => $default,
					'show_in_rest'      => false,
				)
			);
		}
	}

	/**
	 * Sanitize a single value by key. Used by the Settings API and by import.
	 *
	 * @param string $key   Option key without the prefix.
	 * @param mixed  $value Raw value.
	 * @return mixed
	 */
	public static function sanitize( $key, $value ) {
		$defaults = self::defaults();

		switch ( $key ) {
			case 'enabled':
			case 'clear_cart':
			case 'show_countdown':
			case 'enable_waitlist':
			case 'admin_alerts':
			case 'show_admin_bar_indicator':
			case 'broadcast_complete':
				return self::sanitize_flag( $value );

			case 'start_datetime':
			case 'end_datetime':
				return self::sanitize_datetime( $value );

			case 'message':
			case 'broadcast_body':
				return wp_kses_post( is_scalar( $value ) ? (string) $value : '' );

			case 'button_behavior':
			case 'banner_position':
			case 'banner_scope':
				$allowed = self::choices( $key );
				$value   = is_scalar( $value ) ? sanitize_key( (string) $value ) : '';
				return in_array( $value, $allowed, true ) ? $value : $defaults[ $key ];

			case 'bg_color':
			case 'text_color':
				$color = sanitize_hex_color( is_scalar( $value ) ? (string) $value : '' );
				return $color ? $color : $defaults[ $key ];

			case 'bypass_roles':
				return self::sanitize_roles( $value );

			case 'product_exceptions':
			case 'category_exceptions':
				return self::sanitize_ids( $value );

			default:
				return sanitize_text_field( is_scalar( $value ) ? (string) $value : '' );
		}
	}

	/**
	 * Allowed values for choice-type settings.
	 *
	 * @param string $key Option key without the prefix.
	 * @return string[]
	 */
	public static function choices( $key ) {
		switch ( $key ) {
			case 'button_behavior':
				return array( 'hide', 'disable_text', 'inactive_only' );
			case 'banner_position':
				return array( 'top_sticky', 'top_static', 'bottom' );
			case 'banner_scope':
				return array( 'all', 'shop' );
			default:
				return array();
		}
	}

	/**
	 * Normalise a checkbox-style value to '1' or '0'.
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	public static function sanitize_flag( $value ) {
		return ( true === $value || '1' === $value || 1 === $value || 'yes' === $value ) ? '1' : '0';
	}

	/**
	 * Accept only a well-formed local date-time (as produced by datetime-local).
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	public static function sanitize_datetime( $value ) {
		$value = is_scalar( $value ) ? trim( (string) $value ) : '';
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(:\d{2})?$/', $value ) ) {
			return str_replace( ' ', 'T', substr( $value, 0, 16 ) );
		}
		return '';
	}

	/**
	 * Keep only role slugs that actually exist on this site.
	 *
	 * @param mixed $value Raw value.
	 * @return string[]
	 */
	public static function sanitize_roles( $value ) {
		if ( ! is_array( $value ) ) {
			return array();
		}
		$known = array_keys( wp_roles()->roles );
		$roles = array_map( 'sanitize_key', array_filter( $value, 'is_scalar' ) );
		return array_values( array_intersect( $roles, $known ) );
	}

	/**
	 * Sanitize an array of positive integer IDs.
	 *
	 * @param mixed $value Raw value.
	 * @return int[]
	 */
	public static function sanitize_ids( $value ) {
		if ( ! is_array( $value ) ) {
			return array();
		}
		return array_values( array_unique( array_filter( array_map( 'absint', array_filter( $value, 'is_scalar' ) ) ) ) );
	}

	/**
	 * Convert a stored local date-time (store timezone) to a Unix timestamp.
	 *
	 * @param string $datetime Stored date-time string.
	 * @return int|null Null when empty or unparseable.
	 */
	public static function to_timestamp( $datetime ) {
		if ( ! is_string( $datetime ) || '' === $datetime ) {
			return null;
		}

		$timezone = wp_timezone();
		foreach ( array( 'Y-m-d\TH:i', 'Y-m-d\TH:i:s', 'Y-m-d H:i:s', 'Y-m-d H:i' ) as $format ) {
			$parsed = date_create_immutable_from_format( $format, $datetime, $timezone );
			if ( $parsed instanceof DateTimeImmutable ) {
				return $parsed->getTimestamp();
			}
		}

		$parsed = date_create_immutable( $datetime, $timezone );
		return $parsed instanceof DateTimeImmutable ? $parsed->getTimestamp() : null;
	}

	/**
	 * State of the configured window, independent of who is visiting.
	 *
	 * @return string One of: disabled, waiting, active, expired.
	 */
	public static function window_state() {
		if ( '1' !== self::get( 'enabled' ) ) {
			return 'disabled';
		}

		$now   = time();
		$start = self::to_timestamp( (string) self::get( 'start_datetime' ) );
		$end   = self::to_timestamp( (string) self::get( 'end_datetime' ) );

		if ( null !== $start && $now < $start ) {
			return 'waiting';
		}
		if ( null !== $end && $now > $end ) {
			return 'expired';
		}

		return 'active';
	}
}
