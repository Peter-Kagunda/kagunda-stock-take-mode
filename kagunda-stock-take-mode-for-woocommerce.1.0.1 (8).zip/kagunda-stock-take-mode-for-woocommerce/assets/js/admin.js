/**
 * Admin settings screen behaviors for Stock Take Mode for WooCommerce.
 * Reads its configuration from the localized "KAGSTM_Admin" object.
 */
jQuery( function ( $ ) {
	'use strict';

	if ( typeof window.KAGSTM_Admin === 'undefined' ) {
		return;
	}

	var settings = window.KAGSTM_Admin;

	/* Color pickers + live preview ------------------------------------- */
	var $preview = $( '#kagstm-preview' );
	var $bgField = $( '#kagstm_bg_color' );
	var $textField = $( '#kagstm_text_color' );

	function updateColors() {
		$preview[ 0 ].style.setProperty( '--kagstm-bg', $bgField.val() || '#e11d48' );
		$preview[ 0 ].style.setProperty( '--kagstm-text', $textField.val() || '#ffffff' );
	}

	$( '.kagstm-color-field' ).wpColorPicker( {
		change: function () {
			// The picker updates the input after this callback; defer to read the new value.
			setTimeout( updateColors, 0 );
		},
		clear: function () {
			setTimeout( updateColors, 0 );
		},
	} );

	$( '.kagstm-preset' ).on( 'click', function () {
		$bgField.wpColorPicker( 'color', $( this ).data( 'bg' ) );
		$textField.wpColorPicker( 'color', $( this ).data( 'text' ) );
		updateColors();
	} );

	function editorContent( id ) {
		var editor = typeof window.tinyMCE !== 'undefined' ? window.tinyMCE.get( id ) : null;
		if ( editor && editor.initialized && ! editor.isHidden() ) {
			return editor.getContent();
		}
		return $( '#' + id ).val() || '';
	}

	function updatePreviewText() {
		var text = $( '<div>' ).html( editorContent( 'kagstm_message' ) ).text().trim();
		$( '#kagstm-preview-text' ).text( text || settings.i18n.previewFallback );
	}

	function updatePreviewToggles() {
		$( '#kagstm-preview-clock' ).toggle( $( '#kagstm_show_countdown' ).is( ':checked' ) );
		$( '#kagstm-preview-form' ).toggle( $( '#kagstm_enable_waitlist' ).is( ':checked' ) );
	}

	$( '#kagstm_show_countdown, #kagstm_enable_waitlist' ).on( 'change', updatePreviewToggles );
	$( document ).on( 'input change keyup', '#kagstm_message', updatePreviewText );
	$( document ).on( 'tinymce-editor-init', function ( event, editor ) {
		if ( editor.id === 'kagstm_message' ) {
			editor.on( 'input change keyup NodeChange', updatePreviewText );
			updatePreviewText();
		}
	} );

	updatePreviewText();
	updatePreviewToggles();

	/* Select boxes (uses WooCommerce's bundled selectWoo) --------------- */
	if ( settings.hasSelect && $.fn.selectWoo ) {
		$( '.kagstm-product-select' ).selectWoo( {
			width: '100%',
			placeholder: settings.i18n.searchProducts,
			minimumInputLength: 3,
			ajax: {
				url: settings.ajaxUrl,
				dataType: 'json',
				delay: 250,
				data: function ( params ) {
					return {
						term: params.term,
						action: 'kagstm_json_search_products',
						security: settings.searchNonce,
					};
				},
				processResults: function ( data ) {
					return { results: data };
				},
				cache: true,
			},
		} );

		$( '.kagstm-category-select' ).selectWoo( {
			width: '100%',
			placeholder: settings.i18n.searchCategories,
		} );
	}

	/* Tabs (remembers the last one) ----------------------------------- */
	var formTabs = [ '#tab-core', '#tab-ui' ];

	function showTab( target ) {
		var $link = $( '.kagstm-nav-tab[href="' + target + '"]' );
		if ( ! $link.length ) {
			target = '#tab-core';
			$link = $( '.kagstm-nav-tab[href="#tab-core"]' );
		}

		$( '.kagstm-nav-tab' ).removeClass( 'nav-tab-active' ).attr( 'aria-selected', 'false' );
		$link.addClass( 'nav-tab-active' ).attr( 'aria-selected', 'true' );
		$( '.kagstm-tab-content' ).removeClass( 'active' );
		$( target ).addClass( 'active' );
		$( '#kagstm-form-footer' ).toggle( -1 !== formTabs.indexOf( target ) );

		try {
			window.sessionStorage.setItem( 'kagstm_tab', target );
		} catch ( e ) {
			// Storage can be unavailable; the tab simply will not be remembered.
		}
	}

	$( '.kagstm-nav-tab' ).on( 'click', function ( e ) {
		e.preventDefault();
		showTab( $( this ).attr( 'href' ) );
	} );

	var initial = window.location.hash;
	if ( ! initial ) {
		try {
			initial = window.sessionStorage.getItem( 'kagstm_tab' ) || '';
		} catch ( e ) {
			initial = '';
		}
	}
	showTab( initial || '#tab-core' );

	/* Quick end time ---------------------------------------------------- */
	function pad( n ) {
		return ( '0' + n ).slice( -2 );
	}

	$( '.kagstm-quick-end [data-hours]' ).on( 'click', function () {
		var m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/.exec( settings.nowLocal );
		if ( ! m ) {
			return;
		}
		var base = Date.UTC( +m[ 1 ], +m[ 2 ] - 1, +m[ 3 ], +m[ 4 ], +m[ 5 ] );
		var d = new Date( base + parseInt( $( this ).data( 'hours' ), 10 ) * 3600000 );
		$( '#kagstm_start_datetime' ).val( '' );
		$( '#kagstm_end_datetime' ).val( d.getUTCFullYear() + '-' + pad( d.getUTCMonth() + 1 ) + '-' + pad( d.getUTCDate() ) + 'T' + pad( d.getUTCHours() ) + ':' + pad( d.getUTCMinutes() ) );
	} );

	$( '.kagstm-clear-dates' ).on( 'click', function () {
		$( '#kagstm_start_datetime, #kagstm_end_datetime' ).val( '' );
	} );

	/* Confirmations ------------------------------------------------------ */
	$( '[data-confirm]' ).on( 'click', function ( e ) {
		var key = $( this ).data( 'confirm' );
		var message = { clear: settings.i18n.confirmClear, broadcast: settings.i18n.confirmBroadcast, remove: settings.i18n.confirmRemove }[ key ];
		if ( message && ! window.confirm( message ) ) {
			e.preventDefault();
		}
	} );

	/* Waitlist search --------------------------------------------------- */
	$( '#kagstm-waitlist-search' ).on( 'input', function () {
		var q = $( this ).val().toLowerCase();
		$( '#kagstm-waitlist-table tbody tr' ).each( function () {
			var text = $( this ).find( '.kagstm-email-cell' ).text().toLowerCase();
			$( this ).toggle( '' === q || -1 !== text.indexOf( q ) );
		} );
	} );

	/* Test email --------------------------------------------------------- */
	$( '#kagstm-trigger-test-mail' ).on( 'click', function ( e ) {
		e.preventDefault();

		var button = $( this );
		var originalText = button.text();
		var $result = $( '#kagstm-test-result' );

		button.prop( 'disabled', true ).text( settings.i18n.dispatching );
		$result.removeClass( 'is-ok is-error' ).text( '' );

		$.post( settings.ajaxUrl, {
			action: 'kagstm_send_test_email',
			security: settings.searchNonce,
			test_email: $( '#kagstm-test-target-input' ).val(),
			subject: $( '#kagstm_broadcast_subject' ).val(),
			body: editorContent( 'kagstm_broadcast_body' ),
		} ).done( function ( response ) {
			var message = response && response.data && response.data.message ? response.data.message : settings.i18n.testEmailFailed;
			$result.addClass( response && response.success ? 'is-ok' : 'is-error' ).text( message );
		} ).fail( function () {
			$result.addClass( 'is-error' ).text( settings.i18n.testEmailFailed );
		} ).always( function () {
			button.prop( 'disabled', false ).text( originalText );
		} );
	} );
} );
