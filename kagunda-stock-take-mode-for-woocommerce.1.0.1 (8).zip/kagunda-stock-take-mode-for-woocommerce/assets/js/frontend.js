/**
 * Frontend behaviors for Stock Take Mode for WooCommerce.
 * Enqueued via wp_enqueue_script(); reads its configuration from the
 * localized "KAGSTM_Frontend" object rather than inline <script> blocks.
 */
( function () {
	'use strict';

	function ready( fn ) {
		if ( 'loading' === document.readyState ) {
			document.addEventListener( 'DOMContentLoaded', fn );
		} else {
			fn();
		}
	}

	ready( function () {
		if ( typeof window.KAGSTM_Frontend === 'undefined' ) {
			return;
		}

		var settings = window.KAGSTM_Frontend;

		initCountdown();
		initWaitlistForm();
		applyButtonBehavior();

		function initCountdown() {
			var clock = document.querySelector( '.kagstm-countdown-container' );
			if ( ! clock ) {
				return;
			}

			var deadline = new Date( clock.getAttribute( 'data-deadline' ) ).getTime();
			if ( isNaN( deadline ) ) {
				return;
			}

			// Use the server clock as the reference so a wrong device clock can not skew the timer.
			var serverNow = parseInt( clock.getAttribute( 'data-server-now' ), 10 );
			var offset = isNaN( serverNow ) ? 0 : serverNow - Date.now();

			var timer = setInterval( updateClock, 1000 );
			updateClock();

			function updateClock() {
				var remaining = deadline - ( Date.now() + offset );

				if ( remaining <= 0 ) {
					clearInterval( timer );
					finish();
					return;
				}

				setSegment( 'days', Math.floor( remaining / 86400000 ) );
				setSegment( 'hours', Math.floor( ( remaining / 3600000 ) % 24 ) );
				setSegment( 'minutes', Math.floor( ( remaining / 60000 ) % 60 ) );
				setSegment( 'seconds', Math.floor( ( remaining / 1000 ) % 60 ) );
			}

			function setSegment( className, value ) {
				var el = clock.querySelector( '.' + className );
				if ( el ) {
					el.textContent = ( '0' + value ).slice( -2 );
				}
			}

			function finish() {
				clock.textContent = settings.i18n.backSoon;
				clock.classList.add( 'kagstm-countdown-done' );

				// Reload once (with jitter, so visitors don't all hit the server together) to pick up the re-opened store.
				var key = 'kagstm_reloaded';
				try {
					var last = parseInt( window.sessionStorage.getItem( key ), 10 );
					if ( last && Date.now() - last < 120000 ) {
						return;
					}
					window.sessionStorage.setItem( key, String( Date.now() ) );
				} catch ( e ) {
					return;
				}

				setTimeout( function () {
					window.location.reload();
				}, 3000 + Math.floor( Math.random() * 9000 ) );
			}
		}

		function initWaitlistForm() {
			var form = document.querySelector( '.kagstm-waitlist-form-wrap' );
			if ( ! form ) {
				return;
			}

			var emailInput = form.querySelector( 'input[type="email"]' );
			var button = form.querySelector( 'button[type="submit"]' );
			var feedback = form.querySelector( '.kagstm-waitlist-feedback' );

			form.addEventListener( 'submit', function ( event ) {
				event.preventDefault();

				if ( ! emailInput || ! emailInput.checkValidity() || '' === emailInput.value.trim() ) {
					say( settings.i18n.invalidEmail );
					if ( emailInput ) {
						emailInput.focus();
					}
					return;
				}

				button.disabled = true;
				button.textContent = settings.i18n.joining;
				say( '' );

				var formData = new FormData( form );
				formData.append( 'action', 'kagstm_subscribe_email' );
				formData.append( 'nonce', settings.subscribeNonce );

				fetch( settings.ajaxUrl, { method: 'POST', body: formData, credentials: 'same-origin' } )
					.then( function ( response ) { return response.json(); } )
					.then( function ( response ) {
						if ( response && response.success ) {
							form.classList.add( 'kagstm-waitlist-joined' );
							Array.prototype.forEach.call( form.children, function ( child ) {
								if ( child !== feedback ) {
									child.style.display = 'none';
								}
							} );
							say( response.data.message );
						} else {
							say( response && response.data && response.data.message ? response.data.message : settings.i18n.subscribeError );
							reset();
						}
					} )
					.catch( function () {
						say( settings.i18n.subscribeError );
						reset();
					} );
			} );

			function reset() {
				button.disabled = false;
				button.textContent = settings.i18n.joinWaitlist;
			}

			function say( message ) {
				if ( feedback ) {
					feedback.textContent = message;
				}
			}
		}

		function applyButtonBehavior() {
			if ( ! settings.buttonBehavior ) {
				return;
			}

			var selector = '.add_to_cart_button, .single_add_to_cart_button, .wc-block-components-product-button__button, .wp-block-button.wc-block-components-product-button .wp-block-button__link';
			var excepted = ( settings.exceptions || [] ).map( Number );
			var buttons = Array.prototype.filter.call( document.querySelectorAll( selector ), function ( btn ) {
				var id = parseInt( btn.getAttribute( 'data-product_id' ) || btn.value, 10 );
				return isNaN( id ) || -1 === excepted.indexOf( id );
			} );

			if ( 'hide' === settings.buttonBehavior ) {
				Array.prototype.forEach.call( buttons, function ( btn ) {
					btn.style.setProperty( 'display', 'none', 'important' );
				} );
			} else if ( 'inactive_only' === settings.buttonBehavior ) {
				Array.prototype.forEach.call( buttons, function ( btn ) {
					btn.classList.add( 'disabled' );
					btn.disabled = true;
					btn.setAttribute( 'aria-disabled', 'true' );
					btn.setAttribute( 'title', settings.i18n.orderingFrozen );
					btn.style.setProperty( 'opacity', '0.6', 'important' );
					btn.style.setProperty( 'cursor', 'not-allowed', 'important' );
					btn.style.setProperty( 'pointer-events', 'none', 'important' );
				} );
			}
		}
	} );
} )();
